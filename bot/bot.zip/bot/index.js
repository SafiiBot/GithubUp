
const {
WAConnection: _WAConnection,
MessageType, 
Presence,
MessageOptions,
Mimetype,
WALocationMessage,
WA_MESSAGE_STUB_TYPES,
WA_DEFAULT_EPHEMERAL,
ReconnectMode,
ProxyAgent,
GroupSettingChange,
waChatKey,
mentionedJid,
processTime,
} = require("@adiwajshing/baileys")
const simple = require('./lib/simple')
let WAConnection = simple.WAConnection(_WAConnection)
const spin = require('spinnies')
const Crypto = require('crypto')
const fs = require('fs')
const axios = require('axios')
const moment = require('moment-timezone')
const { color, FarzLog} = require('./lib/color')
const colors = require('./lib/colors')
const figlet = require('figlet')
const ms = require('parse-ms')
const chalk = require('chalk')
const gambar2 = fs.readFileSync('./media/image/logo2.jpeg')

const getBuffer = async (url, options) => {
try {
options ? options : {}
const res = await axios({
method: "get",
url,
headers: {
'DNT': 1,
'Upgrade-Insecure-Request': 1
},
...options,
responseType: 'arraybuffer'
})
return res.data
} catch (e) {
console.log(`Error : ${e}`)
}
}
const spinner = {
"interval": 120,
"frames": [
"W",
"WA",
"WAI",
"WAIT",
"WAIT.",
"WAIT..",
"WAIT...",
"WAIT..",
"WAIT.",
"WAIT",
"WAI",
"WA",
"W",
""
]}
let globalSpinner;
var getGlobalSpinner = (disableSpins = false) => {
  if(!globalSpinner) globalSpinner = new spin({ color: 'white', succeedColor: 'white', spinner, disableSpins});
  return globalSpinner;
}
spins = getGlobalSpinner(false)
var forks = (id, text) => {
	spins.add(id, {text: text})
	}
const info = (id, text) => {
spins.update(id, {text: text})
}
const start = (id, text) => {
spins.add(id, {text: text})
}
const success = (id, text) => {
 spins.succeed(id, {text: text})

 }

const close = (id, text) => {
 spins.fail(id, {text: text})
}

blocked = []

const sleep = async (ms) => {
return new Promise(resolve => setTimeout(resolve, ms));
}

require('./Farid.js')
nocache('./Farid.js', module => console.log(color(`${module} is now update!`,'greenyellow')))

const starts = async (client = new WAConnection()) => {
console.log('Starting bot...')
client.version = [2, 2119, 6]
client.logger.level = 'warn'
console.log(color(figlet.textSync(`AKIRAA`, {
font: 'Standard',
horizontalLayout: 'default',
vertivalLayout: 'default',
width: 60,
whitespaceBreak: false
}), 'red'))
client.on('qr', () => {
console.log(color('[','white'), color('!','red'), color(']','white'), color('QR KODE SIAP UNTUK DI SCAN'))
})
fs.existsSync('./session.json') && client.loadAuthInfo('./session.json')
client.on('connecting', () => {
console.log(FarzLog('wait....'))
})
client.on('open', () => {
console.log(FarzLog('Tersambung....'))
}) 
await client.connect({timeoutMs: 30*1000})
fs.writeFileSync('./session.json', JSON.stringify(client.base64EncodedAuthInfo(), null, '\t'))

client.on('ws-close', () => {
console.log(FarzLog('Koneksi terputus, mencoba menghubungkan kembali..'))
})
client.on('close', async ({ reason, isReconnecting }) => {
console.log(FarzLog('Terputus, Alasan :' + reason + '\nMencoba mengkoneksi ulang :' + isReconnecting))
if (!isReconnecting) {
console.log(FarzLog('Connect To Phone Rejected and Shutting Down.'))
}
})

client.on('chat-update', async (message) => {
require('./Farid.js')(client, message)
})


try {
client.on('group-participants-update', async (anu) => {
if (anu.action == 'add') {
if (anu.participants[0] === client.user.jid){
client.updatePresence(anu.jid, Presence.composing)
const buttons = [
{buttonId: `.menu`, buttonText: {displayText: '⋮☰ 𝐌𝐄𝐍𝐔'}, type: 1},
{buttonId: `.owner`, buttonText: {displayText: '👑 𝐎𝐖𝐍𝐄𝐑'}, type: 1}
]
const buttonMessage = {
headerType: "IMAGE",
contentText: `Hai, Aku ${namabot}`,
footerText: `Hallo Semuaa 👋`,
buttons: buttons,
headerType: 1
}
await client.sendMessage(anu.jid, buttonMessage, MessageType.buttonsMessage)
}}
if (anu.action == 'promote') {
const mdata = await client.groupMetadata(anu.jid)
num = anu.participants[0]
console.log(anu)
teks = `─ 「 *PROMOTE DETECT* 」 ─

⬡ *USER :* @${num.split('@')[0]}
⬡ *NOMOR :* ${num.replace('@s.whatsapp.net', '')}
⬡ *GRUP :* ${mdata.subject}`
const buttons = [{buttonId: ' ', buttonText: {displayText: 'SELAMAT 🎉'}, type: 1}]
const buttonMessage = {
headerType: "IMAGE",
contentText: teks,
footerText: 'Cieee Jadi Admin 🎉',
buttons: buttons,
headerType: 1
}
await client.sendMessage(mdata.id, buttonMessage, MessageType.buttonsMessage, {contextInfo: {"mentionedJid": [num]}})
} else if (anu.action == 'demote') {
num = anu.participants[0]
const mdata = await client.groupMetadata(anu.jid)
console.log(anu)
teks = `─ 「 *DEMOTE DETECT* 」 ─

⬡ *USER :* @${num.split('@')[0]}
⬡ *NOMOR :* ${num.replace('@s.whatsapp.net', '')}
⬡ *GRUP :* ${mdata.subject}`
const buttons = [{buttonId: ' ', buttonText: {displayText: 'SELAMAT 🎉'}, type: 1}]
const buttonMessage = {
headerType: "IMAGE",
contentText: teks,
footerText: 'Yang Sabar Yaaa 💪',
buttons: buttons,
headerType: 1
}
await client.sendMessage(mdata.id, buttonMessage, MessageType.buttonsMessage, {contextInfo: {"mentionedJid": [num]}})
}
if (!JSON.parse(fs.readFileSync('./database/welcome.json')).includes(anu.jid)) return
const mdata = await client.groupMetadata(anu.jid)
console.log(anu.participants+' '+anu.action)
if (anu.action == 'add') {
num = anu.participants[0]
try {
EzEz = await client.getProfilePicture(`${num.split('@')[0]}@c.us`)
} catch {
EzEz = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
memeg = mdata.participants.length
teks = `*Hai @${num.split('@')[0]} 👋*
*❏ Welcome In Group :*
*├─ ${mdata.subject}*
*├─ Intro Dulu Kak*
*├─ ❏ Nama :*
*├─ ❏ Umur :*
*├─ ❏ Hobi :*
*├─ ❏ Asal Kota :*
*└─ ❏ Jenis Kelamin :*`
buff  = await getBuffer(`http://hadi-api.herokuapp.com/api/card/welcome?nama=${num.split('@')[0]}&descriminator=404&memcount=${memeg} &gcname=${encodeURI(mdata.subject)}&pp=${EzEz}&bg=https://i.ibb.co/mHtC5V5/75a0537f7e23.jpg`)
const gambraa = (await client.prepareMessageMedia(buff,'imageMessage')).imageMessage
const buttonsss = [
{buttonId: ' ', buttonText: {displayText: 'SELAMAT DATANG 👋'}, type: 1},
]
const buttonsMessage = {
contentText: teks,
buttons: buttonsss,
footerText: `Semoga Betah Yha~~`,
headerType: 4,
imageMessage: gambraa
}
await client.sendMessage(mdata.id, buttonsMessage, MessageType.buttonsMessage, {contextInfo: {"mentionedJid": [num]}})
} else if (anu.action == 'remove') {
num = anu.participants[0]
teks = `Selamat Tinggal *@${num.split('@')[0]}* 👋`
const buttons = [{buttonId: ' ', buttonText: {displayText: 'Byee 👋'}, type: 1}]
const buttonMessage = {
headerType: "IMAGE",
contentText: teks,
footerText: `${num.split('@')[0]} OUT!!`,
buttons: buttons,
headerType: 1
}
await client.sendMessage(mdata.id, buttonMessage, MessageType.buttonsMessage, {contextInfo: {"mentionedJid": [num]}})
}
})
client.on('group-update', async (anu) => {
metdata = await client.groupMetadata(anu.jid)
if(anu.announce == 'false'){
teks = `─ 「 *GROUP OPEN* 」 ─\n\n\`\`\`Group Telah Dibuka Oleh Admin!\`\`\``
client.sendMessage(metdata.id, teks, MessageType.text)
}
else if(anu.announce == 'true'){
teks = `─ 「 *GROUP CLOSE* 」 ─\n\n\`\`\`Group telah ditutup oleh admin\`\`\``
client.sendMessage(metdata.id, teks, MessageType.text)
}
else if(!anu.desc == ''){
tag = anu.descOwner.split('@')[0] + '@s.whatsapp.net'
teks = `─「 *GROUP DESCRIPTION CHANGE* 」 ─

Deskripsi Group telah diubah
oleh Admin @${anu.descOwner.split('@')[0]}

*DESKRIPSI BARU :* 
${anu.desc}`
client.sendMessage(metdata.id, teks, MessageType.text, {contextInfo: {"mentionedJid": [tag]}})
}
else if(anu.restrict == 'false'){
teks = `─ 「 *GROUP SETTING CHANGE* 」 ─\n\n\`\`\`Edit Group info telah dibuka untuk member\nSekarang semua member dapat mengedit info Group Ini\`\`\``
client.sendMessage(metdata.id, teks, MessageType.text)
console.log(`-  Group Setting Change  - In ${metdata.subject}`)
}
else if(anu.restrict == 'true'){
teks = `─ 「 *GROUP SETTING CHANGE* 」 ─\n\n\`\`\`Edit Group info telah ditutup untuk member\nSekarang hanya admin group yang dapat mengedit info Group Ini\`\`\``
client.sendMessage(metdata.id, teks, MessageType.text)
console.log(`-  Group Setting Change  - In ${metdata.subject}`)
}
})
antidel = true
client.on('message-delete', async (m) => {
if (m.key.remoteJid == 'status@broadcast') return
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
 }
const from = m.key.remoteJid
const isGroup = m.key.remoteJid.endsWith('@g.us')
const sender = isGroup ? m.participant : m.key.remoteJid
const dataRevoke = JSON.parse(fs.readFileSync('./database/antidelete.json'))
const dataCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked.json'))
const dataBanCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked-banlist.json'))
const isRevoke = !isGroup ? true : isGroup ? dataRevoke.includes(from) : false
const isCtRevoke = isGroup ? true : dataCtRevoke.data ? true : false
const isBanCtRevoke = isGroup ? true : !dataBanCtRevoke.includes(sender) ? true : false
if (!isRevoke) return
if (!isCtRevoke) return
if (!isBanCtRevoke) return
if (!m.key.fromMe && m.key.fromMe) return
if (antidel === false) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss')
let d = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let calender = d.toLocaleDateString(locale, {
day: 'numeric',
month: 'long',
year: 'numeric'
})
const type = Object.keys(m.message)[0]
teks = `── 「 *ANTI DELETE* 」 ──

⬡ *DARI  : @${m.participant.split("@")[0]}*
⬡ *NOMOR  : ${m.participant.split("@")[0]}*
⬡ *TANGGAL  : ${calender}*`
if (isGroup) buttons = [{buttonId: `.antidelete off`, buttonText: {displayText: 'DISABLE ANTIDELETE'}, type: 1}]
if (!isGroup) buttons = [{buttonId: `.antidelete ctoff`, buttonText: {displayText: 'DISABLE ANTIDELETE'}, type: 1}]
const buttonMessage = {
headerType: "IMAGE",
contentText: teks,
footerText: 'Loh, Kok Di Hapus..?',
buttons: buttons,
headerType: 1
}
await client.sendMessage(m.key.remoteJid, buttonMessage, MessageType.buttonsMessage, {quoted: m.message, contextInfo: { mentionedJid: parseMention(teks) }})
client.copyNForward(m.key.remoteJid, m.message)
})
} catch (e) {
console.log('Error : %s', color(e, 'red'))
}
client.on('CB:action,,call', async json => {
const callerId = json[2][0][1].from;
client.sendMessage(callerId, "*「 CALL DETECTED 」*\n\nMAAF, KAMU AKAN DI BLOCK OTOMATIS\n\nAuto Block System ~", MessageType.text)
client.sendMessage(`6281227961957@s.whatsapp.net`, `*◯ PANGGILAN ◯*\n\nCalling Detected From @${callerId.split("@")[0]} >_<`, MessageType.text, { contextInfo: {"mentionedJid": [callerId]}})
await sleep(4000)
await client.blockUser(callerId, "add")
})
client.on('CB:action,,battery', json => {
global.batteryLevelStr = json[2][0][1].value
global.batterylevel = parseInt(batteryLevelStr)
battre = batterylevel
if(json[2][0][1].live == 'true') {
charging = true
} else if (json[2][0][1].live == 'false') {
charging = false
}
const chargi = json[2][0][1].live
baterai.cas = chargi
})
global.batrei = global.batrei ? global.batrei : []
client.on('CB:action,,battery', json => {
const batteryLevelStr = json[2][0][1].value
const batterylevel = parseInt(batteryLevelStr)
global.batrei.push(batterylevel)
})
client.on('CB:Blocklist', json => {
if (blocked.length > 2) return
for (let i of json[1].blocklist) {
blocked.push(i.replace('c.us','s.whatsapp.net'))
  }
})
       
}
function nocache(module, cb = () => { }) {
console.log(color('MODULE','white'), color(`'${module}'`,'greenyellow'))
fs.watchFile(require.resolve(module), async () => {
await uncache(require.resolve(module))
cb(module)
})
}
function uncache(module = '.') {
return new Promise((resolve, reject) => {
try {
delete require.cache[require.resolve(module)]
resolve()
} catch (e) {
reject(e)
}
})
}
starts()
