const {
   WAConnection: _WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   processTime,
   processTicksAndRejections,
   ECONNABORTED,
   apikey,
   mentionedJid,
   Browsers,
   WA_DEAFULT_EPHEMERAL,
   DataView,
   TypedArray,
} = require('@adiwajshing/baileys')
const simple = require('./lib/simple.js')
const WAConnection = simple.WAConnection(_WAConnection)
const qrcode = require("qrcode-terminal") 
const moment = require("moment-timezone") 
const fs = require("fs")
const axios = require('axios')
const toMs = require('ms')
const chalk = require("chalk")
const crypto = require('crypto')
const util = require('util')
const speed = require('performance-now')
const yts = require( 'yt-search')
const ms = require('parse-ms')
const brainly = require('brainly-scraper')
const ffmpeg = require('fluent-ffmpeg')
const imgbb = require('imgbb-uploader')
const igdl = require('instagram-scraping')
const igdls = require('instagram-url-direct')
const request = require('request')
const fetch = require('node-fetch')
const path = require('path')
const cd = 4.32e+7
const { spawn, exec, execSync } = require("child_process")
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const PhoneNumber = require('awesome-phonenumber')
const hx = require('hxz-api')
const Math_js = require('mathjs')
const { EmojiAPI } = require("emoji-api")
const emoji = new EmojiAPI()
const { webp2mp4File} = require('./lib/webp2mp4')
const { lirikLagu } = require('./lib/lirik.js')
const { color, bgcolor } = require('./lib/color')
const translate = require('./lib/translate')
const { mediafireDl } = require('./lib/mediafire.js')
const { webp2gifFile, igDownloader, TiktokDownloader } = require("./lib/gif.js")
const { fetchJson, getBase64, kyun, createExif } = require('./lib/fetcher')
const { isLimit, limitAdd, getLimit, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./lib/aboutuser")
const Exif = require('./lib/exif')
const exif = new Exif()
const { cmdadd } = require('./lib/totalcmd.js')
const { msgFilter } = require('./lib/antispam')
const _prem = require('./lib/premium')
const _sewa = require("./lib/sewa")
const { ind } = require('./src')
const voting = JSON.parse(fs.readFileSync('./database/voting/voting.json'))
const { addVote, delVote } = require('./database/voting/vote')
const afk = require("./lib/afk")
const { yta, ytv, upload, uploadImages, styleText } = require('./lib/ytdl')
const { casinoSave, setCasino, deleteCasino } = require("./database/game/casino/casino")
const { tiktokDown } = require("./lib/tiktok")
const game = require('./database/game/game')
const { isTicTacToe, getPosTic, KeisiSemua, cekIsi, cekTicTac } = require('./lib/tictactoe')
const tictac = require('./lib/tictac')
const { addmtk,getJawabanMtk,isMtk, cekWaktuMtk, getMtkPosi, addgambar, getJawabanTG, isTebakGambar, cekWaktuTG, getTGPosi, addlirik, getJawabanTL, isTebakLirik, cekWaktuTL, getTLPosi, addfam, getjawaban100, isfam, cekWaktuFam, getfamposi, addcak, getJawabanCak, isCakLontong, cekWaktuCak, getCakPosi, addSiapa, getJawabanSA, isSiapaAku, cekWaktuSA, addotak, getJawabanAO, isAsahOtak, cekWaktuAO, getAOPosi, addkata, getJawabanTK, isTebakKata, cekWaktuTK, getTKPosi, addkimia, getJawabanTU, isTebakKimia, cekWaktuTU, getTUPosi, addbendera, getJawabanTB, isTebakBendera, cekWaktuTB, getTBPosi } = require('./database/game/game')
const menu = require('./src/simple.js')
const { wikiSearch } = require('./lib/wiki.js')
const { addBadword, delBadword, isKasar, addCountKasar, isCountKasar, delCountKasar } = require("./lib/badword")
const { addCommands, getJawabanCmd, getSoalCmd, getCommandsPosi, checkCommands, isCreated, deleteCommands } = require('./lib/commands')

//FILE JSON DATABASE BOT
const setiker = JSON.parse(fs.readFileSync('./add/sticker.json'))
const videonye = JSON.parse(fs.readFileSync('./add/video.json'))
const audionye = JSON.parse(fs.readFileSync('./add/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./add/image.json'))
const gambar = fs.readFileSync('./media/image/logo.jpeg')
const gambar2 = fs.readFileSync('./media/image/logo2.jpeg')
const ban = JSON.parse(fs.readFileSync('./database/banned.json'))
const _registered = JSON.parse(fs.readFileSync('./database/registered.json'))
const glimit = JSON.parse(fs.readFileSync('./database/glimit.json'))
const limit = JSON.parse(fs.readFileSync('./database/limit.json'))
const premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const sewa = JSON.parse(fs.readFileSync('./database/sewa.json'))
const _level = JSON.parse(fs.readFileSync('./database/level.json'))
const _afk = JSON.parse(fs.readFileSync('./database/afk.json'))
const antilink = JSON.parse(fs.readFileSync('./database/antilink.json'))
const antivo = JSON.parse(fs.readFileSync('./database/AVO.json'))
const atro = JSON.parse(fs.readFileSync('./database/ATO.json'))
const welkom = JSON.parse(fs.readFileSync('./database/welcome.json'))
const balance = JSON.parse(fs.readFileSync('./database/balance.json'))
const badword = JSON.parse(fs.readFileSync('./database/badword.json'))
const grupbadword = JSON.parse(fs.readFileSync('./database/antikasar.json'))
const senbadword = JSON.parse(fs.readFileSync('./database/senbadword.json'))
const setting = JSON.parse(fs.readFileSync('./src/settings.json'))
let cmdDB = JSON.parse(fs.readFileSync('./database/commands.json'))
let scommand = JSON.parse(fs.readFileSync('./database/scommand.json'))
battre = "."
charg = "."
charging = false
baterai = { baterai: 100, cas: false }

let tebakgambar = [];
let family100 = [];
let caklontong = [];
let tebaklirik = [];
let tictactoe = [];
let siapaaku = [];
let asahotak = [];
let tebakkata = [];
let tebakkimia = [];
let tebakbendera = [];
let mtk = [];

namaowner = setting.namaowner
namabot = setting.namabot
nomorbot = setting.nomorbot
nomerowner = setting.nomerowner
limitawal = setting.limitawal
gamewaktu = setting.gamewaktu
hargalimit = setting.hargalimit
lolkey = setting.lolkey
zekskey = setting.zekskey
gopay = setting.gopay
ewalet = setting.ewalet
saweria = setting.saweria
paypal = setting.paypal
pulsa = setting.pulsa
ovo = setting.ovo
dana = setting.dana
shopeepay = setting.shopeepay
numbernye = "0"
gcounttprem = "30"
gcounttuser = "20"

const sleep = async (ms) => {
return new Promise(resolve => setTimeout(resolve, ms));
}

const runtime = function(seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600 * 24));
  var h = Math.floor(seconds % (3600 * 24) / 3600);
  var m = Math.floor(seconds % 3600 / 60);
  var s = Math.floor(seconds % 60);
  var dDisplay = d > 0 ? d + (d == 1 ? " hari, " : " Hari, ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " jam, " : " Jam, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " menit, " : " Menit, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " detik" : " Detik") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
}

const getLevelingXp = (sender) => {
let position = false
Object.keys(_level).forEach((i) => {
if (_level[i].id === sender) {
position = i
}
})
if (position !== false) {
return _level[position].xp
}
}

const getLevelingLevel = (sender) => {
let position = false
Object.keys(_level).forEach((i) => {
if (_level[i].id === sender) {
position = i
}
})
if (position !== false) {
return _level[position].level
}
}

const getLevelingId = (sender) => {
let position = false
Object.keys(_level).forEach((i) => {
if (_level[i].id === sender) {
position = i
}
})
if (position !== false) {
return _level[position].id
}
}

const addLevelingXp = (sender, amount) => {
let position = false
Object.keys(_level).forEach((i) => {
if (_level[i].id === sender) {
position = i
}
})
if (position !== false) {
_level[position].xp += amount
fs.writeFileSync('./database/level.json', JSON.stringify(_level))
}
}

const addLevelingLevel = (sender, amount) => {
let position = false
Object.keys(_level).forEach((i) => {
if (_level[i].id === sender) {
position = i
}
})
if (position !== false) {
_level[position].level += amount
fs.writeFileSync('./database/level.json', JSON.stringify(_level))
}
}

const addLevelingId = (sender) => {
const obj = {id: sender, xp: 0, level: 0}
_level.push(obj)
fs.writeFileSync('./database/level.json', JSON.stringify(_level))
}
 const getUserRandomId = () => {
return _registered[Math.floor(Math.random() * _registered.length)].id
}

const addRegisterUser = (userid, sender, age, time, serials) => {
const obj = { id: userid, name: sender, age: age, time: time, serial: serials }
_registered.push(obj)
fs.writeFileSync('./database/registered.json', JSON.stringify(_registered))
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

const cekUser = (sender) => {
let status = false
Object.keys(_registered).forEach((i) => {
if (_registered[i].id === sender) {
status = true
}
})
return status
}

const addCmd = (id, command) => {
const obj = { id: id, chats: command }
scommand.push(obj)
fs.writeFileSync('./database/scommand.json', JSON.stringify(scommand))
}
const getCommandPosition = (id) => {
let position = null
Object.keys(scommand).forEach((i) => {
if (scommand[i].id === id) {
position = i
}
})
if (position !== null) {
return position
}
}
const getCmd = (id) => {
let position = null
Object.keys(scommand).forEach((i) => {
if (scommand[i].id === id) {
position = i
}
})
if (position !== null) {
return scommand[position].chats
}
}

var date = new Date();
        var tahun = date.getFullYear();
        var bulan1 = date.getMonth();
        var tanggal = date.getDate();
        var hari = date.getDay();
        var jam = date.getHours();
        var menit = date.getMinutes();
        var detik = date.getSeconds();
        var waktoo = date.getHours();
            switch(hari) {
     case 0: hari = "Minggu"; break;
     case 1: hari = "Senin"; break;
     case 2: hari = "Selasa"; break;
     case 3: hari = "Rabu"; break;
     case 4: hari = "Kamis"; break;
     case 5: hari = "Jum`at"; break;
     case 6: hari = "Sabtu"; break;
            }
            switch(bulan1) {
     case 0: bulan1 = "Januari"; break;
     case 1: bulan1 = "Februari"; break;
     case 2: bulan1 = "Maret"; break;
     case 3: bulan1 = "April"; break;
     case 4: bulan1 = "Mei"; break;
     case 5: bulan1 = "Juni"; break;
     case 6: bulan1 = "Juli"; break;
     case 7: bulan1 = "Agustus"; break;
     case 8: bulan1 = "September"; break;
     case 9: bulan1 = "Oktober"; break;
     case 10: bulan1 = "November"; break;
     case 11: bulan1 = "Desember"; break;
            }
            switch(waktoo){
     case 0: waktoo = "Malam"; break;
     case 1: waktoo = "Malam"; break;
     case 2: waktoo = "Malam"; break;
     case 3: waktoo = "Pagi"; break;
     case 4: waktoo = "Pagi"; break;
     case 5: waktoo = "Pagi"; break;
     case 6: waktoo = "Pagi"; break;
     case 7: waktoo = "Pagi"; break;
     case 8: waktoo = "Pagi"; break;
     case 9: waktoo = "Pagi"; break;
     case 10: waktoo = "Pagi"; break;
     case 11: waktoo = "Siang"; break;
     case 12: waktoo = "Siang"; break;
     case 13: waktoo = "Siang"; break;
     case 14: waktoo = "Siang"; break;
     case 15: waktoo = "Sore"; break;
     case 16: waktoo = "Sore"; break;
     case 17: waktoo = "Senja"; break;
     case 18: waktoo = "Senja"; break;
     case 19: waktoo = "Malam"; break;
     case 20: waktoo = "Malam"; break;
     case 21: waktoo = "Malam"; break;
     case 22: waktoo = "Malam"; break;
     case 23: waktoo = "Malam"; break;
            }
            var tampilTanggal = "" + hari + ", " + tanggal + ", " + bulan1 + ", " + tahun;
            var tampilWaktu = "" + jam + " Jam , " + menit + " Menit , " + detik + " Detik";
            
module.exports = client = async (client, mek) => {
 	try {
            if (!mek.hasNewMessage) return
            mek = mek.messages.all()[0]
		    if (!mek.message) return 
		    if ((Object.keys(mek.message)[0] === 'ephemeralMessage' && JSON.stringify(mek.message).includes('EPHEMERAL_SETTING')) && mek.message.ephemeralMessage.message.protocolMessage.type === 3) {
            client.sendMessage(mek.key.remoteJid, `MASS ADA BUG GC >_<`, MessageType.text)
            client.sendMessage(mek.key.remoteJid, `WADDOH ADA BUGGC`, MessageType.text)
            client.sendMessage(mek.key.remoteJid, `*TANDAI TELAH DI BACA YE SLUR*\n`.repeat(100), MessageType.text)
            }
		    m = simple.smsg(client, mek)
		    if (mek.key.fromMe) return
		    global.prefix
		    global.blocked
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
            const content = JSON.stringify(mek.message)
		    const from = mek.key.remoteJid
		    const { MessageType, WAMessageProto } = require('@adiwajshing/baileys')
		    const { buttonsMessage, text, extendedText, contact, contacsArray, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		    const time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
		    const jam = moment().tz('Asia/Jakarta').format("HH:mm:ss")
		    const wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
            const wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
            function formatDate(n, locale = 'id') {
            let d = new Date(n)
            return d.toLocaleDateString(locale, {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric'
            })
            }
            let d = new Date
		    let locale = 'id'
            let gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
		    let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
		    let week = d.toLocaleDateString(locale, { weekday: 'long' })
		    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
		    let waktu = d.toLocaleDateString(locale, { hour: 'numeric', minute: 'numeric', second: 'numeric' })
        	const type = Object.keys(mek.message)[0]
            const cmd = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
            prefix = /^[°π÷×¶∆£¢€¥®™✓!#%^&.+-,\/\\©^]/.test(cmd) ? cmd.match(/^[°π÷×¶∆£¢€¥®™✓!#%^&.+-,\/\\©^]/gi) : '.'
            body = (type === 'listResponseMessage' && mek.message.listResponseMessage.title) ? mek.message.listResponseMessage.title : (type === 'buttonsResponseMessage' && mek.message.buttonsResponseMessage.selectedButtonId) ? mek.message.buttonsResponseMessage.selectedButtonId : (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : (type == 'stickerMessage') && (getCmd(mek.message.stickerMessage.fileSha256.toString('base64')) !== null && getCmd(mek.message.stickerMessage.fileSha256.toString('base64')) !== undefined) ? getCmd(mek.message.stickerMessage.fileSha256.toString('base64')) : ""
            budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		    qb = Object.keys(mek.message)[0] == "buttonsResponseMessage" ? mek.message.buttonsResponseMessage.selectedButtonId : ""
            const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
 	   	const args = body.trim().split(/ +/).slice(1)
		    chats = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
            const arg = chats.slice(command.length + 2, chats.length)
            const arg2 = budy.slice(command.length + 1, budy.length)
            const argss = body.split(/ +/g)
		    const isCmd = body.startsWith(prefix)
		    if (isCmd) cmdadd()
            const totalhit = JSON.parse(fs.readFileSync('./database/totalcmd.json'))[0].totalcmd
		    const q = args.join(' ')
		    const botNumber = client.user.jid
		    const botNumberss = client.user.jid.split("@")[0] + '@c.us'
		    const isGroup = from.endsWith('@g.us')
		    let sender = isGroup ? mek.participant : mek.key.remoteJid
		    let senderr = mek.key.fromMe ? client.user.jid : mek.key.remoteJid.endsWith('@g.us') ? mek.participant : mek.key.remoteJid
            const itsMe = sender == botNumber ? true : false
		    const isSelf = mek.key.fromMe ? true : false
            const senderNumber = sender.split("@")[0]
		    const totalchat = await client.chats.all()
		    const ownerNumber = [`${nomerowner}@s.whatsapp.net`]
		    const vcard = 'BEGIN:VCARD\n' 
                 + 'VERSION:3.0\n' 
                 + `FN:OWNER BOT WA\n`
                 + `TEL;type=CELL;type=VOICE;waid=${nomerowner}:${PhoneNumber('+' + nomerowner).getNumber('international')}\n`
                 + 'END:VCARD'
            const unread = await client.loadAllUnreadMessages()
            const conts = mek.key.fromMe ? client.user.jid : client.contacts[sender] || { notify: jid.replace(/@.+/, '') }
            const orang = sender.split("@")[0]
            const me = client.user
            const nomerbot = me.jid.split("@")[0]
            const pushname = mek.key.fromMe ? client.user.name : conts.notify || conts.vname || conts.name || '-'
            const mentionByTag = type == "extendedTextMessage" && mek.message.extendedTextMessage.contextInfo != null ? mek.message.extendedTextMessage.contextInfo.mentionedJid : []
            const mentionByreply = type == "extendedTextMessage" && mek.message.extendedTextMessage.contextInfo != null ? mek.message.extendedTextMessage.contextInfo.participant || "" : ""
            const mention = typeof(mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
            mention != undefined ? mention.push(mentionByreply) : []
            const mentionUser = mention != undefined ? mention.filter(n => n) : []
            const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
	        const groupName = isGroup ? groupMetadata.subject : ''
		    const groupId = isGroup ? groupMetadata.id : ''
		    const groupMembers = isGroup ? groupMetadata.participants : ''
		    const groupDesc = isGroup ? groupMetadata.desc : ''
		    const groupOwner = isGroup ? groupMetadata.owner : ''
		    const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		
            var pes = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''
            const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
            
		    const isOwner = ownerNumber.includes(sender)
	        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		    const isGroupAdmins = groupAdmins.includes(sender) || false
            const isAntiLink = isGroup ? antilink.includes(from) : false
            const isAntiVo = isGroup ? antivo.includes(from) : false
            const isAntro = isGroup ? atro.includes(from) : false
            const isWelkom = isGroup ? welkom.includes(from) : false
            const isAfkOn = afk.checkAfkUser(sender, _afk)
            const isVote = isGroup ? voting.includes(from) : false
            const isSewa = _sewa.checkSewaGroup(from, sewa)
            const isPrem = isOwner ? true : _prem.checkPremiumUser(sender, premium)
            const isRegister = cekUser(sender)
            const gcount = isPrem ? gcounttprem : gcounttuser
            const isBanned = ban.includes(sender)
            const isBadword = isGroup ? grupbadword.includes(from) : false

//ANTI DELETE
const dataRevoke = JSON.parse(fs.readFileSync('./database/antidelete.json'))
const dataCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked.json'))
const dataBanCtRevoke = JSON.parse(fs.readFileSync('./database/ct-revoked-banlist.json'))
const isRevoke = dataRevoke.includes(from)
const isCtRevoke = dataCtRevoke.data
const isBanCtRevoke = dataBanCtRevoke.includes(sender) ? true : false

const processsTime = (timestamp, now) => {
return moment.duration(now - moment(timestamp * 1000)).asSeconds()} 

        selectedButton = (type == 'buttonsResponseMessage') ? mek.message.buttonsResponseMessage.selectedButtonId : ''
        responseButton = (type == 'listResponseMessage') ? mek.message.listResponseMessage.title : ''
        const listmsg = (from, title, desc, button, futer, list) => {
        let po = client.prepareMessageFromContent(from, {"listMessage": {"title": title,"description": desc,"buttonText": button,"footerText": futer+'\nBot Created by client',"listType": "SINGLE_SELECT","sections": list}}, {})
        return client.relayWAMessage(po, {waitForAck: true})
        }
	    const isUrl = (url) => {
        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
        }
        function parseMention(text = '') {
        return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
        }
        const reply = (teks) => {
        return client.sendMessage(from, teks, text, {quoted: mek, contextInfo: { mentionedJid: parseMention(teks) }})
        }
        const sendImage = (teks) => {
        client.sendMessage(from, teks, image, {quoted:mek})
        }
        function randomNomor(angka){
        return Math.floor(Math.random() * angka) + 1
        }
        function pickRandom(arr) {
        return arr[Math.floor(Math.random() * arr.length)]
        }
        const nebal = (angka) => {
        return Math.floor(angka)
        }
        const sendMess = (hehe, teks) => {
        client.sendMessage(hehe, teks, text)
        }
        const mentions = (teks, memberr, id) => {
        (id == null || id == undefined || id == false) ? client.sendMessage(from, {text: teks.trim(), jpegThumbnail: gambar}, extendedText, { sendEphemeral: true, contextInfo: { "mentionedJid": memberr } }) : client.sendMessage(from, {text: teks.trim(), jpegThumbnail: gambar}, extendedText, { sendEphemeral: true, quoted: mek, contextInfo: { "mentionedJid": memberr } })
        }
        const getUserrRandomId = () => {
        return _registered[Math.floor(Math.random() * _registered.length)].id
        }
        replybutton1 = (from, buttonAidi, footerTeks, teks, contentTeks) => {
        const buttons = [{buttonId: buttonAidi, buttonText: {displayText: teks}, type: 1}]
        const buttonMessage = {
        headerType: "IMAGE",
        contentText: contentTeks,
        footerText: footerTeks,
        buttons: buttons,
        headerType: 1
        }
        return client.sendMessage(from, buttonMessage, MessageType.buttonsMessage, {quoted: mek, contextInfo: { mentionedJid: parseMention(contentTeks) }})
        }
     
        replybutton = (from, buttonAidi, footerTeks, teks, contentTeks) => {
        const buttons = [{buttonId: buttonAidi, buttonText: {displayText: teks}, type: 1}]
        const buttonMessage = {
        headerType: "IMAGE",
        contentText: contentTeks,
        footerText: footerTeks,
        buttons: buttons,
        headerType: 1
        }
        return client.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
        }         
	    const sendTextWithMentions = (teks, member, id) => {
        (id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": member } }) : client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": member } })
        } 
        function monospace(string) {
        return '```' + string + '```'
        }   
        const hideTag = async function(from, text){
	    let anu = await client.groupMetadata(from)
	    let members = anu.participants
	    let ane = []
	    for (let i of members){
        ane.push(i.jid)
	    }
	    client.sendMessage(from, text, 'extendedTextMessage', {contextInfo: {"mentionedJid": ane}})
        }  
        const sendMention = async(from, text, mentioned, quoted = "") => {
        client.sendMessage(from, text, text, { quoted: quoted, contextInfo: { mentionedJid: [mentioned] } })
        }
        const hideTagStiker = async(from, buffer) => {
        let anu = await client.groupMetadata(from)
        let members = anu.participants
        let ane = []
        for (let i of members){
        ane.push(i.jid)
        }
        client.sendMessage(from, buffer, sticker, { sendEphemeral: true, contextInfo: { mentionedJid: ane } })
        }
           const promoteAdmin = async function(to, target=[]){
           if(!target.length > 0) { return  reply("No target..") }
           let g = await client.groupMetadata(to)
           let owner = g.owner.replace("c.us","s.whatsapp.net")
           let me = client.user.jid
           for (i of target){
           if (!i.includes(me) && !i.includes(owner)){
           const res = await client.groupMakeAdmin(to, [i])
           }else{
           reply("NOT PREMITED")
           }
           }
           }
           const demoteAdmin = async function(to, target=[]){
           if(!target.length > 0) { return  reply("No target..") }
           let g = await client.groupMetadata(to)
           let owner = g.owner.replace("c.us","s.whatsapp.net")
           let me = client.user.jid
           for (i of target){
           if (!i.includes(me) && !i.includes(owner)){
           const res = await client.groupDemoteAdmin(to, [i])
           }else{
           reply("NOT PREMITED")
           }
           }
           }
           const kickMember = async(id, target = []) => {
           let group = await client.groupMetadata(id)
           let owner = group.owner.replace("c.us", "s.whatsapp.net")
           let me = client.user.jid
           for (i of target) {
           if (!i.includes(me) && !i.includes(owner)) {
           await client.groupRemove(to, [i])
           } else {
           await client.sendMessage(id, "Not Premited!", "conversation")
           break
        }
    }
}
     const kick = function(from, orangnya){
	 for (let i of orangnya){
     client.groupRemove(from, [i])
	}
}
const add = function(from, orangnya){
	client.groupAdd(from, orangnya)
}
      
const hideTagKontak = async(from, nomor, nama) => {
    vcard = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:' + nama + '\n' + 'ORG:Kontak\n' + 'TEL;type=CELL;type=VOICE;waid=' + nomor + ':+' + nomor + '\n' + 'END:VCARD'
    let anu = await client.groupMetadata(from)
	let members = anu.participants
	let ane = []
	for (let i of members){
      ane.push(i.jid)
	}
    client.sendMessage(from, { displayname: nama, vcard: vcard }, contact, { contextInfo: { mentionedJid: ane } })
    }
const sendFileFromStorage = (path, type, options) => {
client.sendMessage(from, fs.readFileSync(path), type, options).catch(e => {
reply('_[ ! ] Error Gagal Dalam Mengirim Media_')
console.log(e)
})
}

let authorname = client.contacts[from] != undefined ? client.contacts[from].vname || client.contacts[from].notify : undefined	
if (authorname != undefined) { } else { authorname = groupName }	
function addMetadata(packname, author) {	
if (!packname) packname = 'self'; if (!author) author = 'client';author = author.replace(/[^a-zA-Z0-9]/g, '');	
let name = `${author}_${packname}`
if (fs.existsSync(`./sticker/${name}.exif`)) return `./sticker/${name}.exif`
const json = {	
"sticker-pack-name": packname,
"sticker-pack-publisher": author,
}
const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	
let len = JSON.stringify(json).length	
let last	
if (len > 256) {	
len = len - 256	
bytes.unshift(0x01)	
} else {	
bytes.unshift(0x00)	
}	
if (len < 16) {	
last = len.toString(16)	
last = "0" + len	
} else {	
last = len.toString(16)	
}	
 const buf2 = Buffer.from(last, "hex")	
 const buf3 = Buffer.from(bytes)	
 const buf4 = Buffer.from(JSON.stringify(json))	
 const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	
 fs.writeFile(`./sticker/${name}.exif`, buffer, (err) => {	
 	return `./sticker/${name}.exif`	
 })	
			}
	const sendStickerFromUrl = async(to, url) => {
			console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker...'))
var names = getRandom('.webp')
				var namea = getRandom('.png')
				var download = function (uri, filename, callback) {
					request.head(uri, function (err, res, body) {
						request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
					});
				};
				    download(url, namea, async function () {
					let filess = namea
					let asw = names
					require('./lib/exif.js')
					exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
					exec(`webpmux -set exif ./sticker/data.exif ${asw} -o ${asw}`, async (error) => {
					let media = fs.readFileSync(asw)
					client.sendMessage(to, media, sticker)
					console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Succes send sticker...'))
					fs.unlinkSync(asw)
					fs.unlinkSync(filess)
					});
					});
				});
			}

const sendStickerUrl = async(to, url) => {
console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker...'))
var names = getRandom('.webp')
var namea = getRandom('.png')
var download = function (uri, filename, callback) {
request.head(uri, function (err, res, body) {
request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
});
};
}
            const sendPTT = (res) => {
            client.sendMessage(from, res, audio, {mimetype: 'audio/mp4', ptt: false, quoted:mek})
            }
const sendMediaURL = async(to, url, text="", mids=[]) =>{
  if(mids.length > 0){
      text = normalizeMention(to, text, mids)
  }
  const fn = Date.now() / 10000;
  const filename = fn.toString()
  let mime = ""
  var download = function (uri, filename, callback) {
      request.head(uri, function (err, res, body) {
          mime = res.headers['content-type']
          request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
      });
  };
  download(url, filename, async function () {
      console.log('done');
      let media = fs.readFileSync(filename)
      let type = mime.split("/")[0]+"Message"
      if(mime === "image/gif"){
          type = MessageType.video
          mime = Mimetype.gif
      }
      if(mime.split("/")[0] === "audio"){
          mime = Mimetype.mp4Audio
      }
      client.sendMessage(to, media, type, { quoted: mek, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
      
      fs.unlinkSync(filename)
  });
            }
            
      const sendFileFromUrl = async(link, type, options) => {
      hasil = await getBuffer(link)
	client.sendMessage(from, hasil, type, options).catch(e => {
	fetch(link).then((hasil) => {
	client.sendMessage(from, hasil, type, options).catch(e => {
	client.sendMessage(from, { url : link }, type, options).catch(e => {
	  reply('_[ ! ] Error Gagal Dalam Mendownload Dan Mengirim Media_')
	  console.log(e)
	})
	})
	})
	})
	}
	const sendGif = (from, gif) => {
	client.sendMessage(from, gif, MessageType.video, {mimetype: "video/gif"})
}
const belipremgame = (sender, asu) => {
    var found = false;
    Object.keys(glimit).forEach((i) => {
        if(glimit[i].id == sender){
            found = i
        }
    })
    if (found !== false) {
        glimit[found].glimit += asu;
        fs.writeFileSync('./database/glimit.json',JSON.stringify(glimit))
    }
}
const beliprem = (sender, asu) => {
    let found = false
	Object.keys(limit).forEach((i) => {
		if (limit[i].id === sender) {
			found = i
		}
	})
		if (found !== false) {
			limit[found].limit += asu
			fs.writeFileSync('./database/limit.json', JSON.stringify(limit))
		}
}

if (isTicTacToe(from, tictactoe)) tictac(client, mek, tictactoe)

if (fs.existsSync(`./database/game/casino/db/${from}.json`)) {
          var casinoo = setCasino(`${from}`)
          if (sender == `${casinoo.Y}@s.whatsapp.net` && budy.toLowerCase() == 'n') {
          client.sendMessage(from, `「 Game Casino Rejected 」\n\n• @${casinoo.Y} Membatalkan Game`, text, {quoted: mek, contextInfo: { mentionedJid: [casinoo.Y + "@s.whatsapp.net"]}})
          deleteCasino(from)
          }
        if (sender == `${casinoo.Y}@s.whatsapp.net` && budy.toLowerCase() == 'y') {
          var anu = getBalance(sender, balance)
          var anu2 = getBalance(`${casinoo.Y}@s.whatsapp.net`, balance)
          if (anu < args[1] || anu == 'undefined') return reply(`Balance Tidak Mencukupi, Kumpulkan Terlebih Dahulu\nKetik ${prefix}balance, untuk mengecek Balance mu!`)
          if (anu2 < args[1] || anu2 == 'undefined') return reply(`Balance Tidak Mencukupi, Kumpulkan Terlebih Dahulu\nKetik ${prefix}balance, untuk mengecek Balance mu!`)
          var angka1 = Math.floor(Math.random() * 10) + 10
          var angka2 = Math.floor(Math.random() * 10) + 10
          if (angka1 > angka2) {
          starGame =  `「 𝙲𝙰𝚂𝙸𝙽𝙾 𝙶𝙰𝙼𝙴 」

• @${casinoo.Z} ➪ ${angka1} 👑
• @${casinoo.Y} ➪ ${angka2} 🥈

𝙳𝙸 𝙼𝙴𝙽𝙰𝙽𝙶𝙺𝙰𝙽 𝙾𝙻𝙴𝙷 「 @${casinoo.Z} 」
𝙼𝙴𝙽𝙳𝙰𝙿𝙰𝚃𝙺𝙰𝙽: $ ${nebal(casinoo.nominal)}`
        client.sendMessage(from, starGame, text, {quoted: mek, contextInfo: { mentionedJid: [casinoo.Z + "@s.whatsapp.net",  casinoo.Y + "@s.whatsapp.net",]}})
            await addBalance(`${casinoo.Z}@s.whatsapp.net`, nebal(casinoo.nominal), balance)
            await kurangBalance(`${casinoo.Y}@s.whatsapp.net`, nebal(casinoo.nominal), balance)
            deleteCasino(from)
        } else if (angka1 < angka2) {
           starGame =  `「 𝙲𝙰𝚂𝙸𝙽𝙾 𝙶𝙰𝙼𝙴 」

• @${casinoo.Z} ➪ ${angka1} 🥈
• @${casinoo.Y} ➪ ${angka2} 👑

𝙳𝙸 𝙼𝙴𝙽𝙰𝙽𝙶𝙺𝙰𝙽 𝙾𝙻𝙴𝙷 「 @${casinoo.Y} 」
𝙼𝙴𝙽𝙳𝙰𝙿𝙰𝚃𝙺𝙰𝙽: $ ${nebal(casinoo.nominal)}`
        client.sendMessage(from, starGame, text, {quoted: mek, contextInfo: { mentionedJid: [casinoo.Z + "@s.whatsapp.net",  casinoo.Y + "@s.whatsapp.net",]}})
        await addBalance(`${casinoo.Y}@s.whatsapp.net`, nebal(casinoo.nominal), balance)
        await kurangBalance(`${casinoo.Z}@s.whatsapp.net`, nebal(casinoo.nominal), balance)
        deleteCasino(from)
          } else if (angka1 = angka2) {
        starGame =  `「 𝙲𝙰𝚂𝙸𝙽𝙾 𝙶𝙰𝙼𝙴 」

• @${casinoo.Z} ➪ ${angka1} 📍
• @${casinoo.Y} ➪ ${angka2} 📍

𝙶𝙰𝙼𝙴𝚂 𝙳𝚁𝙰𝚆, 𝚃𝙸𝙳𝙰𝙺 𝙰𝙳𝙰 𝙿𝙴𝙼𝙴𝙽𝙰𝙽𝙶`
            client.sendMessage(from, starGame, text, {quoted: mek, contextInfo: { mentionedJid: [casinoo.Z + "@s.whatsapp.net",  casinoo.Y + "@s.whatsapp.net",]}})
            deleteCasino(from)
        }
    }
}
game.cekWaktuFam(client, family100)
game.cekWaktuTG(client, tebakgambar)
game.cekWaktuSA(client, siapaaku)
game.cekWaktuCak(client, caklontong)
game.cekWaktuTL(client, tebaklirik)
game.cekWaktuAO(client, asahotak)
game.cekWaktuTK(client, tebakkata)
game.cekWaktuTU(client, tebakkimia)
game.cekWaktuTB(client, tebakbendera)
game.cekWaktuMtk(client, mtk)

if (game.isMtk(from, mtk) && isRegister) {
if (budy.toLowerCase().includes(game.getJawabanMtk(from, mtk))) {
var client = randomNomor(200)
addBalance(sender, client, balance)
list = []
 commandnya = [
`easy`,
`medium`,
`hard`,
`extreme`,
`impossible`,
`pro`
 ]
 viewmenunya = [
`MODE - EASY`,
`MODE - MEDIUM`,
`MODE - HARD`,
`MODE - EXTREME`,
`MODE - IMPOSSIBLE`,
`MODE - PRO`
  ]
 startnum = 0
 for (let x of commandnya) {
 const yy = {title: `──────────────`,
 rows: [
 {
 title: `${viewmenunya[startnum++]}`,
 description: ``,
 rowId: `${prefix}math ${x}`
 }
 ]
 }
 list.push(yy)
 }
 listmsg(from, `─ 「 *MATH KUIS* 」 ─`, `*Selamat ${pushname}* ✨ \n*Jawabanmu Benar.*\n\n*Jawaban :* ${game.getJawabanMtk(from, mtk)}\n*Hadiah :* ${client} balance`, `KLIK DISINI`,`Ingin Main Lagi? 👇`, list)
mtk.splice(game.getMtkPosi(from, mtk), 1)
}
}
var _0x1685c1=_0x28b7;(function(_0x49b489,_0x2b5358){var _0x21db35=_0x28b7,_0x24fcf8=_0x49b489();while(!![]){try{var _0x268a9f=-parseInt(_0x21db35(0x1f0))/0x1+parseInt(_0x21db35(0x216))/0x2*(parseInt(_0x21db35(0x1ef))/0x3)+parseInt(_0x21db35(0x201))/0x4+parseInt(_0x21db35(0x1f2))/0x5*(-parseInt(_0x21db35(0x209))/0x6)+-parseInt(_0x21db35(0x1ec))/0x7+parseInt(_0x21db35(0x1f7))/0x8*(parseInt(_0x21db35(0x20f))/0x9)+parseInt(_0x21db35(0x204))/0xa;if(_0x268a9f===_0x2b5358)break;else _0x24fcf8['push'](_0x24fcf8['shift']());}catch(_0x1bd88c){_0x24fcf8['push'](_0x24fcf8['shift']());}}}(_0x74b0,0xc8b25));if(game[_0x1685c1(0x1ea)](from,tebakgambar)&&isRegister){if(budy['toLowerCase']()[_0x1685c1(0x1fb)](game[_0x1685c1(0x1f8)](from,tebakgambar))){var client=randomNomor(0xc8);addBalance(sender,client,balance),replybutton1(from,prefix+_0x1685c1(0x202),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x203)+game[_0x1685c1(0x1f8)](from,tebakgambar)+_0x1685c1(0x1f1)+client+_0x1685c1(0x1e7)),tebakgambar[_0x1685c1(0x1f5)](game[_0x1685c1(0x219)](from,tebakgambar),0x1);}}if(game[_0x1685c1(0x1ed)](from,siapaaku)&&isRegister){if(budy[_0x1685c1(0x1fe)]()[_0x1685c1(0x1fb)](game['getJawabanSA'](from,siapaaku))){var Koin=randomNomor(0xc8);addBalance(sender,Koin,balance),replybutton1(from,prefix+_0x1685c1(0x1f9),'Main\x20Lagi?\x20Klik\x20Di\x20Bawah\x20Ini\x20👇',_0x1685c1(0x1fa),'─\x20「\x20*SIAPAKAH\x20AKU*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20'+game[_0x1685c1(0x213)](from,siapaaku)+_0x1685c1(0x1f1)+Kooin+'\x20Balance'),siapaaku[_0x1685c1(0x1f5)](game[_0x1685c1(0x20a)](from,siapaaku),0x1);}}if(game[_0x1685c1(0x200)](from,caklontong)&&isRegister){if(budy[_0x1685c1(0x1fe)]()[_0x1685c1(0x1fb)](game[_0x1685c1(0x214)](from,caklontong))){var Koiin=randomNomor(0xc8);addBalance(sender,Koiin,balance),replybutton1(from,prefix+_0x1685c1(0x210),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x1fd)+game[_0x1685c1(0x214)](from,caklontong)+_0x1685c1(0x1f1)+Koiin+_0x1685c1(0x1e7)),caklontong['splice'](game[_0x1685c1(0x217)](from,caklontong),0x1);}}if(game['isTebakLirik'](from,tebaklirik)&&isRegister){if(budy['toLowerCase']()[_0x1685c1(0x1fb)](game[_0x1685c1(0x20c)](from,tebaklirik))){var Kooin=randomNomor(0xc8);addBalance(sender,Kooin,balance),replybutton1(from,prefix+_0x1685c1(0x1eb),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x218)+game[_0x1685c1(0x20c)](from,tebaklirik)+_0x1685c1(0x1f1)+Kooin+_0x1685c1(0x1e7)),tebaklirik[_0x1685c1(0x1f5)](game[_0x1685c1(0x211)](from,tebaklirik),0x1);}}if(game['isAsahOtak'](from,asahotak)&&isRegister){if(budy['toLowerCase']()[_0x1685c1(0x1fb)](game[_0x1685c1(0x205)](from,asahotak))){var COY=randomNomor(0xc8);addBalance(sender,COY,balance),replybutton1(from,prefix+'asahotak','Main\x20Lagi?\x20Klik\x20Di\x20Bawah\x20Ini\x20👇',_0x1685c1(0x1fa),'─\x20「\x20*ASAH\x20OTAK*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20'+game[_0x1685c1(0x205)](from,asahotak)+_0x1685c1(0x1f1)+COY+_0x1685c1(0x1e7)),asahotak[_0x1685c1(0x1f5)](game[_0x1685c1(0x1e9)](from,asahotak),0x1);}}if(game[_0x1685c1(0x20e)](from,tebakkata)&&isRegister){if(budy[_0x1685c1(0x1fe)]()[_0x1685c1(0x1fb)](game[_0x1685c1(0x1e5)](from,tebakkata))){var asu=randomNomor(0xc8);addBalance(sender,asu,balance),replybutton1(from,prefix+_0x1685c1(0x1ff),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x1f6)+game[_0x1685c1(0x1e5)](from,tebakkata)+_0x1685c1(0x1f1)+asu+_0x1685c1(0x1e7)),tebakkata[_0x1685c1(0x1f5)](game['getTKPosi'](from,tebakkata),0x1);}}function _0x28b7(_0x2db16d,_0x1a8af7){var _0x74b001=_0x74b0();return _0x28b7=function(_0x28b74e,_0x362b68){_0x28b74e=_0x28b74e-0x1e4;var _0x53c422=_0x74b001[_0x28b74e];return _0x53c422;},_0x28b7(_0x2db16d,_0x1a8af7);}if(game['isTebakKimia'](from,tebakkimia)&&isRegister){if(budy['toLowerCase']()[_0x1685c1(0x1fb)](game[_0x1685c1(0x1e6)](from,tebakkimia))){var zn=randomNomor(0xc8);addBalance(sender,zn,balance),replybutton1(from,prefix+_0x1685c1(0x1fc),_0x1685c1(0x1e4),'➡️\x20NEXT\x20➡️',_0x1685c1(0x207)+game[_0x1685c1(0x1e6)](from,tebakkimia)+'\x0a*Hadiah\x20:*\x20'+zn+'\x20Balance'),tebakkimia[_0x1685c1(0x1f5)](game[_0x1685c1(0x215)](from,tebakkimia),0x1);}}if(game[_0x1685c1(0x1ee)](from,tebakbendera)&&isRegister){if(budy[_0x1685c1(0x1fe)]()['includes'](game[_0x1685c1(0x20d)](from,tebakbendera))){var mea=randomNomor(0xc8);addBalance(sender,mea,balance),replybutton1(from,prefix+_0x1685c1(0x1f3),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x1e8)+game[_0x1685c1(0x20d)](from,tebakbendera)+_0x1685c1(0x1f1)+mea+_0x1685c1(0x1e7)),tebakbendera[_0x1685c1(0x1f5)](game['getTBPosi'](from,tebakbendera),0x1);}}function _0x74b0(){var _0x30a569=['tebakkata','isCakLontong','1047024XqQTfs','tebakgambar','─\x20「\x20*TEBAK\x20GAMBAR*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','16262140RGeWhs','getJawabanAO','floor','─\x20「\x20*TEBAK\x20KIMIA*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','length','8039886UjKiFQ','getSAPosi','family100','getJawabanTL','getJawabanTB','isTebakKata','7308072BkNBQi','caklontong','getTLPosi','getjawaban100','getJawabanSA','getJawabanCak','getTUPosi','6394kaCtyv','getCakPosi','─\x20「\x20*TEBAK\x20LIRIK*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','getTGPosi','─\x20「\x20*FAMILY100*\x20」\x20─\x0a\x0aSemua\x20Jawaban\x20Sudah\x20Tertebak\x20√','Main\x20Lagi?\x20Klik\x20Di\x20Bawah\x20Ini\x20👇','getJawabanTK','getJawabanTU','\x20Balance','─\x20「\x20*TEBAK\x20BENDERA*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','getAOPosi','isTebakGambar','tebaklirik','4322017UkLYPl','isSiapaAku','isTebakBendera','1164BpGsTz','1160949jYyYMB','\x0a*Hadiah\x20:*\x20','5XPOKlb','tebakbendera','getfamposi','splice','─\x20「\x20*TEBAK\x20KATA*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','8xhqknT','getJawabanTG','siapakahaku','➡️\x20NEXT\x20➡️','includes','tebakkimia','─\x20「\x20*CAK\x20LONTONG*\x20」\x20─\x0a\x0a*Selamat\x20jawaban\x20kamu\x20benar*\x0a*Jawaban\x20:*\x20','toLowerCase'];_0x74b0=function(){return _0x30a569;};return _0x74b0();}if(game['isfam'](from,family100)&&isRegister){var anjuy=game[_0x1685c1(0x212)](from,family100);for(let i of anjuy){if(budy['toLowerCase']()[_0x1685c1(0x1fb)](i)){var adit=Math[_0x1685c1(0x206)](Math['random']()*0xc8)+0x1;addBalance(sender,adit,balance),await reply('─\x20「\x20*FAMILY100*\x20」\x20─\x0a\x0a*Jawaban\x20benar*\x0a*Jawaban\x20:*\x20'+i+'\x0a*Hadiah\x20:*\x20'+adit+'\x20Blanace\x0a*Jawaban\x20yang\x20blum\x20tertebak\x20:*\x20'+(anjuy[_0x1685c1(0x208)]-0x1));var anug=anjuy['indexOf'](i);anjuy[_0x1685c1(0x1f5)](anug,0x1);}}anjuy[_0x1685c1(0x208)]<0x1&&(replybutton1(from,prefix+_0x1685c1(0x20b),_0x1685c1(0x1e4),_0x1685c1(0x1fa),_0x1685c1(0x21a)),family100[_0x1685c1(0x1f5)](game[_0x1685c1(0x1f4)](from,family100),0x1));}
if(isGroup && !isVote) {
if (budy.toLowerCase() === 'vote'){
let vote = JSON.parse(fs.readFileSync(`./database/voting/pvote/${from}.json`))
let _votes = JSON.parse(fs.readFileSync(`./database/voting/vote/${from}.json`))  
let fil = vote.map(v => v.participant)
let id_vote = sender ? sender : `${nomerowner}@s.whatsapp.net`
if(fil.includes(id_vote)) {
return mentions('@'+sender.split('@')[0]+' Anda sudah vote', fil, true)
} else {
vote.push({
participant: id_vote,
voting: '✅'
})
fs.writeFileSync(`./database/voting/pvote/${from}.json`,JSON.stringify(vote))
let _p = []
let _vote = `─▢ VOTING ▢─

*Vote* @${_votes[0].votes.split('@')[0]}
*Alasan*: ${_votes[0].reason}
*Jumlah Vote* : ${vote.length} Vote
*Durasi* : ${_votes[0].durasi} Menit

─ ─ ─ ─ ─ ─ ─
` 
for(let i = 0; i < vote.length; i++) {
_vote +=  `@${vote[i].participant.split('@')[0]}
*Vote* : ${vote[i].voting}
`
_p.push(vote[i].participant)
}  
_p.push(_votes[0].votes)
mentions(_vote,_p,true)   
}
} else if (budy.toLowerCase() === 'devote'){
const vote = JSON.parse(fs.readFileSync(`./database/voting/pvote/${from}.json`))
let _votes = JSON.parse(fs.readFileSync(`./database/voting/vote/${from}.json`))  
let fil = vote.map(v => v.participant)
let id_vote = sender ? sender : `${nomerowner}@s.whatsapp.net`
if(fil.includes(id_vote)) {
return mentions('@'+sender.split('@')[0]+' Anda sudah vote', fil, true)
} else {
vote.push({
participant: id_vote,
voting: '❌'
})
fs.writeFileSync(`./database/voting/pvote/${from}.json`,JSON.stringify(vote))
let _p = []
let _vote = `─▢ VOTING ▢─

*Vote* @${_votes[0].votes.split('@')[0]}
*Alasan*: ${_votes[0].reason}
*Jumlah Vote* : ${vote.length} Vote
*Durasi* : ${_votes[0].durasi} Menit

─ ─ ─ ─ ─ ─ ─
` 
for(let i = 0; i < vote.length; i++) {
_vote +=  `@${vote[i].participant.split('@')[0]}
*Vote* : ${vote[i].voting}
`
_p.push(vote[i].participant)
}  
_p.push(_votes[0].votes)
mentions(_vote,_p,true)   
}
}
}	
const getPremiumExpired = (sender) => {
 let position = null
 Object.keys(premium).forEach((i) => {
if (premium[i].id === sender) {
  position = i
}
 })
 if (position !== null) {
return premium[position].expired
 }
} 
const expiredCheck = () => {
setInterval(() => {
let position = null
Object.keys(premium).forEach((i) => {
if (Date.now() >= premium[i].expired) {
position = i
}
})
if (position !== null) {
console.log(chalk.bgHex('#3DB7E4').underline(color(`PREMIUM EXPIRED : ${premium[position].id}`,'red')))
client.sendMessage(`${nomerowner}@s.whatsapp.net`, `*「 PREMIUM EXPIRED 」* \n\n\`\`\`HAI OWNER! WAKTU PREMIUM wa.me/${premium[position].id.split("@")[0]} TELAH HABIS!\`\`\``, MessageType.text, {contextInfo:{mentionedJid: [premium[position].id]}})
client.sendMessage(`${premium[position].id}`, `「 𝐍𝐎𝐓𝐈𝐅𝐘 」\nHai Kak selamat ${waktoo}!\nWAKTU PREMIUM KAKAK SEKARANG SUDAH HABIS ~\nTERMAKASIH 😊`, MessageType.text)
premium.splice(position, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
}
}, 1000)
}
const getAllPremiumUser = () => {
 const array = []
 Object.keys(premium).forEach((i) => {
array.push(premium[i].id)
 })
 return array
}

const expiredCheckS = (client, sewa) => {
    setInterval(() => {
 let position = null
 Object.keys(sewa).forEach((i) => {
     if (Date.now() >= sewa[i].expired) {
     position = i
     }
 })
if (position !== null) {
replybutton(sewa[position].id, `${prefix}extend`, `Mau Memperpanjang Waktu Penyewaan, klik di bawah`,`E X T E N D`, `━ 「 *SEWA EXPIRE* 」 ━\n\n\`\`\`Waktu Sewa Di Grup Ini Sudah Habis, Bot Akan Keluar Otomatis\`\`\``, MessageType.text)
client.sendMessage(`${nomerowner}@s.whatsapp.net`, `*「 SEWA EXPIRE 」* \n\nHAI OWNER! WAKTU SEWA *${sewa[position].id}*, DI GROUP *${groupName}* TELAH BERAKHIR!`, MessageType.text)
client.groupLeave(sewa[position].id)
sewa.splice(position, 1)
fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa))
}
}, 1000)
}
/*****************END SCURITY FEATURE ********/
			
            const sotoy = [
            '?? : 🍒 : 🍐',
            '🍒 : 🔔 : 🍊',
            '🍇 : 🍇 : 🍇',
            '🍊 : 🍋 : 🔔',
            '🔔 : 🍒 : 🍐',
            '🔔 : 🍒 : 🍊',
            '🍊 : 🍋 : 🔔',		
            '🍐 : 🍒 : 🍋',
            '🍐 : 🍐 : 🍐',
            '🍊 : 🍒 : 🍒',
            '🔔 : 🔔 : 🍇',
            '🍌 : 🍒 : 🔔',
            '🍐 : 🔔 : 🔔',
            '🍊 : 🍋 : 🍒',
            '🍋 : 🍋 : 🍌',
            '🔔 : 🔔 : 🍇',
            '🔔 : 🍐 : 🍇',
            '🔔 : 🔔 : 🔔',
            '🍒 : 🍒 : 🍒',
            '🍌 : 🍌 : 🍌',
            ]
			const slot1 = ['🍋','🍐','🍓','🍇','🍒']
            const slot2 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot3 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot4 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot5 = ['🍋','🍐','🍓','🍇','🍒']
            const slot6 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot7 = ['🍋','🍐','🍓','🍇','🍒']
            const slot8 = ['🍋','🍐','🍓','🍇','🍒']   
            const slot9 = ['🍋','🍐','🍓','🍇','🍒']
            const kapan2 = ['Hari ini','Mungkin besok','1 Minggu lagi','Masih lama','3 Bulan lagi','7 Bulan lagi','3 Tahun lagi','4 Bulan lagi','2 Bulan lagi','1 Tahun lagi','1 Bulan lagi','Coba ulangi']
            const bisakah = ['Tidak Bisa','Bisa']
            const apakah = ['Tidak Dong','Iya','Bener Banget']
            const katailh = ['Lebih baik mengerti sedikit daripada salah mengerti.','Hampir semua pria memang mampu bertahan menghadapi kesulitan. Namun, jika Anda ingin menguji karakter sejati pria, beri dia kekuasaan.','Bila tekad seseorang kuat dan teguh, Tuhan akan bergabung dalam usahanya.','Penderitaan adalah pelajaran.','Ilmu pengetahuan tanpa agama adalah pincang.','Hidup itu seperti sebuah sepeda, agar tetap seimbang kita harus tetap bergerak.','Perbedaan masa lalu, sekarang, dan masa depan tak lebih dari ilusi yang keras kepala.','Sebuah meja, sebuah kursi, semangkuk buah, dan sebuah biola; apa lagi yang dibutuhkan agar seseorang bisa merasa bahagia?','Belas kasihanlah terhadap sesama, bersikap keraslah terhadap diri sendiri.','Cara paling baik untuk menggerakkan diri Anda ialah memberi tugas kepada diri sendiri.','Kita tidak boleh kehilangan semangat. Semangat adalah stimulan terkuat untuk mencintai, berkreasi dan berkeinginan untuk hidup lebih lama.','Manusia akan bahagia selama ia memilih untuk bahagia.','Saya tidak berharap menjadi segalanya bagi setiap orang. Saya hanya ingin menjadi sesuatu untuk seseorang.','Apabila sempurna akal seseorang, maka sedikit perkataannya.','Bahagialah orang yang dapat menjadi tuan untuk dirinya, menjadi kusir untuk nafsunya dan menjadi kapten untuk bahtera hidupnya.','Sahabat yang jujur lebih besar harganya daripada harta benda yang diwarisi dari nenek moyang.','Yang paling melelahkan dalam hidup adalah menjadi orang yang tidak tulus.','Terbuka untuk Anda, begitulah Tuhan memberi kita jalan untuk berusaha. Jangan pernah berfikir jalan sudah tertutup.','Penundaan adalah kuburan dimana peluang dikuburkan.','Cinta bukan saling menatap mata, namun melihat ke arah yang sama bersama-sama.','Kita adalah apa yang kita kerjakan berulang kali. Dengan demikian, kecemerlangan bukan tindakan, tetapi kebiasaan.','Jangan pernah mencoba menjadikan putra atau putri Anda menjadi seperti Anda. Diri Anda hanya cukup satu saja.','Jika Anda bisa membuat orang lain tertawa, maka Anda akan mendapatkan semua cinta yang Anda inginkan.','Masalah akan datang cepat atau lambat. Jika masalah datang, sambut dengan sebaik mungkin. Semakin ramah Anda menyapanya, semakin cepat ia pergi.','Kita tak bisa melakukan apapun untuk mengubah masa lalu. Tapi apapun yang kita lakukan bisa mengubah masa depan.','Kesabaran adalah teman dari kebijaksanaan.','Orang-orang kreatif termotivasi oleh keinginan untuk maju, bukan oleh keinginan untuk mengalahkan orang lain.','Dimanapun engkau berada selalulah menjadi yang terbaik dan berikan yang terbaik dari yang bisa kita berikan.','Kebencian seperti halnya cinta, berkobar karena hal-hal kecil.','Anda tidak perlu harus berhasil pada kali pertama.','Satu jam yang intensif, jauh lebih baik dan menguntungkan daripada bertahun-tahun bermimpi dan merenung-renung.','Hal terbaik yang bisa Anda lakukan untuk orang lain bukanlah membagikan kekayaan Anda, tetapi membantu dia untuk memiliki kekayaannya sendiri.','Tidak ada jaminan keberhasilan, tetapi tidak berusaha adalah jaminan kegagalan.','Aku tidak tahu kunci sukses itu apa, tapi kunci menuju kegagalan adalah mencoba membuat semua orang senang.']
            const buruh1 = ['🐳','🦈','🐬','🐋','🐟','🐠','🦐','🦑','🦀','🐚']
            const buruh2 = ['🐔','🦃','🐿','🐐','🐏','🐖','🐑','🐎','🐺','🦩']
            const buruh3 = ['🦋','🕷','🐝','🐉','🦆','🦅','🕊','🐧','🐦','🦇']
            const slot11 = slot1[Math.floor(Math.random() * (slot1.length))]
		    const slot22 = slot2[Math.floor(Math.random() * (slot2.length))]
		    const slot33 = slot3[Math.floor(Math.random() * (slot3.length))]
		    const slot44 = slot4[Math.floor(Math.random() * (slot4.length))]
			const slot55 = slot5[Math.floor(Math.random() * (slot5.length))]
			const slot66 = slot6[Math.floor(Math.random() * (slot6.length))]	
		    const slot77 = slot4[Math.floor(Math.random() * (slot7.length))]
		    const slot88 = slot5[Math.floor(Math.random() * (slot8.length))]
			const slot99 = slot6[Math.floor(Math.random() * (slot9.length))]
			const buruh11 = buruh1[Math.floor(Math.random() * (buruh1.length))]
		    const buruh22 = buruh2[Math.floor(Math.random() * (buruh2.length))]
		    const buruh33 = buruh3[Math.floor(Math.random() * (buruh3.length))]

//FAKE REPLY
const ffoto = { key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast"}: {})}, message: {imageMessage: {caption: `Selamat ${waktoo}`, jpegThumbnail: gambar}}}
const fvideo = { key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast"}: {})}, message: {videoMessage: {caption: `Selamat ${waktoo}`, jpegThumbnail: gambar}}}
const flokasi = {key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast" } : {}) }, message: {locationMessage: {degreesLatitude: -7.0389318, degreesLongitude: 113.8969749, name: 'Tokyo, Japan', address: '@client.mhrdkaa', jpegThumbnail: gambar}}}
const fkontak = {key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast" } : {}) }, message: {contactMessage: {displayName: `Selamat ${waktoo}`, vcard: 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'N:Bot;Muzza;Gans;;\n' + 'FN:Muzza-Bot\n' + 'item1.TEL;waid=6281231951590:+62 812-319-51590\n' + 'item1.X-ABLabel:Telepon\n' + 'END:VCARD'}}}
const ftoko = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: 'status@broadcast' } : {}) }, message: { 'productMessage': { 'product': { 'productImage':{ 'mimetype': 'image/jpeg', 'jpegThumbnail': gambar}, 'title': `⊳ Made With ❣️ Akiraa ⊲`, 'productImageCount': 9999 }, 'businessOwnerJid': `0@s.whatsapp.net`}}}
const fdoc = {key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast" } : {}) }, message: {documentMessage: {mimetype: 'application/octet-stream', title: `Selamat ${waktoo}`, pageCount: 0, fileName: `Selamat ${waktoo}`, jpegThumbnail: gambar}}}
const finvite = {key: {fromMe: false, participant: `${numbernye}@s.whatsapp.net`, remoteJid: `${numbernye}@s.whatsapp.net`}, message: {groupInviteMessage: {groupJid: from, inviteCode: `Selamat ${waktoo}`, groupName: groupName, caption: `Selamat ${waktoo}`, jpegThumbnail: gambar}}}

 //kolor warna :v
  colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
  
  //detector media
  const isImage = (type === 'imageMessage')
  const isVideo = (type === 'videoMessage')
  const isSticker = (type == 'stickerMessage')
  const isMedia = (type === 'imageMessage' || type === 'videoMessage')
  const isAllMedia = (type === 'imageMessage' || type === 'videoMessage' || type === 'stickerMessage' || type === 'audioMessage' || type === 'contactMessage' || type === 'locationMessage')
  const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
  const isQuotedLoca = type === 'extendedTextMessage' && content.includes('locationMessage')
  const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
  const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
  const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
  const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
  const isQuotedDocs = type === 'extendedTextMessage' && content.includes('documentMessage')
  const isQuotedTeks = type === 'extendedTextMessage' && content.includes('quotedMessage')
  const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
  const isQuotedReply = type === 'extendedTextMessage' && content.includes('Message')

//AUTO READ GC
var chatgc = await client.chats.array.filter(v => v.jid.endsWith('g.us'))
chatgc.map( async ({ jid }) => {
await client.chatRead(jid)
})
//AUTO READ PC
var chatpc = await client.chats.array.filter(v => v.jid.endsWith('s.whatsapp.net'))
chatpc.map( async ({ jid }) => {
await client.chatRead(jid)
})
//Anjay Alok
expiredCheck(premium)
expiredCheckS(client, sewa)

if (isGroup && isAntro && m.message && m.isBaileys && m.quoted && m.quoted.mtype === 'orderMessage' && !(m.quoted.token && m.quoted.orderId)) {
reply(`Troli Detected\n` + require('util').format(m.key))
client.sendMessage(from, '*TANDAI TELAH DI BACA!!*\n'.repeat(300), text)
await client.modifyChat(m.chat, 'delete', {
includeStarred: false
})
}
if (setiker.includes(messagesC)){
namastc = messagesC
buffer = fs.readFileSync(`./database/stick/${namastc}.webp`)
fs.writeFileSync('./sticker/responder.webp', buffer)
exec(`webpmux -set exif ./sticker/data.exif ./sticker/responder.webp -o ./sticker/responder.webp`, async (error) => {
if (error) return reply(ind.emror())
client.sendMessage(from, fs.readFileSync(`./sticker/responder.webp`), sticker, {quoted: mek})
fs.unlinkSync(`./sticker/responder.webp`)
})
}

if (audionye.includes(messagesC)){
namastc = messagesC
buffer = fs.readFileSync(`./database/audio/${namastc}.mp3`)
client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', quoted: mek, ptt: true })
}
  if (isGroup && isAntiLink && !isOwner && !isGroupAdmins && isBotGroupAdmins){
  if (budy.match(/(https:\/\/chat.whatsapp.com)/gi)) {
  replybutton1(from, `${prefix}antilink off`,
  `Klik Di Bawah Untuk Mematikan`,
  `DISABLE ANTILINK`,
  `*❗ GROUP LINK DETECTED ❗*
 
*Maaf Kamu Akan Di Kick Dari Group Ini!*`)
    client.groupRemove(from, [sender])
    }
    }
    if (budy.length > 10000) {
    if (!itsMe) return
    if (m.isBaileys) return
    sendMess(`${ownerNumber}`, `Hai Owner! *wa.me/${sender.split("@")[0]}* Terdeteksi Telah Mengirim Virtex ${isGroup?`*In Group ${groupName}*`:''}`, text)
    client.modifyChat(m.chat, 'delete', {
    includeStarred: false
    })
    client.sendMessage(from, `「 *VIRTEX DETECTED* 」 `, text, {quoted:bugtroli})
    client.sendMessage(from, '*TANDAI TELAH DI BACA!!*\n'.repeat(300), text)
    }
    if (!m.isBaileys && isGroup && isBadword && !isOwner && !isGroupAdmins && !mek.key.fromMe){
    for (let kasar of badword){
    if (chats.toLowerCase().includes(kasar)){
    if (isCountKasar(sender, senbadword)){
    if (!isBotGroupAdmins) return reply(`Kamu beruntung karena bot bukan admin`)
    replybutton1(from, `${prefix}antibadword off`, `𝙺𝙻𝙸𝙺 𝙳𝙸 𝙱𝙰𝚆𝙰𝙷 𝚄𝙽𝚃𝚄𝙺 𝙼𝙴𝙼𝙰𝚃𝙸𝙺𝙰𝙽`,`DISABLE ANTI BADWORD`,`━••❗ *ANTI BADWORD* ❗••━

Hai @${sender.split("@")[0]}
Sepertinya kamu sudah berkata kasar lebih dari 2x, maaf kamu akan di kick`)
client.groupRemove(from, [sender])
delCountKasar(sender, senbadword)
} else {
addCountKasar(sender, senbadword)
reply(`Kamu terdeteksi berkata kasar\nJangan ulangi lagi atau kamu akan dikick`)
}
}
}
}

var _0x29b3e7=_0x2c08;function _0x2c08(_0x1af4f2,_0x56f24c){var _0x16cbd2=_0x16cb();return _0x2c08=function(_0x2c0863,_0x2e10eb){_0x2c0863=_0x2c0863-0x116;var _0x22c20e=_0x16cbd2[_0x2c0863];return _0x22c20e;},_0x2c08(_0x1af4f2,_0x56f24c);}(function(_0x4d4fc8,_0x22d672){var _0x34b95e=_0x2c08,_0x22c258=_0x4d4fc8();while(!![]){try{var _0x5baa83=parseInt(_0x34b95e(0x11c))/0x1+parseInt(_0x34b95e(0x11f))/0x2+-parseInt(_0x34b95e(0x121))/0x3*(-parseInt(_0x34b95e(0x11e))/0x4)+-parseInt(_0x34b95e(0x116))/0x5*(parseInt(_0x34b95e(0x123))/0x6)+parseInt(_0x34b95e(0x117))/0x7*(-parseInt(_0x34b95e(0x120))/0x8)+parseInt(_0x34b95e(0x11a))/0x9+-parseInt(_0x34b95e(0x119))/0xa*(-parseInt(_0x34b95e(0x118))/0xb);if(_0x5baa83===_0x22d672)break;else _0x22c258['push'](_0x22c258['shift']());}catch(_0x1049be){_0x22c258['push'](_0x22c258['shift']());}}}(_0x16cb,0xbbf5c),client[_0x29b3e7(0x11d)](_0x29b3e7(0x11b)+kyun(process['uptime']())+'\x20Total\x20hit\x20:\x20'+totalhit)[_0x29b3e7(0x122)](_0x2d72ed=>_0x2d72ed),settingstatus=new Date()*0x1);function _0x16cb(){var _0x54615e=['6MxrdWd','6684985xEhYwz','7jKfdYc','143xonSrd','153510XfduPH','5396094GwfZSF','Runtime\x20:\x20','1473514PFPSar','setStatus','164tuFfgl','117138JDEHfA','2452616zhSfjO','6018tGnCfU','catch'];_0x16cb=function(){return _0x54615e;};return _0x16cb();}

if (isGroup && m.isBaileys) {
if (mentionUser.length >= groupMembers.length){
if (!budy.match(/(@)/gi)) {
mentions(`Terdeteksi @${sender.split('@')[0]} melakukan hidetag`, [sender], false)
}
}
}

//ROLE LEVEL
const levelRole = getLevelingLevel(sender)
 var role = 'Bronze 1'
  if (levelRole <= 2) {
role = 'Bronze 1'
  } else if (levelRole <= 10) {
role = 'Bronze 2'
  } else if (levelRole <= 20) {
role = 'Bronze 3'
  } else if (levelRole <= 30) {
role = 'Bronze 4'
  } else if (levelRole <= 40) {
role = 'Bronze 5'
  } else if (levelRole <= 70) {
role = 'Silver 1'
  } else if (levelRole <= 85) {
role = 'Silver 2'
  } else if (levelRole <= 95) {
role = 'Silver 3'
  } else if (levelRole <= 105) {
role = 'Silver 4'
  } else if (levelRole <= 125) {
role = 'Silver 5'
  } else if (levelRole <= 150) {
role = 'Gold 1'
  } else if (levelRole <= 170) {
role = 'Gold 2'
  } else if (levelRole <= 190) {
role = 'Gold 3'
  } else if (levelRole <= 210) {
role = 'Gold 4'
  } else if (levelRole <= 230) {
role = 'Gold 5'
  } else if (levelRole <= 260) {
role = 'Platinum 1'
  } else if (levelRole <= 290) {
role = 'Platinum 2'
  } else if (levelRole <= 320) {
role = 'Platinum 3'
  } else if (levelRole <= 350) {
role = 'Platinum 4'
  } else if (levelRole <= 380) {
role = 'Platinum 5'
  } else if (levelRole <= 410) {
role = 'Diamond 1'
  } else if (levelRole <= 450) {
role = 'Diamond 2'
  } else if (levelRole <= 500) {
role = 'Diamond 3'
  } else if (levelRole <= 550) {
role = 'Diamond 4'
  } else if (levelRole <= 600) {
role = 'Diamond 5'
  } else if (levelRole <= 700) {
role = 'Master'
  } else if (levelRole <= 800) {
role = 'Master ✩'
  } else if (levelRole <= 900) {
role = 'Master ✩✩'
  } else if (levelRole <= 1000) {
role = 'Master ✩✩✩'
  } else if (levelRole <= 1100) {
role = 'Master ✯'
  } else if (levelRole <= 1225) {
role = 'Master ✯✯'
  } else if (levelRole <= 1340) {
role = 'Master ✯✯✯'
  } else if (levelRole <= 1400) {
role = 'GrandMaster'
  } else if (levelRole <= 1555) {
role = 'GrandMaster ✩'
  } else if (levelRole <= 1660) {
role = 'GrandMaster ✩✩'
  } else if (levelRole <= 1710) {
role = 'GrandMaster ✩✩✩'
  } else if (levelRole <= 1825) {
role = 'GrandMaster ✯'
  } else if (levelRole <= 1950) {
role = 'GrandMaster ✯✯'
  } else if (levelRole <= 2000) {
role = 'GrandMaster ✯✯✯'
  } else if (levelRole <= 2220) {
role = 'Legends'
  } else if (levelRole <= 2500) {
role = 'Legends 2'
  } else if (levelRole <= 2700) {
role = 'Legends 3'
  } else if (levelRole <= 2900) {
role = 'Legends 4'
  } else if (levelRole <= 3100) {
role = 'Legends 5'
  } else if (levelRole <= 3300) {
role = 'Legends 6'
  } else if (levelRole <= 3600) {
role = 'Legends 7'
  } else if (levelRole <= 3900) {
role = 'Legends 8'
  } else if (levelRole <= 4200) {
role = 'Legends 9'
  } else if (levelRole <= 4450) {
role = 'Legends 10'
  } else if (levelRole <= 4700) {
role = 'Legends 忍'
  } else if (levelRole <= 4900) {
role = 'Legends 忍¹'
  } else if (levelRole <= 5100) {
role = 'Legends 忍²'
  } else if (levelRole <= 5600) {
role = 'Legends 忍³'
  } else if (levelRole <= 6100) {
role = 'Legends 忍⁴'
  } else if (levelRole <= 7000) {
role = 'GrandLegends'
  } else if (levelRole <= 10000) {
role = 'GrandLegends 1'
  } else if (levelRole <= 20000) {
role = 'GrandLegends 2'
  } else if (levelRole <= 30000) {
role = 'GrandLegends 3'
  } else if (levelRole <= 40000) {
role = 'GrandLegends 4'
  } else if (levelRole <= 50000) {
role = 'GrandLegends 忍¹'
  } else if (levelRole <= 60000) {
role = 'GrandLegends 忍²'
  } else if (levelRole <= 70000) {
role = 'GrandLegends 忍³'
  } else if (levelRole <= 80000) {
role = 'GrandLegends 忍⁴'
  } else if (levelRole <= 90000) {
role = 'Pro 숒'
  } else if (levelRole <= 99999999999999) {
role = 'Pro × GrandLegends 숒'
}
const addVn = function(kata){
audionye.push(kata)
fs.writeFileSync('./database/audio.json', JSON.stringify(audionye))
}
const dellVn = function(kata){
anu = audionye.indexOf(kata)
audionye.splice(anu, 1)
fs.writeFileSync('./database/audio.json', JSON.stringify(audionye))
}
for (var i = 0; i < cmdDB.length ; i++) {
if (budy.toLowerCase() === cmdDB[i].commands) {
client.sendMessage(from, `${cmdDB[i].jawaban}`, text, {quoted:mek, thumbnail:gambar2})
}
}
const addStc = function(kata){
setiker.push(kata)
fs.writeFileSync('./database/stick.json', JSON.stringify(setiker))
}
const dellStc = function(kata){
anu = setiker.indexOf(kata)
setiker.splice(anu, 1)
fs.writeFileSync('./database/stick.json', JSON.stringify(setiker))
}
if (isGroup && !m.isBaileys) {
if (mentionUser.length !== 0){
for (let ment of mentionUser) {
if (afk.checkAfkUser(ment, _afk)) {
const getId = afk.getAfkId(ment, _afk)
const getReason = afk.getAfkReason(getId, _afk)
const getTime = Date.now() - afk.getAfkTime(getId, _afk)
const heheh = ms(getTime)
replybutton1(from, `ok`, `Ssssst Diemmm`, `SIAP👌`, `@${ment.split('@')[0]} sedang afk\n\n*Alasan :* ${getReason}\n*Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu`)
}
}
}
if (afk.checkAfkUser(sender, _afk)) {
const getId = afk.getAfkId(sender, _afk)
const reason = afk.getAfkReason(sender, _afk)
const getTime = Date.now() - afk.getAfkTime(getId, _afk)
const heheh = ms(getTime)
_afk.splice(afk.getAfkPosition(sender, _afk), 1)
reply(`
@${sender.split("@")[0]} telah kembali afk setelah *${reason}*
Sejak : ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik yang lalu

selamat datang kembali ✨`)
fs.writeFileSync('./database/afk.json', JSON.stringify(_afk))
}
}
if (isGroup && isRegister && !isCmd) {
const currentLevel = getLevelingLevel(sender)
const checkId = getLevelingId(sender)
try {
if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
const amountXp = Math.floor(Math.random() * 10) + 50
const requiredXp = 3000 * (Math.pow(2, currentLevel) - 1)
const getLevel = getLevelingLevel(sender)
addLevelingXp(sender, amountXp)
if (requiredXp <= getLevelingXp(sender)) {
addLevelingLevel(sender, 1)
addBalance(sender, 30, balance)
reply(`*─ 「 LEVEL UP 」 ─*

⬡ *User :* @${sender.split("@")[0]}
⬡ *Nomer :* ${sender.split("@")[0]}
⬡ *Xp :* ${getLevelingXp(sender)}
⬡ *Level :* ${getLevel} > ${getLevelingLevel(sender)}
⬡ *Balance :* $${getBalance(sender, balance)}*
⬡ *Role :* ${role}

Congrats 🎉`)
}
} catch (err) {
console.error(err)
}
}
if (isCmd && msgFilter.isFiltered(from) && !isGroup) {
console.log(color('[ SPAM ]','red'), (command), ">", (sender.split('@')[0]))
return reply('Sabar, Jangan spamm...')
} 
if (isCmd && msgFilter.isFiltered(from) && isGroup) {
console.log(color('[ SPAM ]','red'), (command), ">", (sender.split('@')[0]), "=>", color(groupName, "yellow"))
return reply('Sabar, Jangan spamm...')
}  

            if (!isGroup && isCmd) console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m➻\x1b[1;37m]', color('NAMA', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('➻', 'yellow'), color(command), 'DI :', color('Chat Pribadi', 'yellow')) 
			if (isCmd && isGroup){
            console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m➻\x1b[1;37m]', color('NAMA', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('➻', 'yellow'), color(command), 'DI :', color(groupName, 'yellow'))
            addBalance(sender, randomNomor(20), balance)
            }
            if (isCmd && !isOwner) msgFilter.addFilter(from)

switch (command) {
	    case 'allmenu':
	    case 'allfitur':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    let cekvipp = ms(_prem.getPremiumExpired(sender,premium) - Date.now())
                    menunya = `━ YOUR INFO ━

⬣ Nama : ${pushname} 
⬣ Nomor : ${sender.split("@")[0]} 
⬣ Status : ${isOwner?`Owner ⚔️`:isPrem?`Premium 🏅`:`Free User`} 
⬣ Expired Prem : ${isOwner?`Unlimited Owner`:isPrem ? `${cekvipp.days}d, ${cekvipp.hours}h, ${cekvipp.minutes}m, ${cekvipp.seconds}s`:'Not Premium'}
⬣ Limit : ${isOwner?`Unlimited Owner`:isPrem ? `Unlimited Premium` : getLimit(sender, limitawal, limit) +' / '+limitawal}
⬣ Limit Game : ${cekGLimit(sender, gcount, glimit)} / ${gcount}
⬣ Balance : $${getBalance(sender, balance)}

─ *GRUP MENU* ─
⬡${prefix}promote [@tag]
⬡${prefix}demote [@tag]
⬡${prefix}tagall
⬡${prefix}listpremium
⬡${prefix}banlist
⬡${prefix}blocklist
⬡${prefix}linkgc
⬡${prefix}resetlink
⬡${prefix}grupinfo
⬡${prefix}sider
⬡${prefix}mute
⬡${prefix}unmute
⬡${prefix}hidetag
⬡${prefix}add [62]
⬡${prefix}kick [@tag]
⬡${prefix}setnama
⬡${prefix}setdesk
⬡${prefix}setpp
⬡${prefix}listvn
⬡${prefix}listgrup
⬡${prefix}listsewa
⬡${prefix}adminlist
⬡${prefix}buggc
⬡${prefix}leave
⬡${prefix}level    
⬡${prefix}antidelete aktif/mati
⬡${prefix}grup buka/tutup 
⬡${prefix}welcome aktif/mati
⬡${prefix}nsfw aktif/mati
⬡${prefix}antilink aktif/mati
⬡${prefix}antikasar aktif/mati
⬡${prefix}simisimi aktif/mati

─ *STICKER MENU* ─
⬡${prefix}sticker
⬡${prefix}stikergif
⬡${prefix}stikerwm
⬡${prefix}semoji
⬡${prefix}toimg
⬡${prefix}findsticker
⬡${prefix}gawrgura
⬡${prefix}umongus
⬡${prefix}takestick
⬡${prefix}stickanjing
⬡${prefix}stickbucin
⬡${prefix}ttp text
⬡${prefix}ttp2 text
⬡${prefix}ttp3 text
⬡${prefix}ttp4 text
⬡${prefix}attp text
⬡${prefix}attp2 text
⬡${prefix}dadu

─ *GAME MENU* ─
⬡${prefix}jadian
⬡${prefix}mining
⬡${prefix}buylimit
⬡${prefix}tebakgambar
⬡${prefix}mathkuis
⬡${prefix}tebakumur
⬡${prefix}family100
⬡${prefix}afk (alasan)
⬡${prefix}fitnah
⬡${prefix}tictactoe [@Tag]
⬡${prefix}resetictactoe
⬡${prefix}weton
⬡${prefix}level
⬡${prefix}suit
⬡${prefix}nickff

─ *FAST MENU* ─
⬡${prefix}tebakgambar
⬡${prefix}katailham
⬡${prefix}caripesan
⬡${prefix}asupan
⬡${prefix}kontak
⬡${prefix}getpic
⬡${prefix}lirik
⬡${prefix}darkjokes
⬡${prefix}memeindo
⬡${prefix}meme
⬡${prefix}truth
⬡${prefix}dare
⬡${prefix}tts
⬡${prefix}cersex
⬡${prefix}cerpen
⬡${prefix}pantun
⬡${prefix}cogan
⬡${prefix}cegan
⬡${prefix}google
⬡${prefix}cuaca

─ *FUN MENU* ─
⬡${prefix}textfont
⬡${prefix}boomtext
⬡${prefix}katajago
⬡${prefix}cinta
⬡${prefix}halah
⬡${prefix}hilih
⬡${prefix}huluh
⬡${prefix}heleh
⬡${prefix}holoh
⬡${prefix}readmore
⬡${prefix}fake

─ *OWNER MENU* ─
⬡${prefix}prem add
⬡${prefix}prem dell
⬡${prefix}bc
⬡${prefix}setexif
⬡${prefix}joingc
⬡${prefix}readall
⬡${prefix}clearall
⬡${prefix}banadd
⬡${prefix}bandell
⬡${prefix}sewa add/dell
⬡${prefix}leave
⬡${prefix}event aktif/mati
⬡${prefix}clone
⬡${prefix}setppbot
⬡${prefix}sethargalimit
⬡${prefix}setnamaowner
⬡${prefix}setnamabot
⬡${prefix}setwaktugametb

─ *MAKER MENU* ─
⬡${prefix}blackpink text
⬡${prefix}neon text
⬡${prefix}greenneon text
⬡${prefix}advanceglow text
⬡${prefix}futureneon text
⬡${prefix}sandwriting text
⬡${prefix}sandsummer text
⬡${prefix}sandengraved text
⬡${prefix}metaldark text
⬡${prefix}neonlight text
⬡${prefix}text1917 text
⬡${prefix}minion text
⬡${prefix}deluxesilver text
⬡${prefix}newyearcard text
⬡${prefix}bloodfrosted text
⬡${prefix}halloween text
⬡${prefix}jokerlogo text
⬡${prefix}fireworksparkle text
⬡${prefix}natureleaves text
⬡${prefix}bokeh text
⬡${prefix}toxic text
⬡${prefix}strawberry text
⬡${prefix}box3d text
⬡${prefix}roadwarning text
⬡${prefix}breakwall text
⬡${prefix}icecold text
⬡${prefix}luxury text
⬡${prefix}cloud text
⬡${prefix}summersand text
⬡${prefix}horrorblood text
⬡${prefix}pornhub text1 text2
⬡${prefix}glitch text1 text2
⬡${prefix}avenger text1 text2
⬡${prefix}space text1 text2
⬡${prefix}ninjalogo text1 text2
⬡${prefix}marvelstudio text1 text2
⬡${prefix}lionlogo text1 text2
⬡${prefix}wolflogo text1 text2
⬡${prefix}steel3d text1 text2
⬡${prefix}wallgravity text1 text2
⬡${prefix}tahta text
⬡${prefix}shadow text
⬡${prefix}cup text
⬡${prefix}cup1 text
⬡${prefix}romance text
⬡${prefix}smoke text
⬡${prefix}burnpaper text
⬡${prefix}lovemessage text
⬡${prefix}undergrass text
⬡${prefix}love text
⬡${prefix}coffe text
⬡${prefix}woodheart text
⬡${prefix}woodenboard text
⬡${prefix}summer3d text
⬡${prefix}wolfmetal text
⬡${prefix}nature3d text
⬡${prefix}golderrose text
⬡${prefix}summernature text
⬡${prefix}letterleaves text
⬡${prefix}glowingneon text
⬡${prefix}fallleaves text
⬡${prefix}flamming text
⬡${prefix}harrypotter text
⬡${prefix}carvedwood text
⬡${prefix}ttlogo text1 text2
⬡${prefix}arcade8bit text1 text2
⬡${prefix}battlefield4 text1 text2
⬡${prefix}pubg text1 text2
⬡${prefix}wetglass text
⬡${prefix}multicolor3d text
⬡${prefix}watercolor text
⬡${prefix}luxurygold text
⬡${prefix}galaxywallpaper text
⬡${prefix}lighttext text
⬡${prefix}beautifulflower text
⬡${prefix}puppycute text
⬡${prefix}royaltext text
⬡${prefix}heartshaped text
⬡${prefix}birthdaycake text
⬡${prefix}galaxystyle text
⬡${prefix}hologram3d text
⬡${prefix}greenneon text
⬡${prefix}glossychrome text
⬡${prefix}greenbush text
⬡${prefix}metallogo text
⬡${prefix}noeltext text
⬡${prefix}glittergold text
⬡${prefix}textcake text
⬡${prefix}starsnight text
⬡${prefix}wooden3d text
⬡${prefix}textbyname text
⬡${prefix}writegalacy text
⬡${prefix}galaxybat text
⬡${prefix}snow3d text
⬡${prefix}birthdayday text
⬡${prefix}goldplaybutton text
⬡${prefix}silverplaybutton text
⬡${prefix}freefire text
⬡${prefix}gmlogo text
⬡${prefix}cartongravity text
⬡${prefix}wasted reply

─ *SERTIFIKAT MENU* ─
⬡${prefix}bucinserti [nama]
⬡${prefix}tololserti [nama]
⬡${prefix}fuckboy [nama]
⬡${prefix}fuckgirl [nama]
⬡${prefix}goodboy [nama]
⬡${prefix}goodgirl [nama]
⬡${prefix}badboy [nama]
⬡${prefix}badgirl [nama]
⬡${prefix}ffserti [nama]
⬡${prefix}ffserti2 [nama]
⬡${prefix}ffserti3 [nama]

─ *OTHER MENU* ─
⬡${prefix}slot
⬡${prefix}infogempa
⬡${prefix}qrcode text
⬡${prefix}nulis text
⬡${prefix}request Fitur
⬡${prefix}jadwaltv
⬡${prefix}telesticker
⬡${prefix}twich
⬡${prefix}balance
⬡${prefix}ceklimit
⬡${prefix}buylimit
⬡${prefix}lapor Fitur
⬡${prefix}pinterest
⬡${prefix}liputan6
⬡${prefix}tribunews
⬡${prefix}artinama
⬡${prefix}quotes
⬡${prefix}quotesanime

─ *DOWNLOADER* ─
⬡${prefix}play
⬡${prefix}joox
⬡${prefix}igdl
⬡${prefix}playmp4
⬡${prefix}tiktoknowm
⬡${prefix}playstore
⬡${prefix}ytmp3 link
⬡${prefix}ytmp4 link
⬡${prefix}tiktokmusik

─ *PREMIUM MENU* ─
⬡${prefix}tiktoknowm
⬡${prefix}tiktokmusik
⬡${prefix}playmp4
⬡${prefix}pinterest
⬡${prefix}takestick
⬡${prefix}findsticker
⬡${prefix}playstore
⬡${prefix}delete
⬡${prefix}buggc
⬡${prefix}ytmp3
⬡${prefix}ytmp4

─ *STALKING MENU* ─
⬡${prefix}igstalk
⬡${prefix}twiterstalk
⬡${prefix}githubstalk
⬡${prefix}tiktokstalk
⬡${prefix}ytstalk
⬡${prefix}ffstalk 

─ *STORAGE MENU* ─
⬡${prefix}addstiker
⬡${prefix}addimage
⬡${prefix}addvideo
⬡${prefix}addcmd
⬡${prefix}dellstiker
⬡${prefix}dellimage
⬡${prefix}dellvideo
⬡${prefix}dellcmd
⬡${prefix}liststiker
⬡${prefix}listimage
⬡${prefix}listvideo
⬡${prefix}listcmd
⬡${prefix}listvn
⬡${prefix}getstiker
⬡${prefix}getimage
⬡${prefix}getvideo

─ *SOUND MENU* ─
⬡${prefix}sound1
⬡${prefix}sound2
⬡${prefix}sound3
⬡${prefix}sound4
⬡${prefix}sound5
⬡${prefix}sound6
⬡${prefix}sound7
⬡${prefix}sound8
⬡${prefix}sound9
⬡${prefix}sound10
⬡${prefix}sound11
⬡${prefix}sound12
⬡${prefix}sound13
⬡${prefix}sound14
⬡${prefix}sound15

─ *CHECK MENU* ─
⬡${prefix}gantengcek 
⬡${prefix}cantikcek 
⬡${prefix}jelekcek 
⬡${prefix}goblokcek 
⬡${prefix}begocek 
⬡${prefix}pintercek 
⬡${prefix}jagocek 
⬡${prefix}nolepcek 
⬡${prefix}bebancek 
⬡${prefix}baikcek 
⬡${prefix}jahatcek 
⬡${prefix}anjingcek 
⬡${prefix}haramcek 
⬡${prefix}pakboycek 
⬡${prefix}pakgirlcek 
⬡${prefix}sangecek 
⬡${prefix}bapercek

─ *TAG MENU* ─
⬡${prefix}ganteng 
⬡${prefix}cantik 
⬡${prefix}jelek 
⬡${prefix}goblok 
⬡${prefix}bego 
⬡${prefix}pinter 
⬡${prefix}jago 
⬡${prefix}babi 
⬡${prefix}beban 
⬡${prefix}baik 
⬡${prefix}jahat 
⬡${prefix}anjing 
⬡${prefix}monyet 
⬡${prefix}haram 
⬡${prefix}pakboy 
⬡${prefix}pakgirl 
⬡${prefix}sadboy 
⬡${prefix}sadgirl 
⬡${prefix}wibu 
⬡${prefix}nolep 
⬡${prefix}hebat

─ *INFO MENU* ─
⬡${prefix}runtime
⬡${prefix}covidindo
⬡${prefix}profile
⬡${prefix}infobot
⬡${prefix}listgrup
⬡${prefix}botgrup
⬡${prefix}speed
⬡${prefix}ping
⬡${prefix}snk
⬡${prefix}level
⬡${prefix}wame
⬡${prefix}balance
⬡${prefix}cekapikey
⬡${prefix}ceklimit
⬡${prefix}cekpremium
⬡${prefix}kodebahasa
⬡${prefix}donasi
⬡${prefix}owner
⬡${prefix}delete

─ *ISLAMI* ─
⬡${prefix}alquran
⬡${prefix}jadwalsholat
⬡${prefix}asmaulhusna
⬡${prefix}kisahnabi
⬡${prefix}alquranaudio
⬡${prefix}listsurah
⬡${prefix}niatsholat

─ *KERANG MENU* ─
⬡${prefix}apakah
⬡${prefix}bisakah
⬡${prefix}kapankah
⬡${prefix}ratetampan
⬡${prefix}ratecantik
⬡${prefix}ratelesbi
⬡${prefix}ratesange
⬡${prefix}rategay
⬡${prefix}watak`
                   var _0x5c2da4=_0x3c97;function _0x4647(){var _0x456093=['split','23992630cyPvtD','7.8000','5328biqOBQ','prepareMessage','4YgxEjD','IDR','73olAQyq','4626355vjIAYN','2878teVDwE','5617308DcWBZs','10000000','4478868djUhyy','1011','8532643gAddlM','prepareMessageFromContent','message','18016yECnum','@s.whatsapp.net'];_0x4647=function(){return _0x456093;};return _0x4647();}function _0x3c97(_0x20dd1c,_0x1ec1c8){var _0x464764=_0x4647();return _0x3c97=function(_0x3c9720,_0x3b16a7){_0x3c9720=_0x3c9720-0x155;var _0x55d5a1=_0x464764[_0x3c9720];return _0x55d5a1;},_0x3c97(_0x20dd1c,_0x1ec1c8);}(function(_0x6e846b,_0x470bfe){var _0x3be09c=_0x3c97,_0x252d9d=_0x6e846b();while(!![]){try{var _0x1a8fdf=parseInt(_0x3be09c(0x15d))/0x1*(-parseInt(_0x3be09c(0x15f))/0x2)+parseInt(_0x3be09c(0x162))/0x3*(-parseInt(_0x3be09c(0x15b))/0x4)+-parseInt(_0x3be09c(0x15e))/0x5+parseInt(_0x3be09c(0x160))/0x6+-parseInt(_0x3be09c(0x164))/0x7+-parseInt(_0x3be09c(0x167))/0x8*(-parseInt(_0x3be09c(0x159))/0x9)+parseInt(_0x3be09c(0x157))/0xa;if(_0x1a8fdf===_0x470bfe)break;else _0x252d9d['push'](_0x252d9d['shift']());}catch(_0x52461c){_0x252d9d['push'](_0x252d9d['shift']());}}}(_0x4647,0xe22ea),imeg=await client[_0x5c2da4(0x15a)](from,gambar,'imageMessage'),imeu=imeg[_0x5c2da4(0x166)]['imageMessage'],client['relayWAMessage'](await client[_0x5c2da4(0x165)](from,{'productMessage':{'businessOwnerJid':nomerowner+_0x5c2da4(0x155),'product':{'productId':_0x5c2da4(0x163),'productImage':imeu,'title':`Selamat ${waktoo} ${pushname}`,'description':''+menunya,'currencyCode':_0x5c2da4(0x15c),'priceAmount1000':_0x5c2da4(0x161),'retailerId':'','url':'','productImageCount':0x1,'salePriceAmount1000':_0x5c2da4(0x158)}}},{'quoted':mek})));
                   break
       case 'start':
       case 'starts':
       case 'menu':
       case 'help':{
                    if (!isRegister) return reply(ind.noregis())
                    menu1 = `Hai Kak @${senderr.split("@")[0]}
                 
Saya Akiraa Bot, Bot WhatsApp
Yang Membantu Kamu Untuk
Mempermudah Sesuatu Seperti
Membuat Sticker Dan Lainnya,
Ada Butuh Info Dariku!`

futer = `Info: Jika Kamu Menggunakan Wa
Lama Atau Wa Mod Dan Button Ga
Keliatan, Langsung Aja Ketik .allmenu`
const gambra = (await client.prepareMessageMedia(gambar,'imageMessage')).imageMessage
let gbutsan = [
{ buttonId: `${prefix}allmenu`, buttonText: { displayText: 'MENU BOT' }, type: 1 },
{ buttonId: `${prefix}snk`, buttonText: { displayText: 'SNK' }, type: 1 }
]
                   const buttonsMessage = {
                   contentText: menu1,
                   buttons: gbutsan,
                   footerText: futer,
                   headerType: 4,
                   imageMessage: gambra
                   }
                   client.sendMessage(from, buttonsMessage, MessageType.buttonsMessage, {contextInfo:{mentionedJid: [senderr]}})
                   }
                   break
        case 'cekmenu':
        case 'checkmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.cekmenu(prefix))
                   break
        case 'fastmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.fastmenu(prefix))
                   break
        case 'islammenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.islammenu(prefix))
                   break
        case 'groupmenu':
        case 'grupmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.grupmenu(prefix))
                   break
        case 'ownermenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (!isOwner) return reply(ind.ownerb())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.ownermenu(prefix))
                   break
        case 'nsfwmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   if (!isNsfw) return reply('```AKTIFKAN MODE NSFW!!```')
                   reply(menu.nsfwmenu(prefix))
                   break
       case 'makermenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.makermenu(prefix))
                   break
        case 'storagemenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.storagemenu(prefix))
                   break
       case 'othermenu':
       case 'menulain':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.othermenu(prefix))
                   break
        case 'funmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.funmenu(prefix))
                   break
        case 'downloadmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.downmenu(prefix))
                   break
        case 'premiummenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.premmenu(prefix))
                   break
        case 'stalkmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.stalkmenu(prefix))
                   break
        case 'soundmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.soundmenu(prefix))
                   break
        case 'listvn':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.listvn())
                   break
       case 'kerangmenu':
                   if (isBanned) return reply(ind.banned())
                   if (!isRegister) return reply(ind.noregis())
                   reply(menu.kerangmenu(prefix))
                   break
       case 'sertifikatmenu':
                   if (isBanned) return reply(ind.banned())
                   if (!isRegister) return reply(ind.noregis())
                   reply(menu.sertifikatmenu(prefix))
                   break
       case 'stickermenu':
       case 'stikermenu':
                   if (isBanned) return reply(ind.banned())
                   if (!isRegister) return reply(ind.noregis())
                   reply(menu.stikermenu(prefix))
                   break
      case 'tagmenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (!isGroup) return reply(ind.groupo())
                   reply(menu.tagmenu(prefix))
                   break
       case 'gamemenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.gamemenu(prefix))
                   break
       case 'infomenu':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.infomenu(prefix))
                   break
        case 'kodebahasa':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(menu.listkode())
                    break
        case 'sewabot':
                    if (!isRegister) return reply(ind.noregis())
                    reply(menu.sewabot())
                    break
        case 'uptopremium':
                    if (!isRegister) return reply(ind.noregis())
                    reply(menu.upprembot())
                    break
        case 'listsurah':
                    if (!isRegister) return reply(ind.noregis())
		            if (isBanned) return reply(ind.banned())
			        reply(ind.wait())
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/quran?apikey=${lolkey}`)
                    get_result = get_result.result
                    ini_txt = 'List Surah:\n'
                    for (var x in get_result) {
                    ini_txt += `${x}. ${get_result[x]}\n`
                    }
                    reply(ini_txt)
                    break
        case 'alquran':
                    if (!isRegister) return reply(ind.noregis())
		            if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    if (args.length < 1) return reply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
                    urls = `http://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${lolkey}`
                    quran = await fetchJson(urls)
                    result = quran.result
                    ayat = result.ayat
                    ini_txt = `QS. ${result.surah} : 1-${ayat.length}\n\n`
                    for (var x of ayat) {
                    arab = x.arab
                    nomor = x.ayat
                    latin = x.latin
                    indo = x.indonesia
                    ini_txt += `${arab}\n${nomor}. ${latin}\n${indo}\n\n`
                    }
                    ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
                    ini_txt = ini_txt.replace(/<strong>/g, "").replace(/<\/strong>/g, "")
                    ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
                    reply(ini_txt)
                    break
        case 'alquranaudio':
                    if (!isRegister) return reply(ind.noregis())
		            if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    if (args.length == 0) return reply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10`)
                    surah = args[0]
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/quran/audio/${surah}?apikey=${lolkey}`)
                    client.sendMessage(from, ini_buffer, audio, { quoted: mek, mimetype: Mimetype.mp4Audio })
                    break
       case 'asmaulhusna':
                   if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
				   reply(ind.wait())
                   get_result = await fetchJson(`http://api.lolhuman.xyz/api/asmaulhusna?apikey=${lolkey}`)
                   get_result = get_result.result
                   ini_txt = `No : ${get_result.index}\n`
                   ini_txt += `Latin: ${get_result.latin}\n`
                   ini_txt += `Arab : ${get_result.ar}\n`
                   ini_txt += `Indonesia : ${get_result.id}\n`
                   ini_txt += `English : ${get_result.en}`
                   reply(ini_txt)
                   break
     case 'kisahnabi':
                 if (!isRegister) return reply(ind.noregis())
		         if (isBanned) return reply(ind.banned())
				 reply(ind.wait())
                 if (args.length == 0) return reply(`Example: ${prefix + command} Muhammad`)
                 query = args.join(" ")
                 get_result = await fetchJson(`http://api.lolhuman.xyz/api/kisahnabi/${query}?apikey=${lolkey}`)
                 get_result = get_result.result
                 ini_txt = `*Nama* : ${get_result.name}\n`
                 ini_txt += `*Lahir* : ${get_result.thn_kelahiran}\n`
                 ini_txt += `*Umur* : ${get_result.age}\n`
                 ini_txt += `*Tempat* : ${get_result.place}\n`
                 ini_txt += `*Cerita* : \n${get_result.story}`
                 reply(ini_txt)
                 break
     case 'jadwalsholat':
                  if (!isRegister) return reply(ind.noregis())
		          if (isBanned) return reply(ind.banned())	
				  reply(ind.wait())
                  try {
                  if (args.length == 0) return reply(`Example: ${prefix + command} Pasuruan`)
                  daerah = args.join(" ")
                  get_result = await fetchJson(`http://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${lolkey}`)
                  get_result = get_result.result
                  ini_txt = `*Wilayah* : ${get_result.wilayah}\n`
                  ini_txt += `*Tanggal* : ${get_result.tanggal}\n\n`
                  ini_txt += `*Sahur* : ${get_result.sahur}\n`
                  ini_txt += `*Imsak* : ${get_result.imsak}\n`
                  ini_txt += `*Subuh* : ${get_result.subuh}\n`
                  ini_txt += `*Terbit* : ${get_result.terbit}\n`
                  ini_txt += `*Dhuha* : ${get_result.dhuha}\n`
                  ini_txt += `*Dzuhur* : ${get_result.dzuhur}\n`
                  ini_txt += `*Ashar* : ${get_result.ashar}\n`
                  ini_txt += `*Maghrib* : ${get_result.maghrib}\n`
                  ini_txt += `*Isya* : ${get_result.isya}`
                  reply(ini_txt)
                  } catch (e) {			
				  reply(`「 ❗ 」\n\n*MAAF, TERJADI KESALAHAN ATAU WILAYAH TIDAK DI TEMUKAN*`)
				  }  
                  break
       case 'niatsholat':
                  if (!isRegister) return reply(ind.noregis())
                  if (isBanned) return reply(ind.banned())
                  if (args.length < 1) return reply(`EXAMPLE : ${prefix + command} dzuhur`)
                  reply(ind.wait())
                  yy = await fetchJson(`https://api.lolhuman.xyz/api/niatsholat/${q}?apikey=${lolkey}`)
                  rr = yy.result
                  nnts = `──「 NIAT SHOLAT 」──\n\n`
                  nnts += `*TITLE :* ${rr.name}\n`
                  nnts += `───\n`
                  nnts += `*ARAB :* ${rr.ar}\n`
                  nnts += `───\n`
                  nnts += `*LATIN :* ${rr.latin}\n`
                  nnts += `───\n`
                  nnts += `*INDO :* ${rr.id}`
                  reply(nnts)
                  break
       case 'odel':
       case 'del':
       case 'delete':
                   if (!isRegister) return reply(ind.noregis())
                   if (!isPrem) return reply(ind.prem())
                   client.deleteMessage(from, { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true })
                  .else
                   break	
        case 'sewa':{
               	if (!isRegister) return reply(ind.noregis())
                   if (!isOwner && !mek.key.fromMe) return reply(ind.ownerb())
                   if(!isGroup) return reply(ind.groupo())
                   if (args[0].toLowerCase() === 'add') {
                   _sewa.addSewaGroup(from, args[1], sewa)
                   reply(`Succes...`)
                   } else if (args[0].toLowerCase() === 'dell') {
                   sewa.splice(_sewa.getSewaPosition(from, sewa), 1)
                   fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa))
                   reply(`Succes...`)
                   } else {
                   }
                   }
                   break
         case 'sewalist': 
         case 'listsewa':
                   if (!isRegister) return reply(ind.noregis())
                   let txtnyee = `List Sewa\nJumlah : ${sewa.length}\n\n`
                   for (let i of sewa){
                   let ccekvipp = ms(i.expired - Date.now())
                   txtnyee += `*ID :* ${i.id} \n*Expire :* ${ccekvipp.days} day(s) ${ccekvipp.hours} hour(s) ${ccekvipp.minutes} minute(s) ${ccekvipp.seconds} second(s)\n\n`
                   }
                   reply(txtnyee)
                   break
          case 'sewacheck':
          case 'ceksewa': 
          case 'sewacek':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
                    if (!isSewa) return reply(`Group ini tidak terdaftar dalam list sewabot. Ketik ${prefix}sewabot untuk info lebih lanjut`)
                    let ceekvip = ms(_sewa.getSewaExpired(from, sewa) - Date.now())
                    let sewenye = `「 *SEWA EXPIRE* 」

➸ *ID*: ${from}
➸ *EXPIRE :* ${ceekvip.days} Hari, ${ceekvip.hours} Jam, ${ceekvip.minutes} Menit, ${ceekvip.seconds} Detik`
                    reply(sewenye)
                    break			
         case 'antikasar':
                    if (!isRegister) return reply(ind.noregis())
			        if (isBanned) return reply(ind.banned())
				    if (!isGroup) return reply(ind.groupo())
				    if (!isGroupAdmins) return reply(ind.admin())
                    if (args.length === 0) return reply(`Pilih enable atau disable`)
                    if (args[0] == 'aktif'){
                    if (isBadword) return reply(`Udah aktif`)
                    grupbadword.push(from)
                    fs.writeFileSync('./database/antikasar.json', JSON.stringify(grupbadword))
                    reply(`antibadword grup aktif`)
                    } else if (args[0] == 'mati'){
                    anu = grupbadword.indexOf(from)
                    grupbadword.splice(anu, 1)
                    fs.writeFileSync('./database/antikasar.json', JSON.stringify(grupbadword))
                    reply('antibadword grup nonaktif')
             	   } else {
                    reply(ind.satukos(prefix, command))
                	}
                    break
        case 'prem':
        case 'premium':{
                  if (!isOwner) return reply(ind.ownerb())
                  if (args[0].startsWith('08')) return reply(`GUNAKAN KODE NEGARA!!\nEXAMPLE : ${prefix + command} add/dell 62812345678910`)
                  if (args[0].startsWith("+62")) return reply(`EXAMPLE : ${prefix + command} add/dell 62812345678910`)
                  const arxx = body.split(' ')
                  if (arxx[1] == 'add') {
                  _prem.addPremiumUser(arxx[2] + '@s.whatsapp.net', args[2], premium)
                  reply(`*「 PREMIUM ADDED 」*\n\n➸ *NOMOR :* ${arxx[2]}\n➸ *EXPIRED :*\n\`\`\`◦➛ ${ms(toMs(args[2])).days} DAYS\n◦➛ ${ms(toMs(args[2])).hours} HOUR\n◦➛ ${ms(toMs(args[2])).minutes} MINUTE\n◦➛ ${ms(toMs(args[2])).seconds} SECOND\`\`\``)
                  } else if (arxx[1] == 'dell') {
                  premium.splice(_prem.getPremiumPosition(arxx[2] + '@s.whatsapp.net', premium), 1)
                  fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
                  reply('_DONE..._')
                  } else {
                  client.sendMessage(`${nomerowner}@s.whatsapp.net`, `*FORMAT SALAH!!*\n\nEXAMPLE : \n${prefix + command} add @TAG TARGET waktu\nUNTUK MENAMBAHKAN USER KE DATA USER PREMIUM\n─ ─ ─\n${prefix + command} dell @TAG TARGET\nUNTUK MENGHAPUS USER DARI DATA USER PREMIUM\n─ ─ ─\nD = DAYS/HARI\nH = HOUR/JAM\nM = MINUTE/MENIT\nS = SECOND/DETIK\n\n*JADI UNTUK WAKTUNYA KAMU ISI TERSERAH SESUAI KEMAUAN KAMU, CONTOH 1D BERARTI 1HARI. DST*`, MessageType.text, {quoted:mek})
                  }
                  }
                  break
       case 'cekprem':
       case 'premcek':
       case 'cekpremium':
       case 'premiumcek':
                   if (!isRegister) return reply(ind.noregis())
                   if (!isPrem) return reply(ind.prem())
                   let cekvip = ms(getPremiumExpired(sender, premium) - Date.now())
                   let premiumnya = `➸ *EXPIRED :*\n\`\`\`◦➛ ${cekvip.days} HARI\n◦➛ ${cekvip.hours} JAM\n◦➛ ${cekvip.minutes} MENIT\n◦➛ ${cekvip.seconds} DETIK\`\`\``
                   reply(`${isOwner ? 'UNLIMITED OWNER' : premiumnya}`)
                   break
     case 'listprem':
     case 'listpremium':
     case 'premiumlist':
     case 'premlist':
                   if (!isRegister) return reply(ind.noregis())
                   let txxt = `「 LIST PREMIUM 」\n\n*➛ JUMLAH :* ${premium.length}\n\n`
                   let men = [];
                   for (let i of premium){
                   men.push(i.id)
                   let cekvip = ms(i.expired - Date.now())
                   txxt += `*⬡ NOMOR : ${i.id.split("@")[0]}*\n\`\`\`- EXPIRED :\n  ◦ ${cekvip.days} DAYS\n  ◦ ${cekvip.hours} HOUR\n  ◦ ${cekvip.minutes} MINUTE\n  ◦ ${cekvip.seconds} SECOND\`\`\`\n\n─ ─ ─ ─ ─\n`
                   }
                   reply(`${txxt}`)
                   break
       case 'slot2':
                   const somtoy = sotoy[Math.floor(Math.random() * sotoy.length)]
                   client.sendMessage(from, `[  🎰 | SLOTS ]\n-----------------\n🍋 : 🍌 : 🍍\n${somtoy}<=====\n🍋 : 🍌 : 🍍\n[  🎰 | SLOTS ]\n\nKeterangan : Jika anda Mendapatkan 3Buah Sama Berarti Kamu Win\n\nContoh : 🍌 : 🍌 : 🍌<=====`, text, { quoted: mek })
                   break
        case 'slot':
		      	 slot = `╭───────────────\n`
		           slot += `│  ╭────[ *SLOT* ]────\n`
			       slot += `│  │➻ ${slot11} │ ${slot22} │ ${slot33}\n`
			       slot += `│  │➻ ${slot44} │ ${slot55} │ ${slot66}<=====\n`
		           slot += `│  │➻ ${slot77} │ ${slot88} │ ${slot99}\n`		 
		           slot += `│  ╰─────────────\n`
			       slot += `╰───────────────`
			       client.sendMessage(from, slot, text, {quoted: mek})
		           break
      case 'banadd':
				  if (!isOwner) return reply(ind.ownerb())
				  bnnd = body.slice(5)
				  ban.push(`${bnnd}@s.whatsapp.net`)
				  fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
				  reply(`Nomor Berhasil Dibanned!`)
				  break
		case 'bandell':
				  if (!isOwner) return reply(ind.ownerb())
				  bnnd = body.slice(7)
				  ban.splice(`${bnnd}@s.whatsapp.net`, 1)
				  fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
				  reply(`Nomor Berhasil Di Unban!`)
				  break
       case 'buggc':
                  if (!isRegister) return reply(ind.noregis())
                  if (!isGroup) return reply(ind.groupo())
                  if (!isPrem) return reply(ind.prem())
                  await client.toggleDisappearingMessages(from)
                  client.sendMessage(from, `Suksess`, text)
                  break
       case 'buylimit':
                  if (args.length < 1) return reply(`Berapa limit yang mau di beli? Pastikan saldo ATM cukup juga! \n\nCara cek saldo : ${prefix}dompet`)
                  if (!isRegister) return reply(ind.noregis())
                  if (isBanned) return reply(ind.banned())
                  payout = body.slice(10)
                  const koinPerlimit = hargalimit
                  const total = koinPerlimit * payout
                  if (checkATMuser(sender) <= total) return reply(`Maaf Uang Kamu Belum Mencukupi. Silahkan Kumpulkan Dan Beli Nanti`)
                  if (checkATMuser(sender) >= total) {
                  confirmATM(sender, total)
                  bayarLimit(sender, payout)
                  await reply(`〘 *NOTA PEMBAYARAN* 〙\n\n‣ *Pengirim* : Admin\n‣ *Penerima* : ${pushname}\n‣ *Nominal Pembelian* : ${body.slice(10)} \n‣ *Harga Limit* : ${koinPerlimit}/limit\n‣ *Sisa Saldo* : Rp.${checkATMuser(sender)}\n\n*PROSES PEMBAYARAN BERHASIL SEMOGA BERMANFAAT 😍*`)
                  }
                  break
    case 'banlist':
                if (!isRegister) return reply(ind.noregis())
				if (isBanned) return reply(ind.banned())
				client.updatePresence(from, Presence.composing) 
				teks = 'Berikut Nomor" Yg Telah Dibanned :\n'
				for (let benn of ban) {
				teks += `~> @${benn.split('@')[0]}\n`
				}
				teks += `Total : ${ban.length}`
				client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": ban}})
				break
     case 'leaderboard':
     case 'lb':
                  if (!isRegister) return reply(ind.noregis())
				  if (isBanned) return reply(ind.banned())
				  _level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
				  uang.sort((a, b) => (a.uang < b.uang) ? 1 : -1)
				  let leaderboardlvl = '-----[ *LEADERBOARD LEVEL* ]----\n\n'
				  let leaderboarduang = '-----[ *LEADERBOARD UANG* ]----\n\n'
				  let nom = 0
				  try {
				  for (let i = 0; i < 10; i++) {
				  nom++
				  leaderboardlvl += `*[${nom}]* ${_level[i].id.replace('@s.whatsapp.net', '')}\n◪  *XP*: ${_level[i].xp}\n◪  *Level*: ${_level[i].level}\n`
				  leaderboarduang += `*[${nom}]* ${uang[i].id.replace('@s.whatsapp.net', '')}\n◪  *Uang*: _Rp${uang[i].uang}_\n◪  *Limit*: ${limitawal - _limit[i].limit}\n`
				  }
				  await reply(leaderboardlvl)
				  await reply(leaderboarduang)
				  } catch (err) {
				  console.error(err)
				  await reply(`minimal 10 user untuk bisa mengakses database`)
				  }
		          break
       case 'limit':
       case 'ceklimit':
       case 'balance':
       case 'glimit':
       case 'dompet':
                  if (isBanned) return reply(ind.banned())
                  if (!isRegister) return reply(ind.noregis())
reply(`*Selamat ${waktoo} @${sender.split("@")[0]}*✨

*⬡ Limit : ${isPrem ? 'Unlimited Premium' : `${getLimit(sender, limitawal, limit)} / ${limitawal}`}*
*⬡ Limit Game : ${cekGLimit(sender, gcount, glimit)} / ${gcount}*
*⬡ Balance : $${getBalance(sender, balance)}*


Kamu Dapat Membeli Limit Dengan ${prefix}Buylimit *Nominal* Dan ${prefix}Buyglimit *Nominal* Untuk Membeli Game Limit

*EXAMPLE :*
${prefix}buylimit 10
${prefix}buyglimit 10

NOTE : 
- Harga Limit Perlimit adalah $100 balance`)
                    break
        case 'setnamaowner':
		        	if (!isOwner) return reply(ind.ownerb())
					client.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					namaowner = body.slice(14)
					reply(`nama owner berhasil di ubah menjadi : ${namaowner}`)
				    await sleep(5000)
                    break 
        case 'setnamabot':
		        	if (!isOwner) return reply(ind.ownerb())
					client.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					namabot = body.slice(12)
					reply(`nama bot berhasil di ubah menjadi : ${namabot}`)
				    break
        case 'daftar':
        case 'verify':
        case 'register':
        case 'registrasi':
                    if (isRegister) return reply('Kamu Sudah Pernah Melakukan Registrasi Sebelumnya..')        
                    const serialUser = createSerial(10)
                    addRegisterUser(sender, pushname, `20`, time, serialUser)      
                    daftar1 =`─ 「 *REGISTRATION* 」 ─\n\n`
                    daftar1 += `⬡ NAMA : ${pushname}\n`
                    daftar1 += `⬡ NOMOR : ${sender.split("@")[0]}\n`
                    daftar1 += `⬡ SN : ${serialUser}`
                    reply(daftar1)
                    addLevelingId(sender)
                    break
	    case 'mining':
	    case 'bonus':
	    case 'claim':
                    if (!isRegister) return reply(ind.noregis())
					if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			    	if (isBanned) return reply(ind.banned())
			        if (isOwner | isAdmin | isPrem) {
				    const mathxpnye = Math.floor(Math.random() * 3000) + 2100
					addLevelingXp(sender, mathxpnye)
					const Money = Math.floor(Math.random() * 1000) + 700
					addKoinUser(sender, Money)
					await reply(`*── 「 CLAIM  」 ──*\n\nSelamat kamu mendapatkan\n*${mathxpnye} Xp* dan *${Money}* balance Dari claim harian`)
	            	} else {
					const Moneyy = Math.floor(Math.random() * 1000) + 700
					addKoinUser(sender, Moneyy)
					const onee = Math.floor(Math.random() * 3000) + 2100
					addLevelingXp(sender, onee)
					await reply(`*── 「 CLAIM  」 ──*\n\nSelamat kamu mendapatkan\n*${onee} Xp* dan *${Moneyy}* balance Dari claim harian`)
					}
					limitAdd(sender, limit)
					break
        case 'miningpro':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isOwner) return reply(ind.ownerb())
					if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        if (isOwner | isAdmin | isPrem) {
				    const mathxpnyee = Math.floor(Math.random() * 10000) + 5000
					addLevelingXp(sender, mathxpnyee)
					const Moneyyy = Math.floor(Math.random() * 5000) + 4000
					addKoinUser(sender, Moneyyy)
					await reply(`*── 「 CLAIM  」 ──*\n\nSelamat kamu mendapatkan\n*${mathxpnyee} Xp* dan *${Moneyyy}* balance Dari claim harian`)
					}
					limitAdd(sender, limit)
					break
        case 'status':
        case 'stats':
        case 'info':
        case 'infobot':
        case 'botinfo':
                   if (!isRegister) return reply(ind.noregis())
                   let i = []
                   let giid = []
                   for (let mem of totalchat){
                   i.push(mem.jid)
                   }
                   for (let id of i){
                   if (id && id.includes('g.us')){
                   giid.push(id)
                   }
                   }
                   const { wa_version, mcc, mnc, os_version, device_manufacturer, device_model } = client.user.phone
                   const processTime = (timestamp, now) => {
                   return moment.duration(now - moment(timestamp * 1000)).asSeconds()} 
                   nunie = nomerowner + '@s.whatsapp.net'
                   tteks = `─── 「 *INFO BOT* 」 ───

⬡ *NAMA BOT :* ${namabot}
⬡ *OWNER :* @${nunie.split("@")[0]}
⬡ *PREFIX :* 「 *MULTI* 」
⬡ *RUNTIME :* ${kyun(process.uptime())}
⬡ *SPEED :* ${processTime(mek.messageTimestamp.low, moment())} Detik

⬡ *V. WHATSAPP :* ${wa_version}
⬡ *BATERAI :* ${battre}%
⬡ *CHARGE :*  ${baterai.cas === 'true' ? 'Di Cas' : 'Tidak Di Cas'}
⬡ *RAM :* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
⬡ *MCC :* ${mcc}
⬡ *MNC :* ${mnc}
⬡ *VERSI OS :* ${os_version}
⬡ *MERK HP :* ${device_manufacturer}
⬡ *VERSI HP :* ${device_model}

⬡ *TOTAL PERSONAL CHAT :* ${totalchat.length - giid.length}
⬡ *TOTAL GROUP CHAT :* ${giid.length}
⬡ *TOTAL CHAT :* ${totalchat.length}
⬡ *TOTAL USER :* ${_registered.length}
⬡ *TOTAL BLOCK :* ${blocked.length}
⬡ *TOTAL BANED :* ${ban.length}

─ 「 *TQTO* 」 ─
⬡ *FARID*
⬡ *ADITYA*
⬡ *AQUL*
⬡ *ARYA MANIK*
⬡ *ALDI FAUZI*
⬡ *BENNY HIDAYAT*
⬡ *LOLHUMAN*
⬡ *MHANKBARBAR*
⬡ *ALL CREATOR BOT*`
                   client.sendMessage(from, gambar, image, {thumbnail:gambar2, quoted: mek, caption: tteks, contextInfo:{mentionedJid: [nunie]}})
                   break
        case 'botgrup':
        case 'grupbot':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    menunye = `Link Grup Owner Bot\nhttps://chat.whatsapp.com/LU0cC941P7IGkV5LfWJylJ \n\nJangan Lupa Join Ya Kak`
                    client.sendMessage(from, menunye, text,)
                    break
		case 'donasi':
    	case 'donate':		
                    if (!isRegister) return reply(ind.noregis())
                    client.sendMessage(from, donasi(namabot, gopay, pulsa, dana, shopeepay, ovo), text)
					break
		case 'level':{					
                    if (!isRegister) return reply(ind.noregis())
                    reply(`@${sender.split("@")[0]}\n\n*⬡ Level : ${getLevelingLevel(sender)}*\n*⬡ Xp : ${getLevelingXp(sender)}*`)
                    }
                    break
        case 'tes':
                    N = '```Bot On Kak Gunakan Dengan\nBijak!```'
                    client.sendMessage(from, N, text, { quoted: mek})
                    break
       case 'runtime':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   uptime = process.uptime()
                   N = `*── 「 BOT AKIRAA 」 ──*\n\n❏ Telah Berjalan Selama *${kyun(uptime)}*`
                   client.sendMessage(from, N, text, { quoted: mek})
                   break
       case 'rules':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.banned())
                   reply(menu.rules(prefix))
                   break
		case 'snk':
		           if (!isRegister) return reply(ind.noregis())
				   replybutton1(from, `${prefix}menu`, `𝚁𝙴𝙶𝙰𝚁𝙳𝚂 : 𝙵𝙰𝚁𝙸𝙳 𝙼𝙰𝙷𝙰𝚁𝙳𝙸𝙺𝙰 || ${nomerowner}\n𝚂𝚄𝙳𝙰𝙷 𝙵𝙰𝙷𝙰𝙼 ? 𝙺𝙻𝙸𝙺 𝙼𝙴𝙽𝚄!`,`⋮☰ MENU`,`⚠️ *SYARAT DAN KETENTUAN* ⚠️

*1. Pengguna dapat menggunakan semua perintah/command dengan batasan limit, terkecuali user premium dengan limit tanpa batas/unlimited, dan tidak melakukan spam terhadap bot.*
*2. Dilarang keras mengirim pesan V dan semacamnya yang membuat server down ataupun bot crash*
*3. Pengguna yang mengirim hal atau data pribadi tidak akan disimpan oleh bot ini, dan tidak akan bertanggung jawab atas data pribadi tersebut!*
*4. Kami tidak pernah meminta anda untuk memberikan informasi pribadi.*

┌─ ❗ *RULES* ❗ ─
│1. Jangan spam bot. 
│Sanksi: *WARN/SOFT BLOCK*
│
│2. Jangan telepon bot.
│Sanksi: *SOFT BLOCK*
│
│3. Jangan mengeksploitasi bot.
│Sanksi: *PERMANENT BLOCK*
└──────────

_Note : Bot ini menggunakan autoread atau langsung membaca pesan yang pengguna kirim_`)
                     break		
		case 'request':
					 const cfrr = body.slice(8)
					 if (cfrr.length > 300) return client.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', msgType.text, {quoted: mek})
				     var nomor = mek.participant
				     const ress = `*[ REQUEST FITUR ]*\n\n*Nama :* ${pushname}\n*Nomor :* wa.me/${sender.split("@")[0]}\n*Hari :* ${tampilBulan}\n*Jam :* ${tampilJam}\n*Pesan :* ${cfrr}`
			         var options = {
				     text: ress,
                     contextInfo: {mentionedJid: [nomor]},
                 	}
			         client.sendMessage(`${nomerowner}@s.whatsapp.net`, options, text, {quoted: mek})
					 reply('REQUEST ANDA TELAH SAMPAI KE OWNER BOT REQUEST PALSU ATAU MAIN² TIDAK AKAN DITANGGAPI.')
				     break
	    case 'lapor':
					 const crfgh = body.slice(6)
					 if (crfgh.length > 300) return client.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', msgType.text, {quoted: mek})
					 var nomor = mek.participant
					 const pesanga = `*[ MELAPORKAN FITUR ]*\n\n*Nama :* ${pushname}\n*Nomor :* wa.me/${sender.split("@")[0]}\n*Hari :* ${tampilBulan}\n*Jam :* ${tampilJam}\n*Pesan :* ${crfgh}`
				     var options = {
					 text: pesanga,
                 	contextInfo: {mentionedJid: [nomor]},
                 	}
			         client.sendMessage(`${nomerowner}@s.whatsapp.net`, options, text, {quoted: mek})
					 reply('LAPORAN ANDA TELAH SAMPAI KE OWNER BOT SILAKAN TUNGGU RESPON DARI OWNER!')
					 break
       case 'kontak':
       case 'kontag':
       case 'sendkontak':
                   if (!isRegister) return reply(ind.noregis())
                   if (args.length == 0) return reply(`Contoh : *${prefix + command} 628121000000*`)
                   pefe = args.join(' ') 
                   vcardd = 'BEGIN:VCARD\n'
                   + 'VERSION:3.0\n'
                   + `FN:${pefe}\n`
                   + `TEL;type=CELL;type=VOICE;waid=${pefe}:${PhoneNumber('+' + pefe).getNumber('internasional')}\n`
                   + 'END:VCARD'.trim()
                   client.sendMessage(from, {displayName: `${pefe}`, vcard: vcardd}, contact)
                   break   
		case 'blocklist': 
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
					teks = 'Nomor Yg Terblokir :\n'
					for (let block of blocked) {
					teks += `*~>* @${block.split('@')[0]}\n`
					}
					teks += `*Total* : ${blocked.length}`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break
        case 'ffstalk':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Idnya mana kak?`)
                    reply(ind.wait()) 
                    ff_id = args[0]
                    get_result = await fetchJson(`https://lolhuman.herokuapp.com/api/freefire/${ff_id}?apikey=${lolkey}`)
                    reply(get_result.result)
                    break
        case 'hidetag':					
                    if (!isRegister) return reply(ind.noregis())
					if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			    	if (isBanned) return reply(ind.banned())
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					var value = body.slice(9)
					var group = await client.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: mek
					}
					client.sendMessage(from, options, text)
					limitAdd(sender, limit)
					break
          case 'afk':
                     if (!isRegister) return reply(ind.noregis())
                     if (!isGroup) return reply(ind.groupo())
                     if (isAfkOn) return reply(`\`\`\`KAMU SEDANG DI DALAM MODE AFK\`\`\``)
                     reason = q ? q : 'Nggak Jelas'
                     afk.addAfkUser(sender, time, reason, _afk)
                     if (pushname === undefined) return reply(`- Sedang Afk Dengan Alasan ${reason} Sejak ${time}`)
                     reply(`@${sender.split("@")[0]} Telah Afk Dengan Alasan ${reason} ~`)
                     break
         case 'mute':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
                    if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(ind.admin())
                    if (isMuted) return reply(`Udah Di Mute Sebelumnya`)
                    mute.push(from)
                    fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
                    reply('Bot Berhasi Di Mute Di Grup Ini Sekarang Hanya Admin Yg Dapat Gunain Bot')
                    break
       case 'myinfo':
       case 'profile': 
       case 'profil':{
                   var p = await client.getStatus(`${sender}`, MessageType.text)
                   try {
                   ppimk = await client.getProfilePicture(`${sender.split('@')[0]}@c.us`)
                   } catch {
                   ppimk = `${imagebb}`
                   }
                   puser = await getBuffer(ppimk)
                   let cegk = ms(getPremiumExpired(sender, premium) - Date.now())
                   client.sendMessage(from, puser, image, {thumbnail:gambar, caption:`── *PROFILE* ──

▢ Nama : ${pushname==undefined?sender.split("@")[0]:pushname}
▢ Bio : ${p.status==undefined?`Not Found`:p.status}
▢ Tag : @${sender.split("@")[0]}
▢ Api : wa.me/${sender.split("@")[0]}

⬡ Limit : ${isPrem ? 'Unlimited Premium' : `${getLimit(sender, limitawal, limit)} / ${limitawal}`}
⬡ Game Limit : ${cekGLimit(sender, gcount, glimit)} / ${gcount}
⬡ Balance : $${getBalance(sender, balance)}
⬡ Role : ${role}
⬡ Level : ${getLevelingLevel(sender)}
⬡ Xp : ${getLevelingXp(sender)}

⬣ Status : ${isOwner?`Owner`:isPrem?`Premium User
⬣ Expired Prem : ${cegk.days} Hari, ${cegk.hours} Jam, ${cegk.minutes} Menit, ${cegk.seconds} Detik`:isUser?`Free User`:`Belum Daftar`}
⬣ Baned : ${isBanned?`Terbanned`:`Tidak Terbanned`}
⬣ Baned Antidelete : ${isBanCtRevoke?`Terbanned`:`Tidak Terbanned`}`, quoted: mek, contextInfo:{mentionedJid:[sender]}})
                      }
                      break
	      case 'getpic':
          case 'getpp':{
                      if (!isRegister) return reply(ind.noregis())
                      if (!isGroup) return reply(ind.groupo())
                      if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply(`Tag Target Yg Ingin Di Ambil PP nya!`)
                      reply(ind.wait())
                      mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
                      try {
                      ppusk = await client.getProfilePicture(mentioned)
                      getbufp = await getBuffer(ppusk)
                      client.sendMessage(from, getbufp, image, {caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                      } catch (e) {
                      client.sendMessage(from, `Gagal Saat Mengambil Foto Target`, text, {quoted: mek})
                      }
                      }
                      break  
		   case 'sethargalimit':
					  if (args.length < 1) return
		          	if (!isOwner) return reply(ind.ownerb())
					  client.updatePresence(from, Presence.composing) 
					  hargalimit = body.slice(15)
					  reply(`harga limit berhasil di ubah menjadi : ${hargalimit}`)
			      	break 
           case 'setwaktugametb':
					  if (args.length < 1) return
		          	if (!isOwner) return reply(ind.ownerb())
					  client.updatePresence(from, Presence.composing) 
				      gamewaktu = body.slice(16)
					  reply(`waktu game berhasil di ubah menjadi : ${gamewaktu}`)
	              	break 
	       case 'setdeskripsi':
	       case 'setdesc':
           case 'setdesk':
                      if (!isRegister) return reply(ind.noregis())
                      if (!isGroup) return reply(ind.groupo())
                      if (!isGroupAdmins) return reply(ind.admin())
                      if (!isBotGroupAdmins) return reply(ind.badmin())
                      client.groupUpdateDescription(from, `${body.slice(9)}`)
                      client.sendMessage(from, 'Sukses, Ganti Deskripsi Grup', text, {quoted: mek})
                      break
          case 'linkgc':
		      		if (!isGroup) return reply(ind.groupo())
		          	if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
		          	if (!isBotGroupAdmins) return reply(ind.badmin())
		          	linkgc = await client.groupInviteCode (from)
		          	yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
		          	client.sendMessage(from, yeh, text, {quoted: mek})
		          	limitAdd(sender, limit)
				      break
          case 'add':
                      try {
                      if (!isGroup) return reply(ind.groupo())
                      if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(ind.admin())           
                      if (!isBotGroupAdmins) return reply(`Jadikan Bot Sebagai Admin Group!`)
                      if (mek.message.extendedTextMessage === null || mek.message.extendedTextMessage === undefined) {
                      entah = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`
                      response = await client.groupAdd(from, [entah])
                      o = response.participants[0]
                      let inv = (Object.values(o))
                      if(inv[0].code == 409) return reply('Target Sudah Di Didalam Group!')
                      if(inv[0].code == 403) return reply('Gagal, Karena Di Private T_T')
                      if(inv[0].code == 408) return reply('Gagal, Karena Target Baru² Saja Keluar')
                      if(inv[0].code == 401) return reply('Gagal, Karena Bot Di Block Oleh Target T_T')
                      } else {
                      entah = mek.message.extendedTextMessage.contextInfo.participant
                      response = await client.groupAdd(from, [entah])
                      o = response.participants[0]
                      let inv = (Object.values(o))
                      if(inv[0].code == 409) return reply('Target Sudah Di Didalam Group!')
                      if(inv[0].code == 403) return reply('Gagal, Karena Di Private T_T')
                      if(inv[0].code == 408) return reply('Gagal, Karena Target Baru² Saja Keluar')
                      if(inv[0].code == 401) return reply('Gagal, Karena Bot Di Block Oleh Target T_T')
                      }
                      } catch {
                      return 
                      }
                      break
         case 'kick':
         case 'tendang':
         case 'headsot':
                     if (!isGroup) return reply(ind.groupo())
                     if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(ind.admin()) 
                     if (!isBotGroupAdmins) return reply(`Jadikan Bot Sebagai Admin Group!`)
                     kick(from, mentionUser)
                     break
	       case 'bot':
					  client.sendMessage(from, 'Dari Pada Gabut Mending Ketik .menu' ,MessageType.text, { quoted: mek} )
					  break
	   	case 'wame':
                      if (!isRegister) return reply(ind.noregis())
                      if (isBanned) return reply(ind.banned())
  					if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
  					client.updatePresence(from, Presence.composing) 
  					options = {
  					text: `*Nih Kak ${pushname} Link Nomor Wa Lu*\n\n*➢ wa.me/${sender.split("@s.whatsapp.net")[0]}*`,
  					contextInfo: { mentionedJid: [sender] }
  					}
  					client.sendMessage(from, options, text, { quoted: mek } )
  					break
  					if (data.error) return reply(data.error)
  					reply(data.result)
					  limitAdd(sender, limit)
  				    break
	 	case 'tagall':
	                 if (!isRegister) return reply(ind.noregis())
		   		  if (!isGroup) return reply(ind.groupo())
					 members_id = []
					 pssan = body.slice(7)
					 teks = `╔══✪〘 *MENTION ALL* 〙✪══\n`
					 teks += `╠➥ *PESAN* : ${pssan}\n`
					 for (let mem of groupMembers) {
					 teks += `╠➥ @${mem.jid.split('@')[0]}\n`
					 members_id.push(mem.jid)
				     }
					 mentions(teks, members_id, true)
					 break
		case 'clearall':
					if (!isOwner) return reply(ind.ownerb())
					anu = await client.chats.all()
					client.setMaxListeners(25)
					for (let _ of anu) {
					client.deleteChat(_.jid)
					}
					reply(`*Clear all Success*`)
					break
        case 'fisheye':
        case 'skullmask':
        case 'alien':
        case 'tosmile':
        case 'cartoon':
        case 'invert':
        case 'pixelate':
        case 'flip':
        case 'grayscale':
        case 'roundimage':
        case 'pencil':
        case 'wasted':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    var imgbb = require('imgbb-uploader')
                    if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
                    ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
                    owgi = await client.downloadAndSaveMediaMessage(ted)
                    dpaa = await imgbb('3b8594f4cb11895f4084291bc655e510', owgi)
                    uhyy = await getBuffer(`https://api.lolhuman.xyz/api/editor/${command}?apikey=${lolkey}&img=${dpaa.display_url}`)
                    client.sendMessage(from, uhyy, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    } else {
                    reply('Reply Imagenya!!')
                    }
                    break
        case 'affect':
        case 'beautiful':
        case 'facepalm':
        case 'hitler':
        case 'jail':
        case 'rip':
        case 'sepia':
        case 'trash':
        case 'wanted':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    var imgbb = require('imgbb-uploader')
                    if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
                    reply(ind.wait())
                    ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
                    owgi = await client.downloadAndSaveMediaMessage(ted)
                    dpaa = await imgbb('3b8594f4cb11895f4084291bc655e510', owgi)
                    uhyy = await getBuffer(`https://api.lolhuman.xyz/api/creator1/${command}?apikey=${lolkey}&img=${dpaa.display_url}`)
                    client.sendMessage(from, uhyy, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    } else {
                    reply('Reply Imagenya!!')
                    }
                    break
        case 'setlimit':
                    if (!isOwner) return reply(ind.ownerb)
                    if (args.length < 1) return
                    limitawal = args[0]
                    reply(`Limit berhasil di ubah menjadi : ${limitawal}`)
                    break
        case 'resetlimit':
                    if (!isOwner && !mek.key.fromMe) return reply(ind.ownerb())
                    client.updatePresence(from, Presence.avaible) 
                    fs.writeFileSync('./database/limit.json', ('[]'))
                    fs.writeFileSync('./database/glimit.json', ('[]'))
                    reply('Succes Sluur~')  
                    await sleep(5000)
                    break
        case 'simisimi':
        case 'simih':
			        if (!isGroup) return reply(ind.groupo())
				    if (args.length < 1) return reply(ind.satukos(prefix, command))
				    if (args[0] === 'aktif') {
				    if (isSimi) return reply(`Fitur ${command} sudah aktif`)
				    samih.push(from)
			        fs.writeFileSync('./database/simi.json', JSON.stringify(samih))
				    reply(`*SUKSES MENGAKTIFKAN FITUR SIMIH DI GRUP INI!*`)
			        } else if (args[0] === 'mati') {
                    var uni = samih.indexOf(from)
				    samih.splice(uni, 1)
			        fs.writeFileSync('./database/simi.json', JSON.stringify(samih))
				    reply(`*SUKSES MENONAKTIFKAN FITUR SIMIH DI GRUP INI!*`)
				    } else {
				    reply(ind.satukos(prefix, command))
				    }
				    break
		case 'leave':
                    if (!isRegister) return reply(ind.noregis())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					setTimeout( () => {
					client.groupLeave (from) 
					}, 2000)
					setTimeout( () => {
					client.updatePresence(from, Presence.composing) 
					client.sendMessage(from, 'Bye cuk🗣', text) // ur cods
					}, 0)
					break
        case 'readall':
					if (!isRegister) return reply(ind.noregis())
					if (!isOwner) return reply(ind.ownerb())
				    var chats = await client.chats.all()
                    chats.map( async ({ jid }) => {
                    await client.chatRead(jid)
                    })
					rdl = `Berhasil membaca ${chats.length} Chat`
				    client.sendMessage(from, rdl, text, { quoted: mek})
					break
		case 'bc': 
					if (!isOwner) return reply(ind.ownerb()) 
					if (args.length < 1) return reply('.....')
					anu = await client.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
					const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
					buff = await client.downloadMediaMessage(encmedia)
					for (let _ of anu) {
					client.sendMessage(_.jid, buff, image, {caption: `*「 AKIRAA BROADCAST 」*\n\n${body.slice(4)}`})
					}
					reply('*Suksess Broadcast* ')
					} else {
					for (let _ of anu) {
					sendMess(_.jid, `*「 AKIRAA BROADCAST 」*\n\n${body.slice(4)}`)
					}
					reply('*Suksess Broadcast* ')
					}
					break
        case 'grupinfo':
        case 'infogrup':
        case 'infogc':{
					if (!isRegister) return reply(ind.noregis())
               	 if (isBanned) return reply(ind.baned())    
                    if (!isGroup) return reply(ind.groupo())            
                    try {
                    ppUrl = await client.getProfilePicture(from)
                    } catch {
                    ppUrl = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
                    }
                    a = groupMetadata
                    let cekvvip = ms(_sewa.getSewaExpired(from, sewa) - Date.now())
                    gring = `━━━• *G R O U P I N F O* •━━━\n\n`
                    gring += `*◯ Nama : ${groupName}*\n`
                    gring += ` - Terakhir Di Ubah Oleh : @${a.subjectOwner.split("@")[0]}\n`
                    gring += `*◯ Waktu Dibuat :* \n`
                    gring += ` - Jam : ${moment(`${groupMetadata.creation}` * 1000).tz('Asia/Jakarta').format('HH:mm:ss')} Wib\n`
                    gring += ` - Tanggal : ${moment(`${groupMetadata.creation}` * 1000).tz('Asia/Jakarta').format('d, m, y')}\n`
                    gring += `*◯ Owner Grup : @${groupMetadata.owner.split('@')[0]}*\n`
                    gring += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ \n`
                    gring += `*⬣ Welcome : ${isWelkom ? 'On':'Off'}*\n`
                    gring += `*⬣ Anti Link : ${isAntiLink? 'On':'Off'}*\n`
                    gring += `*⬣ Anti Badword : ${isBadword? 'On':'Off'}*\n`
                    gring += `*⬣ Anti Delete : ${isRevoke? 'On':'Off'}*\n`
                    gring += `*⬣ Anti View-Once : ${isAntiVo? 'On':'Off'}*\n`
                    gring += `*⬣ Anti Fake troli bot : ${isAntro? 'On':'Off'}* ${isSewa?`\n*⬣ Expired Sewa : ${cekvvip.days} Hari, ${cekvvip.hours} Jam, ${cekvvip.minutes} Menit, ${cekvvip.seconds} Detik*`:``}\n`
                    gring += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ \n`
                    gring += `*◯ Total Member : ${groupMembers.length}*\n`
                    gring += `*◯ Total Admin : ${groupAdmins.length}*\n`
                    gring += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ \n`
                    gring += `*◯ Deskripsi Group :*\n`
                    gring += `${groupDesc}\n`
                    gring += `- *Terakhir Di Ubah Oleh : @${a.descOwner.split("@")[0]}*`
                    jkg = await getBuffer(ppUrl)
                    client.sendMessage(from, jkg, MessageType.image, {thumbnail:gambar, caption: gring, quoted: mek, contextInfo: {"mentionedJid": [groupMetadata.owner.replace('@c.us', '@s.whatsapp.net'),groupMetadata.descOwner.replace('@c.us', '@s.whatsapp.net'),groupMetadata.subjectOwner.replace('@c.us', '@s.whatsapp.net')]}})
                    }
                    break
        case 'listgrup':
        case 'gruplist':
        case 'listgroup':
                    let txy = client.chats.all().filter(v => v.jid.endsWith('g.us')).map(v =>`${client.getName(v.jid)}\n${v.jid} [${v.read_only ? 'Left' : 'Joined'}]`).join`\n\n`
                    client.sendMessage(from, txy, text, {quoted: mek})
                    break
		case 'setpp': 
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
                    if (!isBotGroupAdmins) return reply(ind.badmin())
					media = await client.downloadAndSaveMediaMessage(mek)
					await client.updateProfilePicture(from, media)
					reply('*Sukses mengganti icon group*')
					break			
		case 'grup':
		case 'group':
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (args[0] === 'buka') {
				    reply(`*BERHASIL MEMBUKA GROUP*`)
					client.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'tutup') {
					reply(`*BERHASIL MENUTUP GROUP*`)
					client.groupSettingChange(from, GroupSettingChange.messageSend, true)
					}
					break
        case 'owner':
        case 'creator':
        case 'developer':
                    client.sendMessage(from, {displayname: "Jeff", vcard: vcard}, MessageType.contact,)
                    client.sendMessage(from, `Kalo Ingin Nanya Soal Sewa Dan Seputar Info Bot Bisa Chat Owner Saya Kak ${pushname}`, text, {quoted: mek})
					break    
        case 'setnama':
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					client.groupUpdateSubject(from, `${body.slice(9)}`)
					client.sendMessage(from, 'Succes, Ganti Nama Grup', text, {quoted: mek})
					break
       case 'resetlinkgc':
       case 'resetlink':
                    if (!isRegister) return reply(ind.noregis())  
                    if (!isGroup) return reply(ind.groupo())
                    if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(ind.admin())          
                    if (!isBotGroupAdmins) return reply(ind.badmin())
                    client.query({ json: ['action', 'inviteReset', from], expect200: true })
                    reply(`Sukses Reset Link Group!`)
                    break
        case 'demote':
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 ??𝗮𝗻?? ??𝗻𝗴??𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
					teks = ''
					for (let _ of mentioned) {
					teks += `*jabatan kamu di copot*🏃 :\n`
					teks += `@_.split('@')[0]`
					}
					mentions(teks, mentioned, true)
					client.groupDemoteAdmin(from, mentioned)
					} else {
					mentions(`*Yahh Kamu @${mentioned[0].split('@')[0]} Bukan Admin Lagi Bro!*`, mentioned, true)
					client.groupDemoteAdmin(from, mentioned)
					}
					break
        case 'promote':
					if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 ??𝗮??𝗴𝗲𝘁 𝘆𝗮𝗻𝗴 𝗶𝗻??𝗶𝗻 𝗱𝗶 ??????𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
					teks = ''
					for (let _ of mentioned) {
					teks += `*Perintah Diterima, Menambahkan @${mentioned[0].split('@')[0]} Menjadi Admin Grup!*\n`
					teks += `@_.split('@')[0]`
					}
					mentions(teks, mentioned, true)
					client.groupMakeAdmin(from, mentioned)
					} else {
					mentions(`*Perintah Diterima, Menambahkan @${mentioned[0].split('@')[0]} Menjadi Admin Grup!*`, mentioned, true)
					client.groupMakeAdmin(from, mentioned)
					}
					break
	    case 'adminlist':
	    case 'listadmin':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
					if (!isGroup) return reply(ind.groupo())
					teks = `List Admin Group Ini\nTotal : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
					no += 1
					teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
        case 'welcome':{
               	if (!isRegister) return reply(ind.noregis())
                   if (!isGroup) return reply(ind.groupo())
				   if (!isGroupAdmins) return reply(ind.admin())
                   try {
                   if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(mess.only.admin)
                   if (args[0].toLowerCase() === 'aktif'){
                   if (isWelkom) return reply(`Sudah Di Aktifkan Sebelumnya!`)
                   welkom.push(from)
                   fs.writeFileSync('./database/welcome.json', JSON.stringify(welkom))
                   reply(`Succes mengaktifkan Fitur Welcome`)
                   } else if (args[0].toLowerCase() === 'mati'){
                   if (!isWelkom) return reply(`Fitur Ini Belum Pernah Di Aktifkan Di Group Ini`)
                   var ank = welkom.indexOf(from)
                   welkom.splice(ank, 1)
                   fs.writeFileSync('./database/welcome.json', JSON.stringify(welkom))
                   reply(`Succes Mematikan Fitur Welcome`)
                   }
                   } catch {
                   const buttons = [{buttonId: `${prefix}welcome aktif`, buttonText: {displayText: 'AKTIF'}, type: 1},{buttonId: `${prefix}welcome mati`, buttonText: {displayText: 'MATI'}, type: 1}]
                   const buttonMessage = {
                   headerType: "IMAGE",
                   contentText: `PILIH ON UNTUK MENGAKTIFKAN\nPILIH OFF UNTUK MEMATIKAN`,
                   footerText: `Pilih Di Bawah Ini 👇`,
                   buttons: buttons,
                   headerType: 1
                   }
                   client.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                   }
                   }
                   break
       case 'antidelete':
                   if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(ind.admin())
                   if (args.length < 1) return reply(`─ ❲ ERROR ❳ ─

Penggunaan fitur antidelete :
*${prefix}antidelete [aktif/mati]* (Untuk grup)
*${prefix}antidelete [ctaktif/ctmati]* (untuk semua kontak)
*${prefix}antidelete banct 628558xxxxxxx* (banlist kontak)`)
                  if (args[0].toLowerCase() === 'aktif') {
                  if (isGroup) {
                  if (isRevoke) return reply(`Antidelete telah diaktifkan di grup ini sebelumnya!`)
                  dataRevoke.push(from)
                  fs.writeFileSync('./database/antidelete.json', JSON.stringify(dataRevoke, null, 2))
                  reply(`Antidelete diaktifkan di grup ini!`)
                  } else if (!isGroup) {
                  reply(`Untuk kontak penggunaan *${prefix}antidelete ctaktif*`)
                  }
                  } else if (args[0].toLowerCase() === 'ctaktif') {
                  if (!isOwner) return reply(ind.ownerb())
              	if (!isGroup) {
    	      	if (isCtRevoke) return reply(`Antidelete telah diaktifkan di semua kontak sebelumnya!`)
          		dataCtRevoke.data = true
          		fs.writeFileSync('./database/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
          		reply(`Antidelete diaktifkan disemua kontak!`)
              	} else if (isGroup) {
          		reply(`Untuk grup penggunaan *${prefix}antidelete aktif*`)
              	}
                  } else if (args[0].toLowerCase() === 'banct') {
                  if (!isOwner) return reply(ind.ownerb())
              	if (isBannedCtRevoke) return reply(`kontak ini telah ada di database banlist!`)
              	if (args.length === 1 || args[1].startsWith('0')) return reply(`Masukan nomer diawali dengan 62! contoh 62859289xxxxx`)
              	dataBanCtRevoke.push(args[1].replace("@","") + '@s.whatsapp.net')
              	fs.writeFileSync('./database/ct-revoked-banlist.json', JSON.stringify(dataBanCtRevoke, null, 2))
              	reply(`Kontak ${args[1].replace("@","")} telah dimasukan ke banlist antidelete secara permanen!`)
                  } else if (args[0].toLowerCase() === 'mati') {
              	if (isGroup) {
          		const index = dataRevoke.indexOf(from)
          		dataRevoke.splice(index, 1)
          		fs.writeFileSync('./database/antidelete.json', JSON.stringify(dataRevoke, null, 2))
    	      	reply(`Antidelete dimatikan di grup ini!`)
              	} else if (!isGroup) {
          		reply(`Untuk kontak penggunaan *${prefix}antidelete ctmati*`)
              	}
                  } else if (args[0].toLowerCase() === 'ctmati') {
                  if (!isOwner) return reply(ind.ownerb())
              	if (!isGroup) {
    	      	dataCtRevoke.data = false
          		fs.writeFileSync('./database/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
          		reply(`Antidelete dimatikan disemua kontak!`)
              	} else if (isGroup) {
          		reply(`Untuk grup penggunaan *${prefix}antidelete mati*`)
              	}
                  } else {
                  reply(`─ ❲ ERROR ❳ ─

Penggunaan fitur antidelete :
*${prefix}antidelete [aktif/mati]* (Untuk grup)
*${prefix}antidelete [ctaktif/ctmati]* (untuk semua kontak)
*${prefix}antidelete banct 628558xxxxxxx* (banlist kontak)`)
                   }
                   break
        case 'antilink':
        case 'antilinkgroup':
        case 'antilinkgrup':{
                    if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
					if (!isGroupAdmins) return reply(ind.admin())
					if (!isBotGroupAdmins) return reply(ind.badmin())
                    try {
                    if (!isGroupAdmins && !isOwner && !mek.key.fromMe) return reply(mess.only.admin)
                    if (args[0].toLowerCase() === 'aktif'){
                    if (isAntiLink) return reply(`Sudah Di Aktifkan Sebelumnya!`)
                    antilink.push(from)
                    fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
                    reply(`Succes mengaktifkan Fitur Antilink`)
                    } else if (args[0].toLowerCase() === 'mati'){
                    if (!isAntiLink) return reply(`Fitur Ini Belum Pernah Di Aktifkan Di Group Ini`)
                    var au = antilink.indexOf(from)
                    antilink.splice(au, 1)
                    fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
                    reply(`Succes Mematikan Fitur Antilink`)
                    }
                    } catch {
                    const buttons = [{buttonId: `${prefix}antilink aktif`, buttonText: {displayText: 'AKTIF'}, type: 1},{buttonId: `${prefix}antilink mati`, buttonText: {displayText: 'MATI'}, type: 1}]
                    const buttonMessage = {
                    headerType: "IMAGE",
                    contentText: `PILIH ON UNTUK MENGAKTIFKAN\nPILIH OFF UNTUK MEMATIKAN`,
                    footerText: `Pilih Di Bawah Ini 👇`,
                    buttons: buttons,
                    headerType: 1
                    }
                    client.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
                    }
                    }
                    break
        case 'event':
                    if (!isRegister) return reply(ind.noregis())
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb())
					if (args.length < 1) return reply(ind.satukos(prefix, command))
					if (args[0] === 'aktif') {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					event.push(from)
				    fs.writeFileSync('./database/event.json', JSON.stringify(event))
			        reply('*❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭️*')
					} else if (args[0] === 'mati') {
				    var inu = event.indexOf(from)
                    event.splice(inu, 1)
					fs.writeFileSync('./database/event.json', JSON.stringify(event))
					reply('*❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭*')
					} else {
					reply(ind.satukos(prefix, command))
					}
					break 
		case 'nsfw':
		            if (!isRegister) return reply(ind.noregis())
				    if (!isGroup) return reply(`Maaf, Perintah Ini Hanya Dapat Digunakan Dalam Group!`)
				    if (!isGroupAdmins) return reply(`*LU ADMIN??*`)
				    if (args.length < 1) return reply(ind.satukos(prefix, command))
				    if (args[0] === 'aktif') {
				    if (isNsfw) return reply('*SUDAH AKTIF CUY*')
			        nsfw.push(from)
				    fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw))
				    reply('*❬ SUKSES ❭ Mengaktifkan NSFW Mode Di Group Ini!*')
				    } else if (args[0] === 'mati') {
				    var una = nsfw.indexOf(from)
                    nsfw.splice(una, 1)
				    fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw))
			        reply('*❬ SUKSES ❭ Menonaktifkan NSFW Mode Di Group Ini!*')
				    } else {
				    reply(ind.satukos(prefix, command))
				    }
				    break
        case 'covidindo':
		            if (!isRegister) return reply(ind.noregis())
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/corona/indonesia?apikey=${lolkey}`)
                    get_result = get_result.result
                    ini_mn1k = `*_Situasi virus corona (COVID-19) ${tampilBulan}_*\n\n`
                    ini_mn1k += `*❏ INDONESIA*\n`
                    ini_mn1k += `*├─ ❏ Positif :* ${get_result.positif}\n`
                    ini_mn1k += `*├─ ❏ Sembuh :* ${get_result.sembuh}\n`
                    ini_mn1k += `*├─ ❏ Dirawat :* ${get_result.dirawat}\n`
                    ini_mn1k += `*└─ ❏ Meninggal :* ${get_result.meninggal}`
                    reply(ini_mn1k)
                    break
        case 'pinterest':
		            if (!isRegister) return reply(ind.noregis())
		            if (!isPrem) return reply(ind.prem())
                    if (args.length == 0) return reply(`Example: ${prefix + command} loli`)
                    reply(ind.wait())
                    query = args.join(" ")
                    ini_url = await fetchJson(`http://api.lolhuman.xyz/api/pinterest?apikey=${lolkey}&query=${query}`)
                    ini_url = ini_url.result
                    ini_buffer = await getBuffer(ini_url)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
       case 'nulis':  
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(6)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/nulis?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'qrcode':
        case 'qrkode':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(8)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/qrcode?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'ttp':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(5)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/${command}?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, sticker,)
                    break
        case 'ttp2':   
        case 'ttp3':  
        case 'ttp4':  
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(6)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/${command}?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, sticker,)
                    break
        case 'attp':  
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(6)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/attp?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, sticker,)
                    break
        case 'attp2':  
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length < 1) return reply('Kasih teks lah omm')
                    reply(ind.wait())
                    F = body.slice(7)
                    anu1 = await getBuffer(`https://lolhuman.herokuapp.com/api/attp2?apikey=${lolkey}&text=${F}`)
                    client.sendMessage(from, anu1, sticker,)
                    break
        case 'sider':
        case 'getsider':
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isBanned) return reply(ind.ban())
                    if (!isGroup) return reply(ind.groupo())
                    if (!isQuotedReply) return reply(`Reply pesan dari bot`)
                    client.messageInfo(from, mek.message.extendedTextMessage.contextInfo.stanzaId)   
                    .then((res) => {
                    let anu = []
                    let txt = `*「 𝐋𝐈𝐒𝐓 𝐒𝐈𝐃𝐄𝐑 」*\n\n`
                    for (let i = 0; i < res.reads.length; i++){
                    anu.push(res.reads[i].jid)
                    txt += `@${res.reads[i].jid.split("@")[0]}\n`
                    txt += `Waktu Membaca : ${moment(`${res.reads[i].t}` * 1000).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n`
                    }
                    mentions(txt, anu, true)
                    })
                    break  
       case 'cuaca':
                     if (!isRegister) return reply(ind.noregis())
                     if (isBanned) return reply(ind.ban())
                     reply(ind.wait())
                     if (args.length == 0) return reply(`Example: ${prefix + command} Yogyakarta`)
                     daerah = args[0]
                     get_result = await fetchJson(`http://api.lolhuman.xyz/api/cuaca/${daerah}?apikey=${lolkey}`)
                     get_result = get_result.result
                     ini_mn1k = `❒ *Tempat* : ${get_result.tempat}\n`
                     ini_mn1k += `❒ *Cuaca* : ${get_result.cuaca}\n`
                     ini_mn1k += `❒ *Angin* : ${get_result.angin}\n`
                     ini_mn1k += `❒ *Description* : ${get_result.description}\n`
                     ini_mn1k += `❒ *Kelembapan* : ${get_result.kelembapan}\n`
                     ini_mn1k += `❒ *Suhu* : ${get_result.suhu}\n`
                     ini_mn1k += `❒ *Udara* : ${get_result.udara}\n`
                     ini_mn1k += `❒ *Permukaan laut* : ${get_result.permukaan_laut}`
                     reply(ini_mn1k)
                     break
        case 'google':
        case 'googlesearch':
                     if (!isRegister) return reply(ind.noregis())
                     if (isBanned) return reply(ind.ban())
                     if (args.length < 1) return reply(`Kirim perintah *${prefix + command}* _query_`)
                     reply(ind.wait())
                     anu = await fetchJson(`http://api.lolhuman.xyz/api/gsearch?apikey=${lolkey}&query=${q}`, {method: 'get'})
                     teks = `─ 「 *GOOGLE SEARCH* 」 ─\n\n`
                     o = 1
                     for (let plor of anu.result) {
                     teks += `*${o++}. Judul : ${plor.title}*\n*❒ Deskripsi* : ${plor.desc}\n*❒ Link* : ${plor.link}\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`
                     }
                     reply(teks.trim())
                     break
       case 'ping':
       case 'speed':
                   if (!isRegister) return reply(ind.noregis())
                   if (isBanned) return reply(ind.ban())
                   reply(`_Tessting Speed!_`)
                   const processsTime = (timestamp, now) => {
                   return moment.duration(now - moment(timestamp * 1000)).asSeconds()} 
                   reply(`         「 *SPEED TEST* 」\n\nBot Akiraa Merespon Dalam Hitungan : ${processsTime(mek.messageTimestamp.low, moment())} Detik 💬`)
                   break
        case 'findstiker':
        case 'findsticker':
		            if (!isRegister) return reply(ind.noregis())
		            if (!isPrem) return reply(ind.prem())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Patrick`)
                    reply(ind.wait())
                    query = args.join(" ")
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/stickerwa?apikey=${lolkey}&query=${query}`)
                    get_result = get_result.result[0].stickers
                    for (var x of get_result) {
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/convert/towebp?apikey=${lolkey}&img=${x}`)
                    client.sendMessage(from, ini_buffer, sticker)
                    }
                    break
	    case 'clone':
					if (!isGroup) return reply(ind.groupo())
					if (!isOwner) return reply(ind.ownerb()) 
					if (args.length < 1) return reply(' *TAG YANG MAU DI CLONE!!!* ')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('❬ SUCCSESS ❭')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
			        pp = await client.getProfilePicture(id)
					buffer = await getBuffer(pp)
					client.updateProfilePicture(botNumber, buffer)
					mentions(`Foto profile Berhasil di perbarui menggunakan foto profile @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
					reply(ind.stikga())
					}
					limitAdd(sender, limit)
					break
        case 'wait':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())				
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
			        reply(ind.wait())
			        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
				    media = await client.downloadMediaMessage(encmedia)
					await wait(media).then(res => {
					client.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
					}).catch(err => {
					reply(err)
					})
					} else {
			        reply(ind.ocron())
				    }
				    limitAdd(sender, limit)
					break    
        case 'cecan':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    reply(ind.wait())
                    cecan = await getBuffer(`http://api.lolhuman.xyz/api/random/cecan?apikey=${lolkey}`)
                    client.sendMessage(from, cecan, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'cogan':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    reply(ind.wait())
                    cogan = await getBuffer(`http://api.lolhuman.xyz/api/random/cogan?apikey=${lolkey}`)
                    client.sendMessage(from, cogan, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'art':
        case 'bts':
        case 'exo':
        case 'elf':
        case 'loli':
        case 'neko':
        case 'waifu':
        case 'shota':
        case 'husbu':
        case 'sagiri':
        case 'shinobu':
        case 'megumin':
        case 'wallnime':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (!isNsfw) return reply(ind.nsfwoff())
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    buffer = await getBuffer(`http://api.lolhuman.xyz/api/random/${command}?apikey=${lolkey}`)
                    client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    limitAdd(sender, limit)
                    break
        case 'chiisaihentai':
        case 'trap':
        case 'blowjob':
        case 'yaoi':
        case 'ecchi':
        case 'hentai':
        case 'ahegao':
        case 'hololewd':
        case 'sideoppai':
        case 'animefeets':
        case 'animebooty':
        case 'animethighss':
        case 'hentaiparadise':
        case 'animearmpits':
        case 'hentaifemdom':
        case 'lewdanimegirls':
        case 'biganimetiddies':
        case 'animebellybutton':
        case 'hentai4everyone':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (!isNsfw) return reply(ind.nsfwoff())
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/random/nsfw/${command}?apikey=${lolkey}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    limitAdd(sender, limit)
                    break
        case 'bj':
        case 'ero':
        case 'cum':
        case 'feet':
        case 'yuri':
        case 'trap':
        case 'lewd':
        case 'feed':
        case 'eron':
        case 'solo':
        case 'gasm':
        case 'poke':
        case 'anal':
        case 'holo':
        case 'tits':
        case 'kuni':
        case 'kiss':
        case 'erok':
        case 'smug':
        case 'baka':
        case 'solog':
        case 'feetg':
        case 'lewdk':
        case 'waifu':
        case 'pussy':
        case 'femdom':
        case 'cuddle':
        case 'hentai':
        case 'eroyuri':
        case 'cum_jpg':
        case 'blowjob':
        case 'erofeet':
        case 'holoero':
        case 'classic':
        case 'erokemo':
        case 'fox_girl':
        case 'futanari':
        case 'lewdkemo':
        case 'wallpaper':
        case 'pussy_jpg':
        case 'kemonomimi':
        case 'nsfw_avatar':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (!isNsfw) return reply(ind.nsfwoff())
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/random2/${command}?apikey=${lolkey}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    limitAdd(sender, limit)
                    break 
        case 'blackpink':
        case 'neon':
        case 'greenneon':
        case 'advanceglow':
        case 'futureneon':
        case 'sandwriting':
        case 'sandsummer':
        case 'sandengraved':
        case 'metaldark':
        case 'neonlight':
        case 'text1917':
        case 'minion':
        case 'deluxesilver':
        case 'newyearcard':
        case 'bloodfrosted':
        case 'halloween':
        case 'jokerlogo':
        case 'fireworksparkle':
        case 'natureleaves':
        case 'bokeh':
        case 'toxic':
        case 'strawberry':
        case 'box3d':
        case 'roadwarning':
        case 'breakwall':
        case 'icecold':
        case 'luxury':
        case 'cloud':
        case 'summersand':
        case 'horrorblood':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
		            if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    if (args.length == 0) return reply(`Example: ${prefix + command} Its Muzha`)
                    ini_txt = args.join(" ")
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/textprome/${command}?apikey=${lolkey}&text=${ini_txt}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    limitAdd(sender, limit)
                    break
        case 'ytkomen':
		            if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Contoh : *${prefix + command} Udin | bang mau nanya*`)
                    reply(ind.wait())
                    ytkkmn = body.slice(9)
		            username = ytkkmn.split('|')[0]
		            comment = ytkkmn.split('|')[1]
                    buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/ytcomment?apikey=${lolkey}&username=${username}&comment=${comment}&img=https://i.ibb.co/JdfQ73m/photo-2021-02-05-10-13-39.jpg`)
                    client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'phkomen':
		            if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Contoh : *${prefix + command}phkomen Dimas | mau tanya Om*`)
                    reply(ind.wait())
                    phkkmn = body.slice(9)
		            username = phkkmn.split('|')[0]
		            comment = phkkmn.split('|')[1]
                    buffer = await getBuffer(`http://api.lolhuman.xyz/api/phcomment?apikey=${lolkey}&img=https://i.ibb.co/JdfQ73m/photo-2021-02-05-10-13-39.jpg&text=${comment}&username=${username}`)
                    client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'tololserti':
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(12)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/toloserti?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'fuckboy': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       akkab = body.slice(9)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/fuckboy?apikey=${lolkey}&name=${akkab}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'fuckgirl': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(10)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/fuckgirl?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'bucinserti': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(12)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/bucinserti?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
        case 'goodboy':
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(9)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/goodboy?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'goodgirl':
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(10)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/goodgirl?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
        case 'badboy': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(8)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/badboy?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
        case 'badgirl': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(9)
			       buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/badgirl?apikey=${lolkey}&name=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'ffserti': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(9)
			       buffer = await getBuffer(`https://sertiojanganzapi.nasihosting.com/serti/serti1/img.php?nama=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'ffserti2': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(10)
			       buffer = await getBuffer(`https://sertiojanganzapi.nasihosting.com/serti/serti2/img.php?nama=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
       case 'ffserti3': 
			       if (!isRegister) return reply(ind.noregis())
		           if (isBanned) return reply(ind.banned())
		           reply(ind.wait())
			       if (args.length < 1) return reply('Teks nya mana?')
			       auah = body.slice(10)
			       buffer = await getBuffer(`https://sertiojanganzapi.nasihosting.com/serti/serti3/img.php?nama=${auah}`, {method: 'get'})
	               client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
				   break
      case 'harta': 
      case 'tahta':
      case 'hartatahta':
                  if (!isRegister) return reply(ind.noregis())
		          if (isBanned) return reply(ind.banned())
				  reply(ind.wait())
		          if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                  if (args.length == 0) return reply(`Example: ${prefix + command} Its Muzza`)         
                  client.sendMessage(from, await getBuffer(`https://api.lolhuman.xyz/api/hartatahta?apikey=${lolkey}&text=${q}`), image, {quoted: mek, caption: `❒ *Nih Kak :* ${pushname}`}).catch(() => reply('ERROR'))
                  limitAdd(sender, limit)
                  break
        case 'pornhub':
        case 'glitch':
        case 'avenger':
        case 'space':
        case 'ninjalogo':
        case 'marvelstudio':
        case 'lionlogo':
        case 'wolflogo':
        case 'steel3d':
        case 'wallgravity':
	            	if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
	            	if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    cf = `${body.slice(8)}`
                    reply(ind.wait())
                    txt1 = cf.split("/")[0]
                    txt2 = cf.split("/")[1]
                    if (args.length == 0) return reply(`Example: ${prefix + command} Its Muzha`)
                    txt1 = args[0]
                    txt2 = args[1]
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/textprome2/${command}?apikey=${lolkey}&text1=${txt1}&text2=${txt2}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    limitAdd(sender, limit)
                    break
        case 'shadow':
        case 'cup':
        case 'cup1':
        case 'romance':
        case 'smoke':
        case 'burnpaper':
        case 'lovemessage':
        case 'undergrass':
        case 'love':
        case 'coffe':
        case 'woodheart':
        case 'woodenboard':
        case 'summer3d':
        case 'wolfmetal':
        case 'nature3d':
        case 'golderrose':
        case 'summernature':
        case 'letterleaves':
        case 'glowingneon':
        case 'fallleaves':
        case 'flamming':
        case 'harrypotter':
        case 'carvedwood':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Its Muzha`)
                    ini_txt = args.join(" ")
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/photooxy1/${command}?apikey=${lolkey}&text=${ini_txt}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'ttlogo':
        case 'arcade8bit':
        case 'battlefield4':
        case 'pubg':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
		            cf = `${body.slice(8)}`
                    txt1 = cf.split("/")[0];
                    reply(ind.wait())
                    txt2 = cf.split("/")[1];
                    if (args.length == 0) return reply(`Example: ${prefix + command} Its Muzha`)
                    txt1 = args[0]
                    txt2 = args[1]
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/photooxy2/${command}?apikey=${lolkey}&text1=${txt1}&text2=${txt2}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'wetglass':
        case 'multicolor3d':
        case 'watercolor':
        case 'luxurygold':
        case 'galaxywallpaper':
        case 'lighttext':
        case 'beautifulflower':
        case 'puppycute':
        case 'royaltext':
        case 'heartshaped':
        case 'birthdaycake':
        case 'galaxystyle':
        case 'hologram3d':
        case 'greenneon':
        case 'glossychrome':
        case 'greenbush':
        case 'metallogo':
        case 'noeltext':
        case 'glittergold':
        case 'textcake':
        case 'starsnight':
        case 'wooden3d':
        case 'textbyname':
        case 'writegalacy':
        case 'galaxybat':
        case 'snow3d':
        case 'birthdayday':
        case 'goldplaybutton':
        case 'silverplaybutton':
        case 'freefire':
	            	if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Akiraa Bot`)
                    ini_txt = args.join(" ")
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${lolkey}&text=${ini_txt}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'gmlogo':
	            	if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Akiraa Bot`)
                    ini_txt = args.join(" ")
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/ephoto1/logogaming?apikey=${lolkey}&text=${ini_txt}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'cartoongravity':
        case 'cartongravity':
	            	if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Akiraa Bot`)
                    ini_txt = args.join(" ")
                    reply(ind.wait())
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/ephoto1/cartoongravity?apikey=${lolkey}&text=${ini_txt}`)
                    client.sendMessage(from, ini_buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
         case 'igstalk':
         case 'stalkig':
                     if (!isRegister) return reply(ind.noregis())
                     if (args.length < 1) return reply(`USERNAME NYA MANA?`)
                     reply(ind.wait())
                     try {
                     teekss = q
                     anu = await igdl.scrapeUserPage(teekss)
                     igssst = `❏ *INSTAGRAM STALK*\n`
                     igssst += `*├─ ❏ Username* : ${anu.user.username}\n`
                     igssst += `*├─ ❏ Nickname* : ${anu.user.full_name}\n`
                     igssst += `*├─ ❏ Mengikuti* : ${anu.user.edge_follow.count}\n`
                     igssst += `*├─ ❏ Pengikut* : ${anu.user.edge_followed_by.count}\n`
                     igssst += `*├─ ❏ Jumlah Postingan* : ${anu.user.edge_owner_to_timeline_media.count}\n`
                     igssst += `*├─ ❏ Verifikasi Akun* : ${anu.user.is_verified ? '✓' : '𝘅'}\n`
                     igssst += `*└─ ❏ Bio* : ${anu.user.biography}`
                     buffer = await getBuffer(anu.user.profile_pic_url_hd)
                     client.sendMessage(from, buffer, image, { quoted: mek, caption: igssst })
                     } catch (err) {
                     reply(`_ERROR_`)
                     }
                     break
      case 'stalktwit':
      case 'twitstalk':
      case 'stalktwiter':
      case 'twiterstalk':
                    if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} jokowi`)
                    reply(ind.wait())
                    username = args[0]
                    ini_result = await fetchJson(`https://api.lolhuman.xyz/api/twitter/${username}?apikey=${lolkey}`)
                    ini_result = ini_result.result
                    ini_buffer = await getBuffer(ini_result.profile_picture)
                    ini_txt = `Username : ${ini_result.screen_name}\n`
                    ini_txt += `Name : ${ini_result.name}\n`
                    ini_txt += `Tweet : ${ini_result.tweet}\n`
                    ini_txt += `Joined : ${ini_result.joined}\n`
                    ini_txt += `Followers : ${ini_result.followers}\n`
                    ini_txt += `Following : ${ini_result.following}\n`
                    ini_txt += `Like : ${ini_result.like}\n`
                    ini_txt += `Description : ${ini_result.description}`
                    client.sendMessage(from, ini_buffer, image, { caption: ini_txt })
                    break
        case 'githubstalk':
					if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
					get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/github/${body.slice(13)}?apikey=${lolkey}`, {method: 'get'})
					get_result = get_result.result
					txt = `Full : ${get_result.name}\n`
					txt += `Followers : ${get_result.followers}\n`
					txt += `Following : ${get_result.following}\n`
					txt += `Publick : ${get_result.public_repos}\n`
					txt += `Public Gits : ${get_result.public_gists}\n`
					txt += `User : ${get_result.user}\n`
					txt += `Compi : ${get_result.company}\n`
					txt += `Lokasi : ${get_result.location}\n`
					txt += `Email : ${get_result.email}\n`
					txt += `Bio : ${get_result.bio}\n`
					buffer = await getBuffer(get_result.avatar)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: txt})
					break
        case 'tiktokstalk':
                    if (!isRegister) return reply(ind.noregis())
		            if (isBanned) return reply(ind.banned())
		            reply(ind.wait())
                    username = args[0]
					get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/stalktiktok/${username}?apikey=${lolkey}`, {method: 'get'})
					get_result = get_result.result
					txt = `❏ *DITEMUKAN*\n`
					txt += `*├─ ❏ Nama :* ${get_result.username}\n`
					txt += `*├─ ❏ Bio :* ${get_result.bio}\n`
					txt += `*├─ ❏ Pengikut :* ${get_result.followers}\n`
					txt += `*├─ ❏ Mengikuti :* ${get_result.followings}\n`
					txt += `*├─ ❏ Like :* ${get_result.likes}\n`
					txt += `*└─ ❏ Vidio :* ${get_result.video}`
					buffer = await getBuffer(get_result.user_picture)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: txt})
					break
         case 'ytstalk':
					if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
					ytk = `${body.slice(11)}`
					anu = await fetchJson(`http://api.lolhuman.xyz/api/ytchannel?apikey=${lolkey}&query=${ytk}`, {method: 'get'})
					cari = '•••••••••••••••••\n'
					for (let search of anu.result) {
					cari += `*Channel* : ${search.channel_name}\n*Tentang* : ${search.channel_about}\n*Created* : ${search.channel_created}\n*Link* : https://youtu.com/channel/${search.channel_id}\n•••••••••••••••••\n`
					}
					reply(cari.trim())
					break
       case 'textfont':  
                     if (!isRegister) return reply(ind.noregis())
                     if (args.length < 1) return reply(`[❗] Example :\n*${prefix}${command} zeeone`)
                     reply(ind.wait())
                     F = body.slice(10)
                     anu = await fetchJson(`http://kocakz.herokuapp.com/api/random/text/fancytext?text=${F}`)
                     anu1 = `${anu.result}`
                     reply(anu1)
                     break
      case 'halah':
      case 'hilih':
      case 'huluh':
      case 'heleh':
      case 'holoh':  
                     if (!isRegister) return reply(ind.noregis())
                     if (args.length < 1) return reply(`[❗] Example :\n*${prefix}${command} zeeone`)
                     F = body.slice(7)
                     anu = await fetchJson(`https://pecundang.herokuapp.com/api/${command}?teks={f}`)
                     anu1 = `${anu.result}`
                     reply(anu1)
                     break
         case 'boomtext':  
                     if (args.length < 1) return reply(`[❗] Example :\n*${prefix}${command} zeeone|50`)
                     var PF = body.slice(10)
			         var F1 = PF.split("|")[0];
			 	    var F2 = PF.split("|")[1]; 
                     aanu = await fetchJson(`https://pecundang.herokuapp.com/api/repeater?teks=${F1}&jumlah=${F2}`)
                     anu11 = `${aanu.result}`
                     reply(anu11)
                     break
       case 'telesticker':  
                    if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://t.me/addstickers/LINE_Menhera_chan_ENG`)
                    reply(ind.wait())
                    inii_url = args[0]
                    inii_url = await fetchJson(`http://api.lolhuman.xyz/api/telestick?apikey=${lolkey}&url=${inii_url}`)
                    ini_sticker = inii_url.result.sticker
                    for (sticker_ in ini_sticker) {
                    ini_buffer = await getBuffer(ini_sticker[sticker_])
                    client.sendMessage(from, ini_buffer, sticker)
                    }
                    break
        case 'katajago':  
                    if (!isRegister) return reply(ind.noregis())
                    if (args.length < 1) return reply(`[❗] Example :\n*${prefix}${command} cantik`)
                    anhu = await fetchJson(`https://pecundang.herokuapp.com/api/jagokata?kata=${args[0]}`)
                    anhu1 = `➻ *KATA* : ${anhu.result}`
                    reply(anhu1)
                    break
       case 'jadwaltv':  
                   if (!isRegister) return reply(ind.noregis())
                   reply(ind.wait())
                   janu = await fetchJson(`https://docs-jojo.herokuapp.com/api/jadwaltvnow`)
                   janu1 = `➻ *JAM* : ${janu.result.jam}\n`
                   janu1 += `➻ *JADWAL* : ${janu.result.jadwalTV}\n`
                   reply(janu1)
                   break
       case 'cinta':  
                   if (!isRegister) return reply(ind.noregis())
                   avnu = await fetchJson(`https://docs-jojo.herokuapp.com/api/katacinta`)
                   avnu1 = `➻ *KATA CINTA* : ${avnu.result}`
                   reply(avnu1)
                   break                                                                            
       case 'twich':  
                   if (!isRegister) return reply(ind.noregis())
                   atnu = await fetchJson(`https://docs-jojo.herokuapp.com/api/twichquote`)
                   anyu1 = `➻ *THWICH* : ${atnu.result}`
                   reply(anyu1)
                   break                   
        case 'fake':  
                   if (!isRegister) return reply(ind.noregis())
                   anku = await fetchJson(`https://docs-jojo.herokuapp.com/api/fake_identity`)
                   anku1 = `➻ *NAMA* : ${anu.name}\n`
                   anku1 += `➻ *GENDER* : ${anu.gender}\n` 
                   anku1 += `➻ *AGE* : ${anu.age}\n`
                   anku1 += `➻ *BIRTDAY* : ${anu.birtday}\n`
                   anku1 += `➻ *BACHELOR* : ${anu.Bachelor}\n`
                   anku1 += `➻ *ADDRESA* : ${anu.address}\n`
                   anku1 += `➻ *CODE* : ${anu.zip_code}\n`
                   anku1 += `➻ *STATE* : ${anu.state}\n`
                   anku1 += `➻ *COUNTRY* : ${anu.country}\n`
                   anku1 += `➻ *EMAIL* : ${anu.email}\n`
                   anku1 += `➻ *PASS* : ${anu.password}\n` 
                   anku1 += `➻ *PHONE* : ${anu.phone}\n` 
                   anku1 += `➻ *CARD* : ${anu.card}\n`
                   anku1 += `➻ *CODE* : ${anu.code}\n`
                   anku1 += `➻ *DATE* : ${anu.date}\n`
                   anku1 += `➻ *PIN* : ${anu.pin_code}\n`
                   anku1 += `➻ *WEIGHT* : ${anu.weight}\n` 
                   anku1 += `➻ *HEIGHT* : ${anu.height}\n` 
                   anku1 += `➻ *TYPE* : ${anu.blood_type}\n`
                   anku1 += `➻ *STATUS* : ${anu.status}\n`
                   reply(anku1)
                   break
        case 'cersex':  
                   if (!isRegister) return reply(ind.noregis())
                   anuu = await fetchJson(`https://docs-jojo.herokuapp.com/api/cersex`)                   
                   anu8 = `➻ *JUDUL* : ${anuu.result.judul}\n`
                   anu8 += `➻ *NAMA* : ${anuu.result.cersex}\n`
                   reply(anu8)
                   break
       case 'cerpen':  
                	if (!isRegister) return reply(ind.noregis())
                    anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/cerpen`)                   
                    anu7 = `➻ *JUDUL* : ${anu.result.title}\n`
                    anu7 += `➻ *PENGARANG* : ${anu.result.pengarang}\n` 
                    anu7 += `➻ *KATEGORI* : ${anu.result.kategori}\n`
                    anu7 += `➻ *CERPEN* : ${anu.result.cerpen}\n`
                    reply(anu7)
                    break  
        case 'asupan':{
                    if (!isRegister) return reply(ind.noregis())
                    reply(ind.wait())
                    data = fs.readFileSync('./lib/asupan.js');
                    jsonData = JSON.parse(data);
                    randIndex = Math.floor(Math.random() * jsonData.length);
                    randKey = jsonData[randIndex];
                    p = await getBuffer(randKey.result)
                    client.sendMessage(from, p, video, { quoted:  mek, mimetype: 'video/mp4', caption: '𝙉𝙄𝙃 𝘼𝙎𝙐𝙋𝘼𝙉'})
                    }
                    break
         case 'readmore':  
    	 case 'more':  
                    if (!isRegister) return reply(ind.noregis())
			    	const more = String.fromCharCode(8206)
			    	const readmore = more.repeat(4001)
				    if (!q.includes('|')) return  reply(`GUNAKAN | UNTUK PEMBATAS`)
                    const text1 = q.substring(0, q.indexOf('|') - 0)
                    const text2 = q.substring(q.lastIndexOf('|') + 1)
                    reply( text1 + readmore + text2)
                    break
case 'addcmd': 
case 'setcmd':
if (!isRegister) return reply(ind.noregis())
if (!isOwner) return reply(ind.ownerb())
if (isQuotedSticker) {
if (!q) return reply(`Penggunaan : ${command} cmdnya dan tag stickernya`)
var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
addCmd(kodenya, q)
reply("Done Bwang")
} else {
reply('tag stickenya')
}
break
case 'dellcmd':
case 'delcmd':
if (!isRegister) return reply(ind.noregis())
if (!isOwner) return reply(ind.ownerb())
var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
scommand.splice(getCommandPosition(kodenya), 1)
fs.writeFileSync('./database/scommand.json', JSON.stringify(scommand))
reply("Done Bwang")
break
case 'listcmd':
if (!isRegister) return reply(ind.noregis())
if (!isOwner) return reply(ind.ownerb())
let teksnyee = `\`\`\`「 LIST CMD STIC 」\`\`\``
let cemde = [];
for (let i of scommand) {
cemde.push(i.id)
teksnyee += `\n\n*❏ ID :* ${i.id}\n*❏ Cmd :* ${i.chats}`
}
reply(teksnyee)
break
         case 'addstik':
         case 'addstick':
         case 'addsticker':
         case 'addstiker':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.ban())
                    if (!isPrem) return reply(ind.prem())
                    if (!isQuotedSticker) return reply('Reply stiker nya')
                    if (!q) return reply('Nama sticker nya apa?')
                    boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                    delb = await client.downloadMediaMessage(boij)
                    setiker.push(`${q}`)
                    fs.writeFileSync(`./add/sticker/${q}.webp`, delb)
                    fs.writeFileSync('./add/sticker.json', JSON.stringify(setiker))
                    reply(`Sukses Menambahkan Sticker!!\nCek Sticker Dengan Cara Ketik ${prefix}liststick`)
                    break
          case 'dellstik':
          case 'dellstick':
          case 'dellsticker':
          case 'dellstiker':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.ban())
                    if (!isPrem) return reply(ind.prem())
                    if (!q) return reply(`NAMA STICKER MANA YANG MAU DI HAPUS?`)
                    try {
                    fs.unlinkSync(`./add/sticker/${q}.webp`)
                    setiker.splice(q,1)
                    fs.writeFileSync('./add/sticker.json', JSON.stringify(setiker))
                    reply(`Succes Menghapus sticker ${q}!`)
                    } catch (err) {
                    reply(`Gagal Menghapus sticker ${q}!`)
                    }
                    break
          case 'liststik':
          case 'liststick':
          case 'liststicker':
          case 'liststiker':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.ban())
                    teks = '*「 LIST STICKER 」*\n\n'
                    for (let awokwkwk of setiker) {
                    teks += `⬡ ${awokwkwk}\n`
                    }
                    teks += `\n*TOTAL :* ${setiker.length}`
                    client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": setiker }})
                    break
          case 'getstik':
          case 'getstick':
          case 'getsticker':
          case 'getstiker':
                     if (!isRegister) return reply(ind.noregis())
                     if (isBanned) return reply(ind.ban())
                     try {
                     result = fs.readFileSync(`./add/sticker/${q}.webp`)
                     client.sendMessage(from, result, sticker, {quoted:mek})
                     } catch {
                     reply('*TITLE TIDAK DI TEMUKAN DI DALAM #LISTSTICKER*')
                     }
                     break
          case 'addimage':
          case 'addimg':
          case 'addfoto':
                     if (!isRegister) return reply(ind.noregis())
                     if (isBanned) return reply(ind.ban())
                     if (!isPrem) return reply(ind.prem())
                     if (!isQuotedImage) return reply('Reply Imagenyaaa')
                     if (!q) return reply('Nama imagenyaaa? >_<')
                     boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                     delb = await client.downloadMediaMessage(boij)
                     imagenye.push(`${q}`)
                     fs.writeFileSync(`./add/image/${q}.jpeg`, delb)
                     fs.writeFileSync('./add/image.json', JSON.stringify(imagenye))
                     reply(`Sukses Menambahkan Foto!!\nCek Foto Dengan Cara Ketik ${prefix}listimage`)
                     break
           case 'dellimage':
           case 'dellimg':
           case 'dellfoto':
                      if (!isRegister) return reply(ind.noregis())
                      if (isBanned) return reply(ind.ban())
                      if (!isPrem) return reply(ind.prem())
                      if (!q) return reply(`NAMA FOTO MANA YANG MAU DI HAPUS?`)
                      try {
                      fs.unlinkSync(`./add/image/${q}.jpeg`)
                      imagenye.splice(q,1)
                      fs.writeFileSync('./add/image.json', JSON.stringify(imagenye))
                      reply(`Succes Menghapus Image ${q}!`)
                      } catch (err) {
                      reply(`Gagal Menghapus Image ${q}!`)
                      }
                      break
            case 'listimg':
            case 'listfoto':
            case 'listimage':
                       if (!isRegister) return reply(ind.noregis())
                       if (isBanned) return reply(ind.ban())
                       teks = '*「 LIST IMAGE 」*\n\n'
                       for (let awokwkwk of imagenye) {
                       teks += `⬡ ${awokwkwk}\n`
                       }
                       teks += `\n*TOTAL :* ${imagenye.length}`
                       client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": imagenye } })
                       break
              case 'getimage':
              case 'getimg':
              case 'getfoto':
                       if (!isRegister) return reply(ind.noregis())
                       if (isBanned) return reply(ind.ban())
                       try {
                       buffer = fs.readFileSync(`./add/image/${q}.jpeg`)
                       client.sendMessage(from, buffer, image, { quoted: mek, caption: `${q}` })
                       } catch {
                       reply('*TITLE TIDAK DI TEMUKAN DI DALAM #LISTIMAGE*')
                       }
                       break
          case 'addvid':
          case 'addvideo':
          case 'addmp4':
                       if (!isRegister) return reply(ind.noregis())
                       if (isBanned) return reply(ind.ban())
                       if (!isPrem) return reply(ind.prem())
                       if (!isQuotedVideo) return reply('Reply Vidionyaaa!')
                       if (!q) return reply('Nama vidionyaaa? >_<')
                       boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                       delb = await client.downloadMediaMessage(boij)
                       videonye.push(`${q}`)
                       fs.writeFileSync(`./add/video/${q}.mp4`, delb)
                       fs.writeFileSync('./add/video.json', JSON.stringify(videonye))
                       reply(`Sukses Menambahkan Video!!\nCek Video Dengan Cara Ketik ${prefix}listvideo`)
                       break
            case 'dellvideo':
            case 'dellvid':
            case 'dellmp4':
                      if (!isRegister) return reply(ind.noregis())
                      if (isBanned) return reply(ind.ban())
                      if (!isPrem) return reply(ind.prem())
                      if (!q) return reply(`NAMA VIDEO MANA YANG MAU DI HAPUS?`)
                      try {
                      fs.unlinkSync(`./add/video/${q}.mp4`)
                      videonye.splice(q,1)
                      fs.writeFileSync('./add/video.json', JSON.stringify(videonye))
                      reply(`Succes Menghapus Video ${q}!`)
                      } catch (err) {
                      reply(`Gagal Menghapus Video ${q}!`)
                      }
                      break
           case 'listvid':
           case 'listvideo':
                      if (!isRegister) return reply(ind.noregis())
                      if (isBanned) return reply(ind.ban())
                      teks = '*「 LIST VIDEO 」*\n\n'
                      for (let awokwkwk of videonye) {
                      teks += `⬡ ${awokwkwk}\n`
                      }
                      teks += `\n*TOTAL :* ${videonye.length}`
                      client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": videonye } })
                      break
           case 'getvideo':
           case 'getvid':
           case 'getmp4':
                      if (!isRegister) return reply(ind.noregis())
                      if (isBanned) return reply(ind.ban())
                      try {
                      buffer = fs.readFileSync(`./add/video/${q}.mp4`)
                      client.sendMessage(from, buffer, video, { quoted: mek, caption: `${q}` })
                      } catch {
                      reply('*TITLE TIDAK DI TEMUKAN DI DALAM #LISTVIDEO*')
                      }
                      break
       case 'lirik':
                     if (!isRegister) return reply(ind.noregis())
                     if (args.length == 0) return reply(`Example: ${prefix + command} mentari pagi`)
                     reply(ind.wait())
                     query = args.join(" ")
                     get_result = await fetchJson(`http://api.lolhuman.xyz/api/lirik?apikey=${lolkey}&query=${query}`)
                     reply(get_result.result)
                     break
         case 'truth':
                     if (!isRegister) return reply(ind.noregis())
                     if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                     const trut =['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
                     const ttrth = trut[Math.floor(Math.random() * trut.length)]
                     client.sendMessage(from, ttrth, text, {quoted: mek })
                     limitAdd(sender, limit)
                     break
         case 'dare':
                     if (!isRegister) return reply(ind.noregis())
                     if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                     const dare =['Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot "🦄💨" setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u baby?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " anjimm gabutt anjimmm " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
                     const der = dare[Math.floor(Math.random() * dare.length)]
                     client.sendMessage(from, der, text, { quoted: mek})
                     limitAdd(sender, limit)
                     break
        case 'ytmp3':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    if (!isPrem) return reply(ind.prem())
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
                    reply(ind.wait())
                    ini_link = args[0]
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/ytaudio?apikey=${lolkey}&url=${ini_link}`)
                    get_result = get_result.result
                    ini_txt = `*❏ LAGU DITEMUKAN*\n`
                    ini_txt += `*├─ ❏ Judul :* ${get_result.title}\n`
                    ini_txt += `*├─ ❏ Durasi :* ${get_result.duration}\n`
                    ini_txt += `*├─ ❏ View :* ${get_result.view}\n`
                    ini_txt += `*├─ ❏ Like :* ${get_result.like}\n`
                    ini_txt += `*└─ ❏ Dislike :* ${get_result.dislike}\n\n`
                    ini_txt += `*Silahkan Tunggu Sebentar Kak ${pushname} Lagu Sedang Dikirim Mungkin Butuh Beberapa Menit.*`
                    ini_buffer = await getBuffer(get_result.thumbnail)
                    client.sendMessage(from, ini_buffer, image, { quoted: mek, caption: ini_txt })
                    get_audio = await getBuffer(get_result.link.link)
                    client.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.title}.mp3`, quoted: mek})
                    break
        case 'ytmp4':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    if (!isPrem) return reply(ind.prem())
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
                    reply(ind.wait())
                    ini_link = args[0]
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/ytvideo?apikey=${lolkey}&url=${ini_link}`)
                    get_result = get_result.result
                    ini_txt = `*❏ VIDEO DITEMUKAN*\n`
                    ini_txt += `*├─ ❏ Judul :* ${get_result.title}\n`
                    ini_txt += `*├─ ❏ Durasi :* ${get_result.duration}\n`
                    ini_txt += `*├─ ❏ View :* ${get_result.view}\n`
                    ini_txt += `*├─ ❏ Like :* ${get_result.like}\n`
                    ini_txt += `*└─ ❏ Dislike :* ${get_result.dislike}\n\n`
                    ini_txt += `*Silahkan Tunggu Sebentar Kak ${pushname} File Sedang Dikirim Mungkin Butuh Beberapa Menit.*`
                    ini_buffer = await getBuffer(get_result.thumbnail)
                    client.sendMessage(from, ini_buffer, image, { quoted: mek, caption: ini_txt })
                    get_audio = await getBuffer(get_result.link.link)
                    client.sendMessage(from, get_audio, video, { mimetype: 'video/mp4', filename: `${get_result.title}.mp4`, quoted: mek})
                    break
       case 'tiktoknowm':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    if (!isUrl(args[0]) && !args[0].includes('tiktok')) return reply('Link Error')
                    tiktokDown(`${args[0]}`)
                    .then(res => {
                    reply(ind.wait())
                    var njir = res.result.nowatermark
                    sendFileFromUrl(njir, video, {caption: `Niih Kak ${pushname}`, mimetype:'video/mp4',filename: `TIKTOKNOWM.mp4`, quoted:mek})
                    })
                    break
         case 'stickanjing':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    anu = await getBuffer(`http://lolhuman.herokuapp.com/api/sticker/anjing?apikey=${lolkey}`)
                    client.sendMessage(from, anu, sticker, {quoted: mek})
                    break
         case 'stickbucin':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    ene = await getBuffer(`http://lolhuman.herokuapp.com/api/sticker/bucinstick?apikey=${lolkey}`)
                    client.sendMessage(from, ene, sticker, {quoted: mek})
                    break
         case 'dadu': 
         case 'gawrgura': 
         case 'umongus':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
                    una = await getBuffer(`http://lolhuman.herokuapp.com/api/sticker/${command}?apikey=${lolkey}`)
                    client.sendMessage(from, una, sticker, {quoted: mek})
                    break
        case 'semoji':
        case 'estiker':
        case 'esticker':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    if (args.length == 0) return reply(`Contoh : ${prefix + command} 🗿`)
                    reply(ind.wait())
                    emoji = args[0]
                    try {
                    emoji = encodeURI(emoji[0])
                    } catch {
                    emoji = encodeURI(emoji)
                    }
                    ini_buffer = await getBuffer(`http://api.lolhuman.xyz/api/smoji/${emoji}?apikey=${lolkey}`)
                    client.sendMessage(from, ini_buffer, sticker,)
                    limitAdd(sender, limit)
                    break
        case 'sticker':  
        case 'stiker':  
        case 'stickergif':  
        case 'stikergif':  
        case 'sgif':  
        case 's':
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(`Mohon Tunggu Sebentar Proses Pembuatan Sticker 😇`)
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    var _0x15655b=_0x9bca;(function(_0x4d117a,_0x2bfc24){var _0x1c04ad=_0x9bca,_0x5ce194=_0x4d117a();while(!![]){try{var _0x43c139=parseInt(_0x1c04ad(0x19a))/0x1*(parseInt(_0x1c04ad(0x1a8))/0x2)+parseInt(_0x1c04ad(0x1b1))/0x3+parseInt(_0x1c04ad(0x192))/0x4*(-parseInt(_0x1c04ad(0x1ae))/0x5)+parseInt(_0x1c04ad(0x1a3))/0x6+parseInt(_0x1c04ad(0x19f))/0x7*(parseInt(_0x1c04ad(0x1b0))/0x8)+parseInt(_0x1c04ad(0x1a5))/0x9*(parseInt(_0x1c04ad(0x1a7))/0xa)+-parseInt(_0x1c04ad(0x1aa))/0xb*(parseInt(_0x1c04ad(0x1ac))/0xc);if(_0x43c139===_0x2bfc24)break;else _0x5ce194['push'](_0x5ce194['shift']());}catch(_0x43c636){_0x5ce194['push'](_0x5ce194['shift']());}}}(_0x46e6,0x4d55e));function _0x46e6(){var _0xca0205=['sendMessage','432vTodnA','quotedMessage','15UhTjAV','parse','24FeXjPG','70737QTOiye','536196xUGesO','quotedM','ffmpeg\x20-i\x20','stringify','seconds','downloadAndSaveMediaMessage','message','\x20-vf\x20\x22scale=512:512:force_original_aspect_ratio=increase,fps=15,\x20crop=512:512\x22\x20','1WrHePa','Kirim\x20gambar\x20dengan\x20caption\x20','.webp','unlinkSync','replace','1382843ojRqgt','webpmux\x20-set\x20exif\x20./sticker/data.exif\x20','extendedTextMessage','contextInfo','1179024rOltjR','length','324VKpnKg','\x20-o\x20','110220Ozcpdv','937438QxsnXM','videoMessage','293128IWecgG'];_0x46e6=function(){return _0xca0205;};return _0x46e6();}function _0x9bca(_0x175861,_0x33b05d){var _0x46e67d=_0x46e6();return _0x9bca=function(_0x9bcaf5,_0x424c10){_0x9bcaf5=_0x9bcaf5-0x192;var _0x33cb4b=_0x46e67d[_0x9bcaf5];return _0x33cb4b;},_0x9bca(_0x175861,_0x33b05d);}if((isMedia&&!mek[_0x15655b(0x198)][_0x15655b(0x1a9)]||isQuotedImage)&&args[_0x15655b(0x1a4)]==0x0)encmediat=isQuotedImage?JSON[_0x15655b(0x1af)](JSON[_0x15655b(0x195)](mek)[_0x15655b(0x19e)]('quotedM','m'))[_0x15655b(0x198)][_0x15655b(0x1a1)][_0x15655b(0x1a2)]:mek,mediat=await client[_0x15655b(0x197)](encmediat),ron=getRandom(_0x15655b(0x19c)),exec(_0x15655b(0x194)+mediat+_0x15655b(0x199)+ron,_0x1eb9d7=>{var _0x22d052=_0x15655b;fs[_0x22d052(0x19d)](mediat);if(_0x1eb9d7)return reply(''+_0x1eb9d7);exec(_0x22d052(0x1a0)+ron+_0x22d052(0x1a6)+ron,async _0x33c43d=>{if(_0x33c43d)return reply(''+_0x33c43d);client['sendMessage'](from,fs['readFileSync'](ron),sticker,{'quoted':mek}),fs['unlinkSync'](ron);});});else(isMedia&&mek[_0x15655b(0x198)][_0x15655b(0x1a9)]['seconds']<0xb||isQuotedVideo&&mek[_0x15655b(0x198)][_0x15655b(0x1a1)]['contextInfo'][_0x15655b(0x1ad)][_0x15655b(0x1a9)][_0x15655b(0x196)]<0xb)&&args[_0x15655b(0x1a4)]==0x0?(encmedia=isQuotedVideo?JSON['parse'](JSON[_0x15655b(0x195)](mek)[_0x15655b(0x19e)](_0x15655b(0x193),'m'))[_0x15655b(0x198)][_0x15655b(0x1a1)][_0x15655b(0x1a2)]:mek,mediat=await client[_0x15655b(0x197)](encmedia),ron=getRandom(_0x15655b(0x19c)),exec(_0x15655b(0x194)+mediat+_0x15655b(0x199)+ron,_0x3d7cb8=>{var _0x304022=_0x15655b;fs[_0x304022(0x19d)](mediat);if(_0x3d7cb8)return reply(''+_0x3d7cb8);exec(_0x304022(0x1a0)+ron+_0x304022(0x1a6)+ron,async _0x1e1925=>{var _0x59aac8=_0x304022;if(_0x1e1925)return reply(''+_0x1e1925);client[_0x59aac8(0x1ab)](from,fs['readFileSync'](ron),sticker,{'quoted':mek}),fs['unlinkSync'](ron);});})):reply(_0x15655b(0x19b)+prefix+'sticker\x0aDurasi\x20Sticker\x20Video\x201-9\x20Detik');
                    limitAdd(sender, limit)
                    break
         case 'swm':
         case 'stickerwm':
         case 'stikerwm':{
	                if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(`Mohon Tunggu Sebentar Proses Pembuatan Sticker 😇`)
                    if (args.length < 1) return reply(`Penggunaan ${command} nama|author`)
                    let packname1 = q.split('|')[0] ? q.split('|')[0] : q
                    let author1 = q.split('|')[1] ? q.split('|')[1] : ''
                    if (isImage || isQuotedImage) {
                    let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                    let media = await client.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                    exif.create(packname1, author1, `stickwm_${sender}`)
                    await ffmpeg(`${media}`)
                    .input(media)
                    .on('start', function (cmd) {
                    })
                    .on('error', function (err) {
                    fs.unlinkSync(media)
                    reply(ind.err())
                    })
                    .on('end', function () {
                    exec(`webpmux -set exif ./sticker/stickwm_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                    if (error) return reply(ind.err())
                    client.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker,)
                    fs.unlinkSync(media)
                    fs.unlinkSync(`./sticker/${sender}.webp`)
                    fs.unlinkSync(`./sticker/stickwm_${sender}.exif`)
                     })
                     })
                    .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                    .toFormat('webp')
                    .save(`./sticker/${sender}.webp`)
                    } else if ((isVideo && mek.message.videoMessage.fileLength < 10000000 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.fileLength < 10000000)) {
                    let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                    let media = await client.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                    exif.create(packname1, author1, `stickwm_${sender}`)
                    await ffmpeg(`${media}`)
                    .inputFormat(media.split('.')[4])
                    .on('start', function (cmd) {
                    })
                    .on('error', function (err) {
                    fs.unlinkSync(media)
                    let tipe = media.endsWith('.mp4') ? 'video' : 'gif'
                    reply(ind.err())
                    })
                   .on('end', function () {
                    exec(`webpmux -set exif ./sticker/stickwm_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                    if (error) return reply(ind.err())
                    client.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker,)
                    fs.unlinkSync(media)
                    fs.unlinkSync(`./sticker/${sender}.webp`)
                    fs.unlinkSync(`./sticker/stickwm_${sender}.exif`)
                    })
                    })
                   .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                   .toFormat('webp')
                   .save(`./sticker/${sender}.webp`)
                    } else if (isQuotedSticker) {
                    let encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
                    let media = await client.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
                    exif.create(packname1, author1, `takestick_${sender}`)
                    exec(`webpmux -set exif ./sticker/takestick_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
                    if (error) return reply(ind.err())
                    client.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), sticker,)
                    fs.unlinkSync(media)
                    fs.unlinkSync(`./sticker/takestick_${sender}.exif`)
                    })
                    }else {
                    reply(`Kirim gambar/video dengan caption ${prefix}stickerwm nama|author atau tag gambar/video yang sudah dikirim\nNote : Durasi video maximal 10 detik`)
                    }
                    }
                    limitAdd(sender, limit)
                    break
          case 'setexif':
          case 'exif':
                     if (!isOwner) return reply(ind.ownerb())
                     const namaPack = q.split('|')[0] ? q.split('|')[0] : q
                     const authorPack = q.split('|')[1] ? q.split('|')[1] : ''
                     exif.create(namaPack, authorPack)
                     reply('_DONE!_')
                     break
        case 'takestick':
	    case 'takestik':
	                if (!isRegister) return reply(ind.noregis())
	                if (!isPrem) return reply(ind.prem())
				    if (isBanned) return reply(ind.banned())
			        const pembawm = body.slice(10)
		            if (args.length < 1) return reply(`Contoh *${prefix}${command} Punya|Bot*`)
		            reply(ind.wait())
				    const encmmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
				    const bufag = await client.downloadAndSaveMediaMessage(encmmedia, `./sticker/${sender}`)
				    const packname = pembawm.split('|')[0]
				    const author = pembawm.split('|')[1]
				    exif.create(packname, author, `takestick_${sender}`)
				    exec(`webpmux -set exif ./sticker/takestick_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
					client.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`),sticker,)
					fs.unlinkSync(bufag)
					fs.unlinkSync(`./sticker/takestick_${sender}.exif`)
	                })
				    break
        case 'slowmo':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
			    	media = await client.downloadAndSaveMediaMessage(encmedia)
				    ran = getRandom('.mp3')
				    exec(`ffmpeg -i ${media} -filter:a "atempo=0.7,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
			    	fs.unlinkSync(media)
				    if (err) return reply('Error!')
			    	uhh = fs.readFileSync(ran)
			    	client.sendMessage(from, uhh, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek,duration:999999999999})
			    	fs.unlinkSync(ran)
			     	})
			     	break
         case 'tupai':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -filter:a "atempo=0.5,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
					fs.unlinkSync(media)
					if (err) return reply('Error!')
					hah = fs.readFileSync(ran)
					client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek,duration:999999999999})
					fs.unlinkSync(ran)
					})
				    break
	    case 'gemok':
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -filter:a "atempo=1.6,asetrate=22100" ${ran}`, (err, stderr, stdout) => {
					fs.unlinkSync(media)
					if (err) return reply('Error!')
					hah = fs.readFileSync(ran)
					client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek,duration:999999999999})
					fs.unlinkSync(ran)
					})
				    break
	    case 'geprek':     
                    if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} -af equalizer=f=94:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
					fs.unlinkSync(media)
					if (err) return reply('Error!')
					hah = fs.readFileSync(ran)
					client.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
					fs.unlinkSync(ran)
					})
					break
         case 'joingc':
         case 'join':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isOwner) return reply(ind.ownerb())
                    if (args.length < 1) return reply('Link nya mana?')
                    client.query({
                    json:["action", "invite", `${args[0].replace('https://chat.whatsapp.com/','')}`]
                    })
                    reply(`Sukses Join`)
                    break
         case 'meme': 
			        if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/random/meme?apikey=${lolkey}`, {method: 'get'})
                    client.sendMessage(from, buffer, image, {caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'memeindo': 
			        if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    buffer = await getBuffer(`http://api.lolhuman.xyz/api/meme/memeindo?apikey=${lolkey}`, {method: 'get'})
                    client.sendMessage(from, buffer, image, { caption: `❒ *Nih Kak :* ${pushname}`, quoted: mek})
                    break
        case 'darkjokes':
		            if (!isRegister) return reply(ind.noregis())
				    if (isBanned) return reply(ind.banned())
				    reply(ind.wait())
                    buffer = await getBuffer(`http://lolhuman.herokuapp.com/api/meme/darkjoke?apikey=${lolkey}`, {method: 'get'})
                    client.sendMessage(from, buffer, image, {quoted: mek, caption: `❒ *Nih Kak :* ${pushname}`})
                    break   
         case 'sound1':
         case 'sound2':
         case 'sound3':
         case 'sound4':
         case 'sound5':
         case 'sound6':
         case 'sound7':
         case 'sound8':
         case 'sound9':
         case 'sound10':
         case 'sound11':
         case 'sound12':
         case 'sound13':
         case 'sound14':
         case 'sound15':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    sound = fs.readFileSync(`./media/sound/${command}.mp3`)
                    client.sendMessage(from, sound, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
                    break
         case 'cekapikey':
	                if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/checkapikey?apikey=${lolkey}`)
                    get_result = get_result.result
                    ckpa = `❏ *Username* : ${get_result.username}\n`
                    ckpa += `❏ *Request* : ${get_result.requests}\n`
                    ckpa += `❏ *Today* : ${get_result.today}\n`
                    ckpa += `❏ *Type* : ${get_result.account_type}\n`
                    ckpa += `❏ *Expired* : ${get_result.expired}`
                    reply(ckpa)
                    break
      case 'playvideo':
      case 'playv':
      case 'playmp4':{
                    if (!isRegister) return reply(ind.noregis())
                    if (!isPrem) return reply(ind.prem())
                    if (isBanned) return reply(ind.ban())
                    reply(ind.wait())
                    if (args.length === 0) return reply(`EXAMPLE : \n${prefix + command} _QUERY_`)
                    try {
                    let yut = await yts(q)
                    ytv(yut.videos[0].url)
                    .then((res) => {
                    const { dl_link, thumb, title, filesizeF, filesize } = res
                    axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                    .then((a) => {
                    if (Number(filesize) >= 40000) return  client.sendMessage(from, `*─ 「 YOUTUBE VIDEO 」─*\n\n*▢ Title :* ${title}\n*▢ Filesize :* ${filesizeF}\n*▢ Upload :* ${yut.videos[0].ago}\n*▢ Ditonton :* ${yut.videos[0].views}\n*▢ Duration :* ${yut.videos[0].timestamp}\n\n\`\`\`UKURAN FILE TERLALU BESAR ANDA BISA DOWNLOAD MELALUI LINK DI ATAS!\`\`\``, text, {quoted : mek})
                    const captionis = `─ 「 YOUTUBE VIDEO 」─\n\n*▢ Title :* ${title}\n*▢ Filesize :* ${filesizeF}\n*▢ Upload :* ${yut.videos[0].ago}\n*▢ Ditonton :* ${yut.videos[0].views}\n*▢ Duration :* ${yut.videos[0].timestamp}\n*▢ LINK :* ${yut.videos[0].url}\n\n\`\`\`TUNGGU SEBENTAR, VIDEO SEDANG DIKIRIM\`\`\``
                    client.sendMessage(from, captionis, text, {quoted : mek}).then((res) => sendFileFromUrl(from, dl_link, '', res))
                    })
                    })
                    } catch (err) {
                    console.log('Error : %s', color(err, 'red'))
                    reply(ind.err())
                    }
                    }
                   limitAdd(sender, limit)
                   break
        case 'ytdl':
        case 'ytplay':
        case 'playmp3':
        case 'play':{
if (!isRegister) return reply(ind.noregis())
if (!q) return reply(`Example : ${prefix+command} query`)
reply(ind.wait())
res = await yts(q)
if (Number(res.all[0].seconds) >= 3000) return reply(`Error! Ukuran File Terlalu Besar!!`)
let thumbInfo = `*─ 「 YOUTUBE 」─*

*◯ Judul :* ${res.all[0].title}
*◯ Diupload :* ${res.all[0].ago}
*◯ Penonton :* ${res.all[0].views}
*◯ Durasi :* ${res.all[0].timestamp}
*◯ LINK :* ${res.all[0].url}
*◯ Deskripsi :* 
${res.all[0].description}`
const gambra = (await client.prepareMessageMedia({url:res.all[0].image},'imageMessage',{thumbnail:Buffer.alloc(0)})).imageMessage
const buttonsssok = [
{buttonId:`${prefix}pleybuttonvideo ${res.all[0].url}`,buttonText:{displayText:'VIDEO '},type:1},
{buttonId:`${prefix}pleybuttonaudio ${res.all[0].url}`,buttonText:{displayText:'AUDIO'},type:1}
]
                    const ButtonsMessagees = {
                    contentText: thumbInfo,
                    buttons: buttonsssok,
                    footerText: `Silahkan Pilih Jenis File Dibawah Ini`,
                    headerType: 4,
                    imageMessage: gambra
                    }
                    client.sendMessage(from, ButtonsMessagees, MessageType.buttonsMessage, {quoted: mek})
                    }
                    break
      case 'pleybuttonvideo':{
                    if (!isRegister) return reply(ind.noregis())
                    reply(ind.wait())
                    let yut = await yts(q)
                    ytv(yut.videos[0].url)
                    .then((res) => {
                    const { dl_link, thumb, title, filesizeF, filesize } = res
                    axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                    .then((a) => {
                    if (Number(filesize) >= 20000) return reply('FILE TERLALU BESAR!!!')
                    sendFileFromUrl(dl_link, video, {mimetype: 'video/mp4',quoted:mek})
                    })
                    })
                    }
                    break
         case 'pleybuttonaudio':{
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    let yut = await yts(q)
                    yta(yut.videos[0].url)
                    .then((res) => {
                    const { dl_link, thumb, title, filesizeF, filesize } = res
                    axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                    .then((a) => {
                    if (Number(filesize) >= 20000) return reply('FILE TERLALU BESAR!!!')
                    sendFileFromUrl(dl_link, audio, {mimetype: 'audio/mp4', quoted:mek})
                    })
                    })
                    }
                    break
        case 'jooxplay':
        case 'joox':
		            if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Melukis Senja`)
                    reply(ind.wait())
                    query = args.join(" ")
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/jooxplay?apikey=${lolkey}&query=${query}`)
                    get_result = get_result.result
                    ini_mn1k = `*❏ JOOX PLAY*\n`
                    ini_mn1k += `*Judul* : ${get_result.info.song}\n`
                    ini_mn1k += `*Artis* : ${get_result.info.singer}\n`
                    ini_mn1k += `*Durasi* : ${get_result.info.duration}\n`
                    ini_mn1k += `*Album* : ${get_result.info.album}\n`
                    ini_mn1k += `*Upload* : ${get_result.info.date}\n\n`
                    ini_mn1k += `*Silahkan Tunggu Sebentar Kak ${pushname} Lagu Sedang Dikirim Mungkin Butuh Beberapa Menit.*`
                    thumbnail = await getBuffer(get_result.image)
                    client.sendMessage(from, thumbnail, image, { quoted: mek, caption: ini_mn1k })
                    get_audio = await getBuffer(get_result.audio[0].link)
                    client.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.info.song}.mp3`, quoted: mek})
                    break
         case 'tomp3':
         case 'toaudio':
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isBanned) return reply(ind.ban())
                    if (!isQuotedVideo) return reply(`REPLY VIDEONYA BOSS`)
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    var encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
                    var media = await client.downloadAndSaveMediaMessage(encmedia)
                    var ran = getRandom('.mp4')
                    exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply('Gagal, pada saat mengkonversi video ke mp3')
                    var buffer = fs.readFileSync(ran)
                    client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', quoted: mek})
                    fs.unlinkSync(ran)
                    })
                    limitAdd(sender, limit)
                    break
        case 'toimg':
                    if (!isRegister) return reply(ind.noregis())
		            if (isBanned) return reply(ind.banned())
		        	if (!isQuotedSticker) return reply('Reply/tag sticker !')
		            reply(ind.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media)
					if (err) return reply('Error Kak')
					buffer = fs.readFileSync(ran)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: `❒ *Nih Kak :* ${pushname}`})
			        fs.unlinkSync(ran)
				    })
					break
        case 'igdl':
        case 'ig':
        case 'instagram':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.ban())
                    if (args.length < 1) return reply(`LINKNYA MANA?`)
                    if (!isUrl) return reply(ind.linkga())
                    reply(ind.wait())
                    anu = await igdls(q)
                    buffer = await getBuffer(anu.url_list[0])
                    client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: mek})
                    break
         case 'caripesan':
                    if (!isRegister) return reply(ind.noregis()) 
                    if(!q)return reply('pesannya apa bang?')
                    let v = await client.searchMessages(q,from,10,1)
                    let s = v.messages
                    let el = s.filter(v => v.message)
                    el.shift()
                    try {
                    if(el[0].message.conversation == undefined) return
                    reply(`Ditemukan ${el.length} pesan`)
                    await sleep(3000)
                    for(let i = 0; i < el.length; i++) {
                    await client.sendMessage(from,'Nih pesannya',text,{quoted:el[i]})
                    }
                    } catch(e){
                    reply('Pesan tidak ditemukan!')
                    }           
                    break
         case 'toptt':
         case 'tovn':
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isBanned) return reply(ind.ban())
                    if (!isQuotedAudio) return reply(`REPLY AUDIONYA BOSS`)
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    var encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
                    var media = await client.downloadAndSaveMediaMessage(encmedia)
                    var ran = getRandom('.mp4')
                    exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return reply('Gagal, pada saat mengkonversi video ke mp3')
                    var buffer = fs.readFileSync(ran)
                    client.sendMessage(from, buffer, audio, {ptt: true, mimetype: 'audio/mp4', quoted: mek})
                    fs.unlinkSync(ran)
                    })
                    limitAdd(sender, limit)
                    break
        case 'tiktokmusic':
        case 'tiktokmusik':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isPrem) return reply(ind.prem())
                    if (args.length < 1) return reply(`Linknya Mana Cuy?\nContoh : ${prefix + command} Melukis Senja`)
                    if (!isUrl) return reply(`ITU KAH LINKNYA?`)        	 				
                    reply(ind.wait())
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
                    ini_link = args[0]
                    get_audio = await getBuffer(`http://api.lolhuman.xyz/api/tiktokmusic?apikey=${lolkey}&url=${ini_link}`)
                    client.sendMessage(from, get_audio, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
                    break    
         case 'artinama':
		            if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Manik`)
                    reply(ind.wait())
                    ini_nama = args.join(" ")
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/artinama?apikey=${lolkey}&nama=${ini_nama}`)
                    get_result.result
                    artnma = `❒ *Artinama* : ${get_result.result}`
                    reply(artnma)
                    break
         case 'weton':
		            if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} 12 12 2020`)
                    reply(ind.wait())
                    tanggal = args[0]
                    bulan = args[1]
                    tahun = args[2]
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/weton/${tanggal}/${bulan}/${tahun}?apikey=${lolkey}`)
                    get_result = get_result.result
                    ini_mn1k = `*❏ Weton* : ${get_result.weton}\n`
                    ini_mn1k += `*❏ Pekerjaan* : ${get_result.pekerjaan}\n`
                    ini_mn1k += `*❏ Rejeki* : ${get_result.rejeki}\n`
                    ini_mn1k += `*❏ Jodoh* : ${get_result.jodoh}`
                    reply(ini_mn1k)
                    break
         case 'tebakumur':
                    if (!isRegister) return reply(ind.noregis())
                    if (args.length == 0) return reply(`Example: ${prefix + command} Udin`)
                    ini_name = args.join(" ")
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/tebakumur?apikey=${lolkey}&name=${ini_name}`)
                    get_result = get_result.result
                    ini_mn1k = `「 *TEBAK UMUR* 」\n\n`
                    ini_mn1k += `*❏ Nama* : ${get_result.name}\n`
                    ini_mn1k += `*❏ Umur* : ${get_result.age}`
                    reply(ini_mn1k)
                    break
        case 'playstore':
		            if (!isRegister) return reply(ind.noregis())
		            if (!isPrem) return reply(ind.prem())
                    if (args.length == 0) return reply(`Example: ${prefix + command} telegram`)
                    query = args.join(" ")
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/playstore?apikey=${lolkey}&query=${query}`)
                    get_result = get_result.result
                    ini_mn1k = `*❏ Play Store Search* :\n`
                    for (var x of get_result) {
                    ini_mn1k += `*Nama* : ${x.title}\n`
                    ini_mn1k += `*Id* : ${x.appId}\n`
                    ini_mn1k += `*Developer* : ${x.developer}\n`
                    ini_mn1k += `*Link* : ${x.url}\n`
                    ini_mn1k += `*Price* : ${x.priceText}\n\n`
                    }
                    reply(ini_mn1k)
                    break
        case 'ganteng': case 'cantik': case 'jelek': case 'goblok':  
        case 'bego': case 'pinter': case 'jago': case 'nolep': case 'monyet':                 	 
        case 'babi': case 'beban': case 'baik': case 'jahat': case 'anjing': 
        case 'haram': case 'pakboy': case 'pakgirl': case 'sadgirl':  
    	case 'wibu': case 'hebat': case 'sadboy':
				    if (!isRegister) return reply(ind.noregis())				
			    	if (isBanned) return reply('*Lu Dah Ke Ban Tuolol*')
			    	if (!isGroup) return reply(`Maaf, Perintah Ini Hanya Dapat Digunakan Dalam Group!`)	
					jds = []
					const jdiid = groupMembers
					const akuut = jdiid[Math.floor(Math.random() * jdiid.length)]
					teks = `YANG PALING *${command}* ADALAH @${akuut.jid.split('@')[0]}`
					jds.push(akuut.jid)
					mentions(teks, jds, true)
					break
       case 'kapankah':  
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
				    const kapan1 = body.slice(1)					 
				    const kpnkh = kapan2[Math.floor(Math.random() * (kapan2.length))]
				    const jawab1 = `Pertanyaan : *${kapan1}*\n\nHasil : *${kpnkh}*`
         		   client.sendMessage(from, jawab1, text, {quoted: mek})
				    break
        case 'bisakah':  
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
				    const tanyaba = body.slice(1)					 
				    const biskah = bisakah[Math.floor(Math.random() * (bisakah.length))]
				    const jawablu = `Pertanyaan : *${tanyaba}*\n\nHasil : *${biskah}*`
         		   client.sendMessage(from, jawablu, text, {quoted: mek})
				    break
        case 'apakah':  
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
				    const apakahy = body.slice(1)					 
				    const apkah = apakah[Math.floor(Math.random() * (apakah.length))]
				    const jawagu = `Pertanyaan : *${apakahy}*\n\nHasil : *${apkah}*`
         		   client.sendMessage(from, jawagu, text, {quoted: mek})
				    break
        case 'ratetampan':
        case 'ratecantik':
        case 'ratelesbi':
        case 'rategay':
        case 'ratesange':
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
					const rate = body.slice(1)
					const ra =['10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					const te = ra[Math.floor(Math.random() * ra.length)]
					const jawna = `Pertanyaan : *${rate}*\n\nHasil : *${te}%*`
					client.sendMessage(from, jawna, text, {quoted: mek})
					break
         case 'watak':
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
					const watak = body.slice(1)
					const wa =['Penyayang','Pemurah','Pemarah','Pemaaf','Penurut','Baik','Baperan','Baik Hati','penyabar','UwU','top deh, pokoknya','Suka Membantu']
					const tak = wa[Math.floor(Math.random() * wa.length)]
					const jaawa = `Pertanyaan : *${watak}*\n\nHasil : *${tak}*`
					client.sendMessage(from, jaawa, text, {quoted: mek})
					break
        case 'jadian':
	                if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
					jds = []
					const jdii = groupMembers
					const koss = groupMembers
					const akuu = jdii[Math.floor(Math.random() * jdii.length)]
					const diaa = koss[Math.floor(Math.random() * koss.length)]
					teks = `Cieee... @${akuu.jid.split('@')[0]} 💞 @${diaa.jid.split('@')[0]} Baru Jadian Nih Bagi Pj Nya Dong`
					jds.push(akuu.jid)
					jds.push(diaa.jid)
					mentions(teks, jds, true)
					break
       case 'fitnah':
       case 'fitnahpc':
                    if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
                    if (args.length < 1) return reply(`Contoh :\n${prefix}fitnah [@tag|pesan|balasanbot]]\n\nEx : \n${prefix}fitnah @tagmember|hai|hai juga`)
                    var ghtt = args.join('')
                    mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
                    var replace = ghtt.split("|")[0];
                    var target = ghtt.split("|")[1];
                    var bot = ghtt.split("|")[2];
                    client.sendMessage(from, `${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target}` }}})
                    break
       case 'tictactoe':
					if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
                    if (isTicTacToe(from, tictactoe)) return reply(`Masih ada game yg blum selesai`)
                    if (args.length < 1) return reply(`Kirim perintah *${prefix}tictactoe* @tag`)
                    if (mek.message.extendedTextMessage != undefined){
                    mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
                    mentions(monospace(`@${sender.split('@')[0]} menantang @${mentioned[0].split('@')[0]} untuk bermain TicTacToe\n\nKirim (Y/T) untuk bermain`), [sender, mentioned[0]], false)
                    tictactoe.push({
                    id: from,
                    status: null,
                    penantang: sender,
                    ditantang: mentioned[0],
                    taruhan: 0,
                    TicTacToe: ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣']
                    })
                    } else {
                    reply(`Kirim perintah *${prefix}tictactoe* @tag`)
                    }
                    break
         case 'resettictactoe':
         case 'resetictactoe':     
                    if (!isRegister) return reply(ind.noregis())
                    if (!isGroup) return reply(ind.groupo())
                    if (!isTicTacToe(from, tictactoe)) return reply(`Tidak ada sesi game tictactoe di grup ini`)
                    tictactoe.splice(getPosTic(from, tictactoe), 1)
                    reply(`Berhasil menghapus sesi tictactoe di grup ini`)
                    break
        case 'bebancek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *BEBANAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🤬`
                    reply(N)
                    break 
        case 'gantengcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *GANTENGAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😎`
                    reply(N)
                    break 
         case 'cantikcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *CANTIKAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😁`
                    reply(N)
                    break 
        case 'jelekcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *J3L3KAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🤢`
                    reply(N)
                    break 
        case 'goblokcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *GOBLOKAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🤣`
                    reply(N)
                    break 
        case 'begocek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *BEGOAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😂`
                    reply(N)
                    break 
        case 'pintercek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *PINTARAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😗`
                    reply(N)
                    break 
        case 'jagocek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *JAGOAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 💪`
                    reply(N)
                    break 
        case 'nolepcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *NOLEPAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🧐`
                    reply(N)
                    break
       case 'baikcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *BAIKKAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😇`
                    reply(N)
                    break 
         case 'jahatcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *JAHATAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 👿`
                    reply(N)
                    break 
         case 'anjingcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *ANJINGAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 👀`
                    reply(N)
                    break
        case 'haramcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *HARAMAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🥴`
                    reply(N)
                    break 
         case 'pakboycek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *PAKBOY* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😏`
                    reply(N)
                    break 
         case 'pakgirlcek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *PAKGIRLAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😏`
                    reply(N)
                    break 
         case 'sangecek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *SANGEAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 🤤`
                    reply(N)
                    break 
       case 'bapercek':
                    Muzza = Math.floor(Math.random() * 100) + 1
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    N = `KE *BAPERAN* KAMU\n`
                    N += `ADALAH : *${Muzza}%* 😘`
                    reply(N)
                    break 
        case 'katailham':
                    if (!isRegister) return reply(ind.noregis()) 
			        if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
                    ktahm = katailh[Math.floor(Math.random() * (katailh.length))]
                    reply(ktahm)
                    break
        case 'suit':
                    try {
                    if (!isRegister) return reply(ind.noregis()) 
                    const text = args.join(' ')
                    if (!text) return reply(`Pilih Suit:\n❒ *${prefix}suit gunting*\n❒ *${prefix}suit batu*\n❒ *${prefix}suit kertas*`)
                    var m4ni1kku = Math.random()
                    if (m4ni1kku < 0.34) {
                    m4ni1kku = 'batu'
                    } else if (m4ni1kku > 0.34 && m4ni1kku < 0.67) {
                    m4ni1kku = 'gunting'
                    } else {
                    m4ni1kku = 'kertas'
                    }
                    if (text == m4ni1kku) {
                    reply(`Hasil Pertandingan Seri, Mau Bermain Lagi Kak *${pushname}*?`)
                    } else if (text == 'batu') {
                    if (m4ni1kku == 'gunting') {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nSelamat Kamu Menang Kamu Berhak Mendapatkan Bonus!`)
                    } else {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nMaaf Kak Kamu Kalah Dalam Pertandingan Ini!`)
                    }
                    } else if (text == 'gunting') {
                    if (m4ni1kku == 'kertas') {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nSelamat Kamu Menang Kamu Berhak Mendapatkan Bonus!`)
                    } else {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nMaaf Kak Kamu Kalah Dalam Pertandingan Ini!`)
                    }
                    } else if (text == 'kertas') {
                    if (m4ni1kku == 'batu') {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nSelamat Kamu Menang Kamu Berhak Mendapatkan Bonus!`)
                    } else {
                    reply(`*「 HASIL 」*\n\n*❒ Kamu :* ${text}\n*❒ Akiraa Bot :* ${m4ni1kku}\n\nMaaf Kak Kamu Kalah Dalam Pertandingan Ini!`)
                    }
                    } else {
                    reply(`Pilih Suit:\n❒ *${prefix}suit gunting*\n❒ *${prefix}suit batu*\n❒ *${prefix}suit kertas*`)
                    }
                    } catch {
                    reply('_Error_')
                    }
                    break
        case 'mathkuis':
        case 'match':
        case 'math': {
                    try {
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isGame(sender, isOwner, gcount, glimit)) return reply(ind.limit(pushname))
                    if (game.isMtk(from, mtk)) return reply(`Masih ada soal yang belum di selesaikan`)
                    let buh = await fetchJson(`https://h4ck3rs404-api.herokuapp.com/api/kuis/math?mode=${q}&apikey=404Api`)
                    const petunjuk = buh.result.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
                    bp = await client.sendMessage(from, `*Soal :* ${buh.result.soal} \nWaktu : ${gamewaktu}s`, text, {quoted:mek, thumbnail:gambar2 })
                    let anih = buh.result.jawaban.toLowerCase()
                    game.addmtk(from, anih, gamewaktu, mtk)
                    gameAdd(sender, glimit)
                    setTimeout(() => {
                    client.deleteMessage(from, bp.key)
                    }, gamewaktu+`000`)
                    } catch {
                    list = []
commandnya = [
`easy`,
`medium`,
`hard`,
`extreme`,
`impossible`,
`pro`
]
 viewmenunya = [
`◯ MODE - EASY`,
`◯ MODE - MEDIUM`,
`◯ MODE - HARD`,
`◯ MODE - EXTREME`,
`◯ MODE - IMPOSSIBLE`,
`◯ MODE - PRO`
]
                    startnum = 0
                    for (let x of commandnya) {
                    const yy = {title: `──────────────`,
                    rows: [
                    {
                    title: `${viewmenunya[startnum++]}`,
                    description: ``,
                    rowId: `${prefix}math ${x}`
                    }
                    ]
                    }
                    list.push(yy)
                    }
                    listmsg(from, `─ 「 *MATH KUIS* 」 ─`, `SILAHKAN PILIH MODE DI BAWAH INI `, `PILIH MODE DISINI`,`𝙼𝙰𝚃𝙷 𝙺𝚄𝙸𝚂`, list)
                    mtk.splice(game.getMtkPosi(from, mtk), 1)
                    }
                    }
                    break
        case 'tebakgambar':{
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    let anu = await axios.get(`http://api.lolhuman.xyz/api/tebak/gambar?apikey=${lolkey}`)
                    const petunjuk = anu.data.result.answer.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
                    sendFileFromUrl(from, anu.data.result.image, monospace(`「 *TEBAK GAMBAR* 」\nSilahkan Jawab Soal Yang Ada Di Foto Ini\n\nWaktu : ${gamewaktu}s`), mek)
                    let m = anu.data.result.answer.toLowerCase()
                    game.addgambar(from, m, gamewaktu, tebakgambar)
                    }
                    limitAdd(sender, limit) 
                    break
   	case 'family100':
			    	if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
					anu = await fetchJson(`http://api.lolhuman.xyz/api/tebak/family100?apikey=${lolkey}`, {method: 'get'})
					family = `*${anu.result.question}*`
					setTimeout( () => {
					client.sendMessage(from, '*➸ Jawaban :* '+anu.result.aswer, text, {quoted: mek})
					}, 30000)
					setTimeout( () => {
					client.sendMessage(from, '_10 Detik lagi…_', text)
					}, 20000)
					setTimeout( () => {
					client.sendMessage(from, '_20 Detik lagi_…', text)
					}, 10000)
					setTimeout( () => {
					client.sendMessage(from, '_30 Detik lagi_…', text)
					}, 2500)
					setTimeout( () => {
					client.sendMessage(from, family, text, {quoted: mek})
					}, 0)
					limitAdd(sender, limit)
					break    
         case 'infogempa':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    get_result = await fetchJson(`http://api.lolhuman.xyz/api/infogempa?apikey=${lolkey}`)
                    get_result = get_result.result
                    ini_txt = `*❏ Lokasi :* ${get_result.lokasi}\n`
                    ini_txt += `*❏ Waktu :* ${get_result.waktu}\n`
                    ini_txt += `*❏ Potensi :* ${get_result.potensi}\n`
                    ini_txt += `*❏ Magnitude :* ${get_result.magnitude}\n`
                    ini_txt += `*❏ Kedalaman :* ${get_result.kedalaman}\n`
                    ini_txt += `*❏ Koordinat :* ${get_result.koordinat}`
                    get_buffer = await getBuffer(get_result.map)
                    client.sendMessage(from, get_buffer, image, { quoted: mek, caption: ini_txt })
                    limitAdd(sender, limit)
                    break
        case 'quotes':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    quotess = await fetchJson(`http://api.lolhuman.xyz/api/random/quotes?apikey=${lolkey}`)
                    quotess = quotess.result
                    authorr = quotess.by
                    quotess = quotess.quote
                    reply(`_${quotess}_\n\n*― ${authorr}*`)
                    limitAdd(sender, limit)
                    break
        case 'quotesanime':
                    if (!isRegister) return reply(ind.noregis())
                    if (isBanned) return reply(ind.banned())
                    reply(ind.wait())
                    quotes = await fetchJson(`http://api.lolhuman.xyz/api/random/quotesnime?apikey=${lolkey}`)
                    quotes = quotes.result
                    quote = quotes.quote
                    char = quotes.character
                    anime = quotes.anime
                    episode = quotes.episode
                    reply(`_${quote}_\n\n*― ${char}*\n*― ${anime} ${episode}*`)
                    limitAdd(sender, limit)
                    break
        case 'pantun':  
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)	
                    anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/random_pantun`)
                    anu1 = `➻ *PANTUN* : ${anu.result}\n` 
                    reply(anu1)
                    break
        case 'tts': 
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isBanned) return reply(ind.banned())
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
			        limitAdd(sender, limit)
				    if (args.length < 1) return client.sendMessage(from, 'Diperlukan kode bahasa kak!!', text, {quoted: mek})					 
					if (args.length < 2) return client.sendMessage(from, 'Mana teks yang mau di jadiin suara? suara setan kah?', text, {quoted: mek})
					reply(ind.wait())
					dtt = body.slice(8)
					const gtts = require('./lib/gtts')(args[0])
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 800
				    ? reply('Maksimal Teks 800 Huruf')
					: gtts.save(ranm, dtt, function() {
					exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
					fs.unlinkSync(ranm)
					buffer = fs.readFileSync(rano)
					client.sendMessage(from, buffer, audio, {ptt:true, quoted:mek})
					fs.unlinkSync(rano)
					})
					})
					break  
        case 'tribunews':
        case 'tribunnews':
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
                    client.updatePresence(from, Presence.composing) 
                    data = await fetchJson(`https://api.zeks.xyz/api/tribunews?apikey=${zekskey}`, {method: 'get'})
                    teks = '=================\n'
                    for (let i of data.result) {
                    teks += `*Judul* : ${i.title}\n*Time* : ${i.time}\n*Link* : ${i.url}\n*Keterangan* : ${i.ket}\n=================\n`
                    }
                    reply(teks.trim())
                    limitAdd(sender, limit)
                    break
       case 'liputan6': 
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
					client.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.zeks.xyz/api/liputan6?apikey=${zekskey}`, {method: 'get'})
					teks = '=================\n'
					for (let i of data.result) {
                    teks += `*Judul* : ${i.title}\n*Url* : ${i.url}\n*Keterangan* : ${i.ket}\n*Category* : ${i.category}\n*Time* : ${i.time}\n=================\n`
					}
					reply(teks.trim())
					limitAdd(sender, limit)
					break
    	case 'nickff': 
                    if (isBanned) return reply(ind.banned())
                    if (!isRegister) return reply(ind.noregis()) 
                    if (isLimit(sender, isPrem, isOwner, limitawal, limit)) return reply(ind.limit(pushname))
                    reply(ind.wait())
					client.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.zeks.xyz/api/nickepep?apikey=${zekskey}`, {method: 'get'})
					teks = '=================\n'
					for (let i of data.result) {
                    teks += `*Nick* : ${i}\n=================\n`
					}
					reply(teks.trim())
					limitAdd(sender, limit)
					break

default:
if (isGroup && isAntiVo && m.mtype == 'viewOnceMessage'){
var msg = {...mek}
let typenya = msg.message.viewOnceMessage.message["videoMessage"] ?
msg.message.viewOnceMessage.message.videoMessage : msg.message.viewOnceMessage.message.imageMessage   
typenya["viewOnce"] = false
typenya["caption"] = `⦁─┈❥︎❀• *Anti-ViewOnce* •❀❥︎┈─⦁${(typenya.caption === '') ? `\n\n*◯ Type : `+typenya.mimetype+'*' : `\n\n*◯ Caption : `+typenya.caption+`*\n*◯ Type : `+typenya.mimetype+'*'}`  
let peq = msg.message.viewOnceMessage.message["imageMessage"] ? { key: { fromMe: false, participant: sender, id: mek.key.id }, message: {"viewOnceMessage": {"message": { "imageMessage" : {"viewOnce": true } } } } } :  { key: { fromMe: false, participant: sender, id: mek.key.id }, message: {"viewOnceMessage": {"message": { "imageMessage" : {"viewOnce": true } } } } }  
let pe = await client.prepareMessageFromContent(from, msg.message.viewOnceMessage.message, {quoted: peq, tumbnail:gambar2})  
await client.relayWAMessage(pe)
}
if (budy.startsWith("=")){
if (isBanned) return
reply(`${Math_js.evaluate(budy.slice(1).replace("×","*").replace("x","*").replace("X","*").replace("÷","/").replace(":","/").replace("kali","*").replace("bagi","/").replace("tambah","+").replace("tamba","+").replace("kurang","-").replace("kurangi","-"))}`)
}
				    if (budy.includes(`alaikum`)){
                    F3 = fs.readFileSync('./media/sound/salamcw.mp3')
                    client.sendMessage(from, F3, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
                    }
                    if (budy.includes(`'alaikum`)){
                    F3 = fs.readFileSync('./media/sound/salamcw.mp3')
                    client.sendMessage(from, F3, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
                    }
                    if (budy.includes(`${nomorbot}`)) {
                    if (!isGroup) return
                    N = `Yaa Ada Apa ${pushname} Silahkan Kirim ${prefix}menu`
                    client.sendMessage(from, N, text, {quoted: mek})
                    }
                    if (budy == 'Makasih') {
                    reply(`Sama Sama Kak`)   
			        }
			        if (budy == 'Bot') {
                    reply(`Ya Kak Kenapa`)
                    }
                    if (budy == 'bot') {
                    reply(`Ya Kak Kenapa`)
                    }
                    if (budy == 'Gratata') {
					ssds = fs.readFileSync('./media/sound/djgratata.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Gemes') {
					ssds = fs.readFileSync('./media/sound/gemes.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Alay') {
					ssds = fs.readFileSync('./media/sound/Alay.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Ara') {
					ssds = fs.readFileSync('./media/sound/Ara.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Bernyanyi') {
					ssds = fs.readFileSync('./media/sound/bernyanyi.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Bwa') {
					ssds = fs.readFileSync('./media/sound/bwa.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Bermain') {
					ssds = fs.readFileSync('./media/sound/xbermain.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Gta') {
					ssds = fs.readFileSync('./media/sound/djgta.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Kaweni') {
					ssds = fs.readFileSync('./media/sound/djkaweni.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Gatal') {
					ssds = fs.readFileSync('./media/sound/gatal.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Sakit') {
					ssds = fs.readFileSync('./media/sound/djsakit.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Zombie') {
					ssds = fs.readFileSync('./media/sound/djzombie.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Iri') {
					ssds = fs.readFileSync('./media/sound/iri.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Ladadida') {
					ssds = fs.readFileSync('./media/sound/ladadida.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Papipip') {
					ssds = fs.readFileSync('./media/sound/papipip.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Pota') {
					ssds = fs.readFileSync('./media/sound/pota.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Tengteng') {
					ssds = fs.readFileSync('./media/sound/tengteng.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Welot') {
					ssds = fs.readFileSync('./media/sound/welot.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Tapi') {
					ssds = fs.readFileSync('./media/sound/tb.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Gamgam') {
					ssds = fs.readFileSync('./media/sound/rusher.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Manis') {
					ssds = fs.readFileSync('./media/sound/manis.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Nomix') {
					ssds = fs.readFileSync('./media/sound/safonomix.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Sariroti') {
					ssds = fs.readFileSync('./media/sound/sariroti.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
			        if (budy == 'Pale') {
					ssds = fs.readFileSync('./media/sound/pale.mp3');
					client.sendMessage(from, ssds, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			        }
                    if (isCmd) {
                    N = `Perintah *${prefix}${command}* Tidak Ditemukan!`
                    client.sendMessage(from, N, text, {quoted: mek})
	                }
                    }
                    } catch (e) {
                    e = String(e)
                    if (!e.includes("this.isZero")) {
                    if (!e.includes("Cannot read property 'conversation' of null")) {
                    if (!e.includes("Cannot read property 'contextInfo' of undefined")) {
                    if (!e.includes("Cannot set property 'mtype' of undefined")) {
                    if (!e.includes("jid is not defined")) {
                    console.log('ERROR : %s', color(e, 'red'))
                    }
                  }
               }
           }
       }
   }
}