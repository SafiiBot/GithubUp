exports.cekmenu = (prefix) => {
return`┌───「 CHECK MENU 」
│
│❒ ${prefix}gantengcek 
│❒ ${prefix}cantikcek 
│❒ ${prefix}jelekcek 
│❒ ${prefix}goblokcek 
│❒ ${prefix}begocek 
│❒ ${prefix}pintercek 
│❒ ${prefix}jagocek 
│❒ ${prefix}nolepcek 
│❒ ${prefix}bebancek 
│❒ ${prefix}baikcek 
│❒ ${prefix}jahatcek 
│❒ ${prefix}anjingcek 
│❒ ${prefix}haramcek 
│❒ ${prefix}pakboycek 
│❒ ${prefix}pakgirlcek 
│❒ ${prefix}sangecek 
│❒ ${prefix}bapercek
│
└─────────────────`
}

exports.islammenu = (prefix) => {
return`┌───「 ISLAMI 」
│
│❒ ${prefix}alquran
│❒ ${prefix}jadwalsholat
│❒ ${prefix}asmaulhusna
│❒ ${prefix}kisahnabi
│❒ ${prefix}alquranaudio
│❒ ${prefix}listsurah
│❒ ${prefix}niatsholat
│
└─────────────────`
}

exports.grupmenu = (prefix) => {
return`┌───「 GRUP MENU 」
│
│❒ ${prefix}promote [@tag]
│❒ ${prefix}demote [@tag]
│❒ ${prefix}tagall
│❒ ${prefix}listpremium
│❒ ${prefix}banlist
│❒ ${prefix}blocklist
│❒ ${prefix}linkgc
│❒ ${prefix}resetlink
│❒ ${prefix}grupinfo
│❒ ${prefix}sider
│❒ ${prefix}mute
│❒ ${prefix}unmute
│❒ ${prefix}hidetag
│❒ ${prefix}add [62]
│❒ ${prefix}kick [@tag]
│❒ ${prefix}setnama
│❒ ${prefix}setdesk
│❒ ${prefix}setpp
│❒ ${prefix}listvn
│❒ ${prefix}listgrup
│❒ ${prefix}listsewa
│❒ ${prefix}adminlist
│❒ ${prefix}buggc
│❒ ${prefix}leave
│❒ ${prefix}level    
│❒ ${prefix}antidelete aktif/mati
│❒ ${prefix}grup buka/tutup 
│❒ ${prefix}welcome aktif/mati
│❒ ${prefix}nsfw aktif/mati
│❒ ${prefix}antilink aktif/mati
│❒ ${prefix}antikasar aktif/mati
│❒ ${prefix}simisimi aktif/mati
│
└─────────────────`
}

exports.ownermenu = (prefix) => {
return`┌───「 OWNER MENU 」
│
│❒ ${prefix}prem add
│❒ ${prefix}prem dell
│❒ ${prefix}bc
│❒ ${prefix}setexif
│❒ ${prefix}joingc
│❒ ${prefix}readall
│❒ ${prefix}clearall
│❒ ${prefix}banadd
│❒ ${prefix}bandell
│❒ ${prefix}leave
│❒ ${prefix}sewa add/dell
│❒ ${prefix}event aktif/mati
│❒ ${prefix}clone
│❒ ${prefix}setppbot
│❒ ${prefix}sethargalimit
│❒ ${prefix}setnamaowner
│❒ ${prefix}setnamabot
│❒ ${prefix}setwaktugametb
│
└─────────────────`
}

exports.nsfwmenu = (prefix) => {
return`┌───「 NSFW MENU 」
│
│❒ ${prefix}waifu
│❒ ${prefix}husbu
│❒ ${prefix}loli
│❒ ${prefix}elf
│❒ ${prefix}art
│❒ ${prefix}bts
│❒ ${prefix}exo
│❒ ${prefix}neko
│❒ ${prefix}shota
│❒ ${prefix}husbu
│❒ ${prefix}sagiri
│❒ ${prefix}shinobu
│❒ ${prefix}megumin
│❒ ${prefix}wallnime
│❒ ${prefix}chiisaihentai
│❒ ${prefix}trap
│❒ ${prefix}blowjob
│❒ ${prefix}yaoi
│❒ ${prefix}ecchi
│❒ ${prefix}hentai
│❒ ${prefix}ahegao
│❒ ${prefix}hololewd
│❒ ${prefix}sideoppai
│❒ ${prefix}animefeets
│❒ ${prefix}animebooty
│❒ ${prefix}animethighss
│❒ ${prefix}hentaiparadise
│❒ ${prefix}animearmpits
│❒ ${prefix}hentaifemdom
│❒ ${prefix}lewdanimegirls
│❒ ${prefix}biganimetiddies
│❒ ${prefix}animebellybutton
│❒ ${prefix}hentai4everyone
│❒ ${prefix}bj
│❒ ${prefix}ero
│❒ ${prefix}cum
│❒ ${prefix}feet
│❒ ${prefix}yuri
│❒ ${prefix}trap
│❒ ${prefix}lewd
│❒ ${prefix}feed
│❒ ${prefix}eron
│❒ ${prefix}solo
│❒ ${prefix}gasm
│❒ ${prefix}poke
│❒ ${prefix}anal
│❒ ${prefix}holo
│❒ ${prefix}tits
│❒ ${prefix}kuni
│❒ ${prefix}kiss
│❒ ${prefix}erok
│❒ ${prefix}smug
│❒ ${prefix}baka
│❒ ${prefix}solog
│❒ ${prefix}feetg
│❒ ${prefix}lewdk
│❒ ${prefix}pussy
│❒ ${prefix}femdom
│❒ ${prefix}cuddle
│❒ ${prefix}hentai
│❒ ${prefix}eroyuri
│❒ ${prefix}cum_jpg
│❒ ${prefix}blowjob
│❒ ${prefix}erofeet
│❒ ${prefix}holoero
│❒ ${prefix}classic
│❒ ${prefix}erokemo
│❒ ${prefix}fox_girl
│❒ ${prefix}futanari
│❒ ${prefix}lewdkemo
│❒ ${prefix}wallpaper
│❒ ${prefix}pussy_jpg
│❒ ${prefix}kemonomimi
│❒ ${prefix}nsfw_avatar
│
└─────────────────`
}

exports.makermenu = (prefix) => {
return`┌───「 MAKER MENU 」
│
│❒ ${prefix}blackpink text
│❒ ${prefix}neon text
│❒ ${prefix}greenneon text
│❒ ${prefix}advanceglow text
│❒ ${prefix}futureneon text
│❒ ${prefix}sandwriting text
│❒ ${prefix}sandsummer text
│❒ ${prefix}sandengraved text
│❒ ${prefix}metaldark text
│❒ ${prefix}neonlight text
│❒ ${prefix}text1917 text
│❒ ${prefix}minion text
│❒ ${prefix}deluxesilver text
│❒ ${prefix}newyearcard text
│❒ ${prefix}bloodfrosted text
│❒ ${prefix}halloween text
│❒ ${prefix}jokerlogo text
│❒ ${prefix}fireworksparkle text
│❒ ${prefix}natureleaves text
│❒ ${prefix}bokeh text
│❒ ${prefix}toxic text
│❒ ${prefix}strawberry text
│❒ ${prefix}box3d text
│❒ ${prefix}roadwarning text
│❒ ${prefix}breakwall text
│❒ ${prefix}icecold text
│❒ ${prefix}luxury text
│❒ ${prefix}cloud text
│❒ ${prefix}summersand text
│❒ ${prefix}horrorblood text
│❒ ${prefix}pornhub text1 text2
│❒ ${prefix}glitch text1 text2
│❒ ${prefix}avenger text1 text2
│❒ ${prefix}space text1 text2
│❒ ${prefix}ninjalogo text1 text2
│❒ ${prefix}marvelstudio text1 text2
│❒ ${prefix}lionlogo text1 text2
│❒ ${prefix}wolflogo text1 text2
│❒ ${prefix}steel3d text1 text2
│❒ ${prefix}wallgravity text1 text2

❒ *PHOTO OXY*
│❒ ${prefix}tahta text
│❒ ${prefix}shadow text
│❒ ${prefix}cup text
│❒ ${prefix}cup1 text
│❒ ${prefix}romance text
│❒ ${prefix}smoke text
│❒ ${prefix}burnpaper text
│❒ ${prefix}lovemessage text
│❒ ${prefix}undergrass text
│❒ ${prefix}love text
│❒ ${prefix}coffe text
│❒ ${prefix}woodheart text
│❒ ${prefix}woodenboard text
│❒ ${prefix}summer3d text
│❒ ${prefix}wolfmetal text
│❒ ${prefix}nature3d text
│❒ ${prefix}golderrose text
│❒ ${prefix}summernature text
│❒ ${prefix}letterleaves text
│❒ ${prefix}glowingneon text
│❒ ${prefix}fallleaves text
│❒ ${prefix}flamming text
│❒ ${prefix}harrypotter text
│❒ ${prefix}carvedwood text
│❒ ${prefix}ttlogo text1 text2
│❒ ${prefix}arcade8bit text1 text2
│❒ ${prefix}battlefield4 text1 text2
│❒ ${prefix}pubg text1 text2

❒ *PHOTO 360⁰*
│❒ ${prefix}wetglass text
│❒ ${prefix}multicolor3d text
│❒ ${prefix}watercolor text
│❒ ${prefix}luxurygold text
│❒ ${prefix}galaxywallpaper text
│❒ ${prefix}lighttext text
│❒ ${prefix}beautifulflower text
│❒ ${prefix}puppycute text
│❒ ${prefix}royaltext text
│❒ ${prefix}heartshaped text
│❒ ${prefix}birthdaycake text
│❒ ${prefix}galaxystyle text
│❒ ${prefix}hologram3d text
│❒ ${prefix}greenneon text
│❒ ${prefix}glossychrome text
│❒ ${prefix}greenbush text
│❒ ${prefix}metallogo text
│❒ ${prefix}noeltext text
│❒ ${prefix}glittergold text
│❒ ${prefix}textcake text
│❒ ${prefix}starsnight text
│❒ ${prefix}wooden3d text
│❒ ${prefix}textbyname text
│❒ ${prefix}writegalacy text
│❒ ${prefix}galaxybat text
│❒ ${prefix}snow3d text
│❒ ${prefix}birthdayday text
│❒ ${prefix}goldplaybutton text
│❒ ${prefix}silverplaybutton text
│❒ ${prefix}freefire text
│❒ ${prefix}gmlogo text
│❒ ${prefix}cartongravity text
│❒ ${prefix}wasted reply
│
└─────────────────`
}

exports.fastmenu = (prefix) => {
return`┌───「 FAST MENU 」
│
│❒ ${prefix}tebakgambar
│❒ ${prefix}katailham
│❒ ${prefix}caripesan
│❒ ${prefix}asupan
│❒ ${prefix}kontak
│❒ ${prefix}getpic
│❒ ${prefix}lirik
│❒ ${prefix}darkjokes
│❒ ${prefix}memeindo
│❒ ${prefix}meme
│❒ ${prefix}truth
│❒ ${prefix}dare
│❒ ${prefix}tts
│❒ ${prefix}cersex
│❒ ${prefix}cerpen
│❒ ${prefix}pantun
│❒ ${prefix}cogan
│❒ ${prefix}cegan
│❒ ${prefix}google
│❒ ${prefix}cuaca
│
└─────────────────`
}

exports.funmenu = (prefix) => {
return`┌───「 FUN MENU 」
│
│❒ ${prefix}textfont
│❒ ${prefix}boomtext
│❒ ${prefix}katajago
│❒ ${prefix}cinta
│❒ ${prefix}halah
│❒ ${prefix}hilih
│❒ ${prefix}huluh
│❒ ${prefix}heleh
│❒ ${prefix}holoh
│❒ ${prefix}readmore
│❒ ${prefix}fake
│
└─────────────────`
}

exports.storagemenu = (prefix) => {
return`┌───「 STORAGE MENU 」
│
│❒ ${prefix}addstiker
│❒ ${prefix}addimage
│❒ ${prefix}addvideo
│❒ ${prefix}addcmd
│❒ ${prefix}dellstiker
│❒ ${prefix}dellimage
│❒ ${prefix}dellvideo
│❒ ${prefix}dellcmd
│❒ ${prefix}liststiker
│❒ ${prefix}listimage
│❒ ${prefix}listvideo
│❒ ${prefix}listcmd
│❒ ${prefix}listvn
│❒ ${prefix}getstiker
│❒ ${prefix}getimage
│❒ ${prefix}getvideo
│
└─────────────────`
}

exports.othermenu = (prefix) => {
return`┌───「 OTHER MENU 」
│
│❒ ${prefix}slot
│❒ ${prefix}infogempa
│❒ ${prefix}qrcode text
│❒ ${prefix}nulis text
│❒ ${prefix}request Fitur
│❒ ${prefix}jadwaltv
│❒ ${prefix}telesticker
│❒ ${prefix}twich
│❒ ${prefix}balance
│❒ ${prefix}ceklimit
│❒ ${prefix}buylimit
│❒ ${prefix}lapor Fitur
│❒ ${prefix}pinterest
│❒ ${prefix}liputan6
│❒ ${prefix}tribunews
│❒ ${prefix}artinama
│❒ ${prefix}quotes
│❒ ${prefix}quotesanime
│
└─────────────────`
}

exports.downmenu = (prefix) => {
return`┌───「 DOWNLOAD MENU 」
│
│❒ ${prefix}play
│❒ ${prefix}joox
│❒ ${prefix}igdl
│❒ ${prefix}playmp4
│❒ ${prefix}tiktoknowm
│❒ ${prefix}playstore
│❒ ${prefix}ytmp3 link
│❒ ${prefix}ytmp4 link
│❒ ${prefix}tiktokmusik
│
└─────────────────`
}

exports.premmenu = (prefix) => {
return`┌───「 PREMIUM MENU 」
│
│❒ ${prefix}tiktoknowm
│❒ ${prefix}tiktokmusik
│❒ ${prefix}playmp4
│❒ ${prefix}pinterest
│❒ ${prefix}takestick
│❒ ${prefix}findsticker
│❒ ${prefix}playstore
│❒ ${prefix}delete
│❒ ${prefix}buggc
│❒ ${prefix}ytmp3
│❒ ${prefix}ytmp4
│
└─────────────────`
}

exports.stalkmenu = (prefix) => {
return`┌───「 STALKING MENU 」
│
│❒ ${prefix}igstalk
│❒ ${prefix}twiterstalk
│❒ ${prefix}githubstalk
│❒ ${prefix}tiktokstalk
│❒ ${prefix}ytstalk
│❒ ${prefix}ffstalk
│
└─────────────────`
}

exports.soundmenu = (prefix) => {
return`┌───「 SOUND MENU 」
│
│❒ ${prefix}sound1
│❒ ${prefix}sound2
│❒ ${prefix}sound3
│❒ ${prefix}sound4
│❒ ${prefix}sound5
│❒ ${prefix}sound6
│❒ ${prefix}sound7
│❒ ${prefix}sound8
│❒ ${prefix}sound9
│❒ ${prefix}sound10
│❒ ${prefix}sound11
│❒ ${prefix}sound12
│❒ ${prefix}sound13
│❒ ${prefix}sound14
│❒ ${prefix}sound15

❒ *PENGUBAH SOUND*
│❒ ${prefix}tupai
│❒ ${prefix}gemok
│❒ ${prefix}slowmo
│❒ ${prefix}geprek
│
└─────────────────`
}

exports.kerangmenu = (prefix) => {
return`┌───「 KERANG MENU 」
│
│❒ ${prefix}apakah
│❒ ${prefix}bisakah
│❒ ${prefix}kapankah
│❒ ${prefix}ratetampan
│❒ ${prefix}ratecantik
│❒ ${prefix}ratelesbi
│❒ ${prefix}ratesange
│❒ ${prefix}rategay
│❒ ${prefix}watak
│
└─────────────────`
}

exports.sertifikatmenu = (prefix) => {
return`┌───「 SERTIFIKAT MENU 」
│
│❒ ${prefix}bucinserti [nama]
│❒ ${prefix}tololserti [nama]
│❒ ${prefix}fuckboy [nama]
│❒ ${prefix}fuckgirl [nama]
│❒ ${prefix}goodboy [nama]
│❒ ${prefix}goodgirl [nama]
│❒ ${prefix}badboy [nama]
│❒ ${prefix}badgirl [nama]
│❒ ${prefix}ffserti [nama]
│❒ ${prefix}ffserti2 [nama]
│❒ ${prefix}ffserti3 [nama]
│
└─────────────────`
}

exports.stikermenu = (prefix) => {
return`┌───「 STICKER MENU 」
│
│❒ ${prefix}sticker
│❒ ${prefix}stikergif
│❒ ${prefix}stikerwm
│❒ ${prefix}semoji
│❒ ${prefix}toimg
│❒ ${prefix}findsticker
│❒ ${prefix}gawrgura
│❒ ${prefix}umongus
│❒ ${prefix}takestick
│❒ ${prefix}stickanjing
│❒ ${prefix}stickbucin
│❒ ${prefix}ttp text
│❒ ${prefix}ttp2 text
│❒ ${prefix}ttp3 text
│❒ ${prefix}ttp4 text
│❒ ${prefix}attp text
│❒ ${prefix}attp2 text
│❒ ${prefix}dadu
│
└─────────────────`
}

exports.tagmenu = (prefix) => {
return`┌───「 TAG MENU 」
│
│❒ ${prefix}ganteng 
│❒ ${prefix}cantik 
│❒ ${prefix}jelek 
│❒ ${prefix}goblok 
│❒ ${prefix}bego 
│❒ ${prefix}pinter 
│❒ ${prefix}jago 
│❒ ${prefix}babi 
│❒ ${prefix}beban 
│❒ ${prefix}baik 
│❒ ${prefix}jahat 
│❒ ${prefix}anjing 
│❒ ${prefix}monyet 
│❒ ${prefix}haram 
│❒ ${prefix}pakboy 
│❒ ${prefix}pakgirl 
│❒ ${prefix}sadboy 
│❒ ${prefix}sadgirl 
│❒ ${prefix}wibu 
│❒ ${prefix}nolep 
│❒ ${prefix}hebat
│
└─────────────────`
}

exports.gamemenu = (prefix) => {
return`┌───「 GAME MENU 」
│
│❒ ${prefix}jadian
│❒ ${prefix}mining
│❒ ${prefix}buylimit
│❒ ${prefix}tebakgambar
│❒ ${prefix}mathkuis
│❒ ${prefix}tebakumur
│❒ ${prefix}family100
│❒ ${prefix}afk (alasan)
│❒ ${prefix}fitnah
│❒ ${prefix}tictactoe [@Tag]
│❒ ${prefix}resetictactoe
│❒ ${prefix}weton
│❒ ${prefix}level
│❒ ${prefix}suit
│❒ ${prefix}nickff
│
└─────────────────`
}

exports.infomenu = (prefix) => {
return`┌───「 INFO MENU 」
│
│❒ ${prefix}runtime
│❒ ${prefix}covidindo
│❒ ${prefix}profile
│❒ ${prefix}infobot
│❒ ${prefix}listgrup
│❒ ${prefix}botgrup
│❒ ${prefix}speed
│❒ ${prefix}ping
│❒ ${prefix}snk
│❒ ${prefix}level
│❒ ${prefix}wame
│❒ ${prefix}balance
│❒ ${prefix}cekapikey
│❒ ${prefix}ceklimit
│❒ ${prefix}cekpremium
│❒ ${prefix}kodebahasa
│❒ ${prefix}donasi
│❒ ${prefix}owner
│❒ ${prefix}delete
│
└─────────────────`
}

exports.listvn = () => {
return`*── 「 VN DATABASE 」 ──*
    
➸ Total : 24
           
➸ Gratata
➸ Gemes
➸ Pale
➸ Alay
➸ Ara
➸ Bernyanyi
➸ Bwa
➸ Bermain
➸ Gta
➸ Kaweni
➸ Gatal
➸ Sakit
➸ Zombie
➸ Iri
➸ Ladadida
➸ Papipip
➸ Pota
➸ Tengteng
➸ Welot
➸ Tapi
➸ Gamgam
➸ Manis
➸ Nomix
➸ Sariroti`
}

exports.sewabot = () => {
return`╭─ *[ SEWA BOT ]*
│• 1 MINGGU : 5K
│• 1 BULAN : 10k
│• PERMANEN : 15k (PROMO)
│• PERPANJANG : 5K/BULAN
╰────
╭─ *[ KELEBIHAN BOT ]*
│• FAST RESPON
│• MENU SIMPLE
│• ANTILINK, WELCOME ON, DLL
╰────
╭─ *[ KEUNTUNGAN ]*
│• ANTI LINK ( AUTO KICK )
│• WELCOME IMAGE ( OTOMATIS )
│• DAN 500+ FITUR LAINNYA
│• PERINTAH KICK
╰────
📍 MINAT?
CHAT : http://wa.me/${nomerowner}?text=Assalamu'alaikum+Kak+Mau+Sewa+Bot+Nya

SISTEM MASUKIN BOT - TF - DONE
PEMBAYARAN💸
- GOPAY✓
- DANA✓
- OVO✓
- PULSA✓
AMAN? 100% AMAN NO TIPU MALAHAN AMANAH`
}

exports.upprembot = () => {
return`*「 AKIRAA IKLAN 」*

❏ Upgrade Premium : 10K/BULAN
❏ Perpanjang Premium: 5K/BULAN
❏ Premium + Sewa Bot : 10K (Promo)
❏ Order : wa.me/${nomerowner}?text=BANG+MAU+UPGRADE+PREMIUM
────────────────────
❏ Sewa Bot Ke Grup : 10K/BULAN
❏ Perpanjang : 5K/BULAN
❏ Order : wa.me/${nomerowner}?text=BANG+MAU+SEWA+BOTNYA+KE+GRUP+SAYA
────────────────────
❏ Pembayaran : DANA/OVO/GOPAY/PULSA 
❏ Note : KIRIM SCREENSHOT SEBAGAI BUKTI KE NOMOR wa.me/${nomerowner}

*「 AKIRAA BOT 」*`
}

exports.rules = (prefix) => {
return`-----[ PERATURAN ]-----

1. Jangan Spam Bot. 
Sanksi: _BLOCK_

2. Jangan Telepon Bot.
Sanksi: _BLOCK_

3. Jangan VC Bot.
Sanksi: _BLOCK_

*Jika Sudah Dipahami Peraturan Nya, Silakan Ketik ${prefix}menu*`
}

exports.listkode = () => {
return`❏ *LIST KODE BAHASA*
*af* : Afrikaans
*sq* : Albanian
*ar* : Arabic
*hy* : Armenian
*ca* : Catalan
*zh* : Chinese
*zh-cn* : Chinese (Mandarin/China)
*zh-tw* : Chinese (Mandarin/Taiwan)
*zh-yue* : Chinese (Cantonese)
*hr* : Croatian
*cs* : Czech
*da* : Danish
*nl* : Dutch
*en* : English
*en-au* : English (Australia)
*en-uk* : English (United Kingdom)
*en-us* : English (United States)
*eo* : Esperanto
*fi* : Finnish
*fr* : French
*de* : German
*el* : Greek
*ht* : Haitian Creole
*hi* : Hindi
*hu* : Hungarian
*is* : Icelandic
*id* : Indonesian
*it* : Italian
*ja* : Japanese
*ko* : Korean
*la* : Latin
*lv* : Latvian
*mk* : Macedonian
*no* : Norwegian
*pl* : Polish
*pt* : Portuguese
*pt-br* : Portuguese (Brazil)
*ro* : Romanian
*ru* : Russian
*sr* : Serbian
*sk* : Slovak
*es* : Spanish
*es-es* : Spanish (Spain)
*es-us* : Spanish (United States)
*sw* : Swahili
*sv* : Swedish
*ta* : Tamil
*th* : Thai
*tr* : Turkish
*vi* : Vietnamese
*cy* : Welsh`
}
